"use client";

import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { Card, CardContent } from "@/components/ui/card";
import { hmSecondsFromVdot } from "banister";
// Shared with the home Recovery card + the app, so a given z reads the same everywhere.
import { readinessScore as zToPercentile } from "@/lib/readiness";
import type { ChartValue } from "@/lib/chart-types";

interface ComparisonData {
  load: { date: string; dailyLoad: number; ctl: number; atl: number }[];
  readiness: { date: string; garminScore: number; ourScore: number }[];
  fitness: { date: string; garminVo2max: number; ourVdot: number | null }[];
  racePrediction: { date: string; garminSeconds: number | null; ourVdot: number | null }[];
}

interface ComparisonChartsProps {
  data: ComparisonData;
  hoveredDate: string | null;
  onHoverDate: (date: string | null) => void;
}

export function ComparisonCharts({ data, hoveredDate, onHoverDate }: ComparisonChartsProps) {
  // Map the signed z-composite to its normal-distribution percentile (0-100) so
  // it sits on the same honest scale as Garmin's 0-100 readiness. The old linear
  // `50 + z*25` went negative for z < -2 (our z reaches -3.4). Percentile is
  // strictly bounded: z=0 → 50, z=+2 → 98, z=-2 → 2.
  const readinessNormalized = data.readiness.map(r => ({
    ...r,
    ourScoreNorm: Math.round(zToPercentile(r.ourScore)),
  }));

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <ChartCard
        title="Training Load"
        subtitle="CTL/ATL vs Garmin Load"
        data={data.load}
        ourKey="ctl"
        garminKey="atl"
        ourLabel="CTL (ours)"
        garminLabel="ATL"
        ourColor="oklch(0.65 0.15 250)"
        hoveredDate={hoveredDate}
        onHoverDate={onHoverDate}
      />
      <ChartCard
        title="Readiness"
        subtitle="Normalized (0-100) vs Garmin"
        data={readinessNormalized}
        ourKey="ourScoreNorm"
        garminKey="garminScore"
        ourLabel="Our readiness"
        garminLabel="Garmin readiness"
        ourColor="oklch(0.65 0.15 142)"
        hoveredDate={hoveredDate}
        onHoverDate={onHoverDate}
      />
      <ChartCard
        title="Fitness"
        subtitle="VDOT vs Garmin VO2max"
        data={data.fitness}
        ourKey="ourVdot"
        garminKey="garminVo2max"
        ourLabel="VDOT (ours)"
        garminLabel="Garmin VO2max"
        ourColor="oklch(0.65 0.15 50)"
        hoveredDate={hoveredDate}
        onHoverDate={onHoverDate}
        tightYAxis
      />
      <ChartCard
        title="Race Prediction"
        subtitle="Daniels vs Garmin HM prediction"
        data={data.racePrediction.map(r => ({
          ...r,
          ourSeconds: r.ourVdot ? hmSecondsFromVdot(r.ourVdot) : null,
        }))}
        ourKey="ourSeconds"
        garminKey="garminSeconds"
        ourLabel="Daniels prediction"
        garminLabel="Garmin prediction"
        ourColor="oklch(0.65 0.15 320)"
        hoveredDate={hoveredDate}
        onHoverDate={onHoverDate}
        invertY
        tightYAxis
        formatValue={(s) => {
          const h = Math.floor(s / 3600);
          const m = Math.floor((s % 3600) / 60);
          const sec = Math.round(s % 60);
          return `${h}:${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
        }}
      />
    </div>
  );
}

function ChartCard({ title, subtitle, data, ourKey, garminKey, ourLabel, garminLabel, ourColor, hoveredDate: _hoveredDate, onHoverDate, invertY, formatValue, tightYAxis }: {
  title: string;
  subtitle: string;
  // Each card plots two series out of one row set, named by ourKey and garminKey, so the row
  // shape differs per card and only the date is common.
  data: ({ date: string } & Record<string, number | string | null>)[];
  ourKey: string;
  garminKey: string;
  ourLabel: string;
  garminLabel: string;
  ourColor: string;
  hoveredDate: string | null;
  onHoverDate: (date: string | null) => void;
  invertY?: boolean;
  formatValue?: (v: number) => string;
  tightYAxis?: boolean;
}) {
  if (data.length === 0) {
    return (
      <Card>
        <CardContent className="pt-4 pb-2 px-4">
          <h4 className="text-sm font-medium">{title}</h4>
          <p className="text-xs text-muted-foreground">{subtitle}</p>
          <div className="h-[160px] flex items-center justify-center text-xs text-muted-foreground">
            No data yet
          </div>
        </CardContent>
      </Card>
    );
  }

  // Compute tight Y domain from actual data values with 10% padding
  let yDomain: [number, number] | undefined;
  if (tightYAxis) {
    const vals = data
      .flatMap((d) => [d[ourKey], d[garminKey]])
      .filter((v): v is number => typeof v === "number" && isFinite(v));
    if (vals.length > 0) {
      const min = Math.min(...vals);
      const max = Math.max(...vals);
      const range = max - min || 1;
      const pad = range * 0.15;
      yDomain = [Math.floor(min - pad), Math.ceil(max + pad)];
    }
  }

  return (
    <Card>
      <CardContent className="pt-4 pb-2 px-4">
        <div className="mb-2">
          <h4 className="text-sm font-medium">{title}</h4>
          <p className="text-xs text-muted-foreground">{subtitle}</p>
        </div>
        <ResponsiveContainer width="100%" height={160}>
          <LineChart data={data} onMouseMove={(e: { activeLabel?: string | number }) => {
            if (e?.activeLabel) onHoverDate(String(e.activeLabel));
          }} onMouseLeave={() => onHoverDate(null)}>
            <XAxis dataKey="date" hide />
            <YAxis hide={!formatValue} reversed={invertY} width={formatValue ? 52 : 0} tickFormatter={formatValue} tick={{ fontSize: 10, fill: "oklch(0.55 0 0)" }} domain={yDomain} />
            <Tooltip
              contentStyle={{ backgroundColor: "oklch(0.15 0.01 250)", border: "1px solid oklch(0.3 0.01 250)", borderRadius: "6px", fontSize: "11px" }}
              labelStyle={{ color: "oklch(0.7 0 0)" }}
              formatter={formatValue ? (v: ChartValue) => formatValue(Number(v)) : undefined}
            />
            <Line type="monotone" dataKey={ourKey} stroke={ourColor} dot={false} strokeWidth={2} name={ourLabel} connectNulls />
            <Line type="monotone" dataKey={garminKey} stroke="oklch(0.5 0.02 250)" dot={false} strokeWidth={1.5} strokeDasharray="4 3" name={garminLabel} connectNulls />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

