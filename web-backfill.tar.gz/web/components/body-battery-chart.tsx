"use client";

import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Cell,
  ReferenceLine,
} from "recharts";
import { isLongRange, buildChartTicks, formatChartTick } from "@/lib/chart-utils";

interface BodyBatteryPoint {
  date: string;
  charged: number;
  drained: number;
}

export function BodyBatteryChart({ data }: { data: BodyBatteryPoint[] }) {
  if (data.length === 0) return null;

  const chartData = data.map((d) => ({
    date: d.date,
    charged: Number(d.charged),
    drained: -Number(d.drained),
    net: Number(d.charged) - Number(d.drained),
  }));

  const longRange = isLongRange(chartData);
  const tickDates = buildChartTicks(chartData);

  return (
    <ResponsiveContainer width="100%" height={200}>
      <BarChart data={chartData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }} stackOffset="sign">
        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.3} />
        <XAxis
          dataKey="date"
          className="text-[10px]"
          tickLine={false}
          tickFormatter={(d: string) => formatChartTick(d, longRange)}
          {...(tickDates ? { ticks: tickDates } : { interval: Math.max(Math.floor(chartData.length / 5), 1) })}
        />
        <YAxis
          className="text-[10px]"
          tickLine={false}
          width={35}
          tickFormatter={(v: number) => `${v}`}
        />
        <Tooltip
          cursor={{ fill: "var(--muted)", opacity: 0.3 }}
          contentStyle={{
            background: "var(--card)",
            border: "1px solid var(--border)",
            borderRadius: "8px",
            fontSize: "12px",
            color: "var(--card-foreground)",
          }}
          labelFormatter={(d) =>
            new Date(String(d)).toLocaleDateString("en-US", {
              weekday: "short",
              month: "short",
              day: "numeric",
            })
          }
          formatter={(value, name) => {
            const label = name === "charged" ? "Charged" : "Drained";
            return [`${Math.abs(Number(value))} pts`, label];
          }}
        />
        <ReferenceLine y={0} stroke="var(--muted-foreground)" opacity={0.3} />
        <Bar dataKey="charged" stackId="a" radius={[3, 3, 0, 0]}>
          {chartData.map((_, index) => (
            <Cell key={index} fill="oklch(62% 0.17 142)" opacity={0.6} />
          ))}
        </Bar>
        <Bar dataKey="drained" stackId="a" radius={[0, 0, 3, 3]}>
          {chartData.map((_, index) => (
            <Cell key={index} fill="oklch(60% 0.22 25)" opacity={0.5} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
