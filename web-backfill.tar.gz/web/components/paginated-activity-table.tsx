"use client";

import { useState } from "react";
import { ActivityDetailModal } from "./activity-detail-modal";
import {
  Wind,
  Snowflake,
  Mountain,
  Bike,
  Waves,
  PersonStanding,
  Heart,
  Activity,
  Footprints,
  ChevronUp,
  ChevronDown,
  ChevronsUpDown,
  Search,
} from "lucide-react";

const ACTIVITY_ICONS: Record<string, React.ReactNode> = {
  kiteboarding_v2: <Wind className="h-4 w-4 text-cyan-400" />,
  wind_kite_surfing: <Wind className="h-4 w-4 text-cyan-400" />,
  resort_snowboarding: <Snowflake className="h-4 w-4 text-blue-300" />,
  resort_skiing_snowboarding_ws: <Snowflake className="h-4 w-4 text-blue-300" />,
  hiking: <Mountain className="h-4 w-4 text-green-400" />,
  e_bike_fitness: <Bike className="h-4 w-4 text-yellow-400" />,
  lap_swimming: <Waves className="h-4 w-4 text-blue-400" />,
  swimming: <Waves className="h-4 w-4 text-blue-400" />,
  open_water_swimming: <Waves className="h-4 w-4 text-blue-400" />,
  walking: <PersonStanding className="h-4 w-4 text-emerald-400" />,
  cycling: <Bike className="h-4 w-4 text-yellow-400" />,
  indoor_cardio: <Heart className="h-4 w-4 text-red-400" />,
  other: <Activity className="h-4 w-4 text-muted-foreground" />,
  treadmill_running: <Footprints className="h-4 w-4 text-green-400" />,
};

const ACTIVITY_LABELS: Record<string, string> = {
  kiteboarding_v2: "Kiteboarding",
  wind_kite_surfing: "Kite Surfing",
  resort_snowboarding: "Snowboarding",
  resort_skiing_snowboarding_ws: "Snowboarding",
  hiking: "Hiking",
  e_bike_fitness: "E-Bike",
  lap_swimming: "Swimming",
  swimming: "Swimming",
  open_water_swimming: "Swimming",
  walking: "Walk",
  indoor_cardio: "Cardio",
  cycling: "Cycling",
  indoor_cycling: "Indoor Cycle",
  stand_up_paddleboarding_v2: "SUP",
  other: "Other",
  treadmill_running: "Treadmill",
};

interface Activity {
  activity_id: string;
  type_key: string;
  date: string;
  name: string;
  distance_km: number;
  duration_min: number;
  avg_hr: number | null;
  calories: number | null;
  elev_gain: number;
}

type SortKey = "date" | "distance_km" | "duration_min" | "avg_hr" | "calories" | "elev_gain";
type SortDir = "asc" | "desc";

const PAGE_SIZE = 20;

function formatDuration(mins: number) {
  const h = Math.floor(mins / 60);
  const m = Math.round(mins % 60);
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

// Module-level, not created inside the table's render: a component created during render is a
// new type every render and loses its state (soma#958).
function SortIcon({ col, sortKey, sortDir }: { col: SortKey; sortKey: SortKey; sortDir: SortDir }) {
  if (sortKey !== col)
    return <ChevronsUpDown className="h-3 w-3 opacity-30 inline ml-1" />;
  return sortDir === "asc" ? (
    <ChevronUp className="h-3 w-3 inline ml-1" />
  ) : (
    <ChevronDown className="h-3 w-3 inline ml-1" />
  );
}

export function PaginatedActivityTable({ activities }: { activities: Activity[] }) {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [page, setPage] = useState(0);
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState<string | null>(null);
  const [sortKey, setSortKey] = useState<SortKey>("date");
  const [sortDir, setSortDir] = useState<SortDir>("desc");

  function toggleSort(key: SortKey) {
    if (sortKey === key) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setSortKey(key);
      setSortDir("desc");
    }
    setPage(0);
  }

  const searchLower = search.toLowerCase();
  const searchFiltered = search
    ? activities.filter((a) => a.name.toLowerCase().includes(searchLower))
    : activities;

  // Get unique types for filter (from search-filtered set)
  const typeCounts = new Map<string, number>();
  for (const a of searchFiltered) {
    const label = ACTIVITY_LABELS[a.type_key] || a.type_key;
    typeCounts.set(label, (typeCounts.get(label) || 0) + 1);
  }
  const typeOptions = Array.from(typeCounts.entries()).sort((a, b) => b[1] - a[1]);

  const filtered = typeFilter
    ? searchFiltered.filter((a) => (ACTIVITY_LABELS[a.type_key] || a.type_key) === typeFilter)
    : searchFiltered;

  const sorted = [...filtered].sort((a, b) => {
    let av: number, bv: number;
    switch (sortKey) {
      case "date":
        av = new Date(a.date).getTime();
        bv = new Date(b.date).getTime();
        break;
      case "distance_km":
        av = a.distance_km;
        bv = b.distance_km;
        break;
      case "duration_min":
        av = a.duration_min;
        bv = b.duration_min;
        break;
      case "avg_hr":
        av = a.avg_hr ?? 0;
        bv = b.avg_hr ?? 0;
        break;
      case "calories":
        av = a.calories ?? 0;
        bv = b.calories ?? 0;
        break;
      case "elev_gain":
        av = a.elev_gain;
        bv = b.elev_gain;
        break;
      default:
        av = 0;
        bv = 0;
    }
    return sortDir === "asc" ? av - bv : bv - av;
  });

  const totalPages = Math.ceil(sorted.length / PAGE_SIZE);
  const pageActivities = sorted.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  return (
    <>
      {/* Search */}
      <div className="flex items-center gap-2 bg-muted/50 border border-border rounded-lg px-3 py-2 text-sm w-full max-w-xs mb-3">
        <Search className="h-4 w-4 text-muted-foreground shrink-0" />
        <input
          type="text"
          placeholder="Search activities..."
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(0); }}
          className="bg-transparent outline-none w-full placeholder:text-muted-foreground/60"
        />
      </div>

      {/* Type Filter */}
      {typeOptions.length > 1 && (
        <div className="flex flex-wrap gap-1.5 mb-3">
          <button
            onClick={() => { setTypeFilter(null); setPage(0); }}
            className={`px-3 py-2 min-h-[36px] rounded-full text-xs transition-colors ${
              !typeFilter ? "bg-primary text-primary-foreground" : "bg-muted hover:bg-accent text-muted-foreground"
            }`}
          >
            All ({searchFiltered.length})
          </button>
          {typeOptions.map(([label, count]) => (
            <button
              key={label}
              onClick={() => { setTypeFilter(label); setPage(0); }}
              className={`px-3 py-2 min-h-[36px] rounded-full text-xs transition-colors ${
                typeFilter === label ? "bg-primary text-primary-foreground" : "bg-muted hover:bg-accent text-muted-foreground"
              }`}
            >
              {label} ({count})
            </button>
          ))}
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-muted-foreground sticky top-0 z-10 bg-card">
              <th
                className="text-left py-2 font-medium cursor-pointer hover:text-foreground select-none"
                onClick={() => toggleSort("date")}
              >
                Date <SortIcon col="date" sortKey={sortKey} sortDir={sortDir} />
              </th>
              <th className="text-left py-2 font-medium">Type</th>
              <th className="text-left py-2 font-medium">Name</th>
              <th
                className="text-right py-2 font-medium cursor-pointer hover:text-foreground select-none"
                onClick={() => toggleSort("distance_km")}
              >
                Distance <SortIcon col="distance_km" sortKey={sortKey} sortDir={sortDir} />
              </th>
              <th
                className="text-right py-2 font-medium cursor-pointer hover:text-foreground select-none"
                onClick={() => toggleSort("duration_min")}
              >
                Duration <SortIcon col="duration_min" sortKey={sortKey} sortDir={sortDir} />
              </th>
              <th
                className="text-right py-2 font-medium cursor-pointer hover:text-foreground select-none hidden sm:table-cell"
                onClick={() => toggleSort("avg_hr")}
              >
                HR <SortIcon col="avg_hr" sortKey={sortKey} sortDir={sortDir} />
              </th>
              <th
                className="text-right py-2 font-medium cursor-pointer hover:text-foreground select-none hidden sm:table-cell"
                onClick={() => toggleSort("calories")}
              >
                Cal <SortIcon col="calories" sortKey={sortKey} sortDir={sortDir} />
              </th>
              <th
                className="text-right py-2 font-medium cursor-pointer hover:text-foreground select-none hidden lg:table-cell"
                onClick={() => toggleSort("elev_gain")}
              >
                Elev <SortIcon col="elev_gain" sortKey={sortKey} sortDir={sortDir} />
              </th>
            </tr>
          </thead>
          <tbody>
            {pageActivities.map((a) => (
              <tr
                key={a.activity_id}
                className="border-b border-border/50 cursor-pointer hover:bg-accent/30 active:bg-accent/40 active:scale-[0.998] transition-all"
                onClick={() => setSelectedId(a.activity_id)}
              >
                <td className="py-2.5 text-muted-foreground whitespace-nowrap">
                  {new Date(a.date).toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                    year: "2-digit",
                  })}
                </td>
                <td className="py-2.5">
                  <span className="flex items-center gap-1.5">
                    {ACTIVITY_ICONS[a.type_key] || null}
                    <span className="text-xs">
                      {ACTIVITY_LABELS[a.type_key] || a.type_key}
                    </span>
                  </span>
                </td>
                <td className="py-2.5 max-w-[200px] truncate"><span title={a.name}>{a.name}</span></td>
                <td className="py-2.5 text-right">
                  {a.distance_km.toFixed(1)} km
                </td>
                <td className="py-2.5 text-right whitespace-nowrap">
                  {formatDuration(a.duration_min)}
                </td>
                <td className="py-2.5 text-right hidden sm:table-cell">
                  {a.avg_hr ? Math.round(a.avg_hr) : "—"}
                </td>
                <td className="py-2.5 text-right text-muted-foreground hidden sm:table-cell">
                  {a.calories ? Math.round(a.calories) : "—"}
                </td>
                <td className="py-2.5 text-right text-muted-foreground hidden lg:table-cell">
                  {a.elev_gain > 0 ? `${a.elev_gain.toLocaleString()}m` : "—"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-4 text-sm">
          <span className="text-muted-foreground">
            {page * PAGE_SIZE + 1}–{Math.min((page + 1) * PAGE_SIZE, sorted.length)} of {sorted.length}
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage(Math.max(0, page - 1))}
              disabled={page === 0}
              className="px-3 py-2 rounded border border-border text-xs hover:bg-accent disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              Previous
            </button>
            <div className="flex items-center gap-1">
              {(() => {
                const getVisiblePages = (): (number | "ellipsis")[] => {
                  if (totalPages <= 5) {
                    return Array.from({ length: totalPages }, (_, i) => i);
                  }
                  const pages: (number | "ellipsis")[] = [0];
                  if (page > 2) pages.push("ellipsis");
                  for (let i = Math.max(1, page - 1); i <= Math.min(totalPages - 2, page + 1); i++) {
                    pages.push(i);
                  }
                  if (page < totalPages - 3) pages.push("ellipsis");
                  if (totalPages > 1) pages.push(totalPages - 1);
                  return pages;
                };
                return getVisiblePages().map((p, idx) =>
                  p === "ellipsis" ? (
                    <span key={`ellipsis-${idx}`} className="w-9 h-9 flex items-center justify-center text-xs text-muted-foreground">
                      ...
                    </span>
                  ) : (
                    <button
                      key={p}
                      onClick={() => setPage(p)}
                      className={`w-9 h-9 rounded text-xs transition-colors ${
                        page === p
                          ? "bg-primary text-primary-foreground"
                          : "hover:bg-accent"
                      }`}
                    >
                      {p + 1}
                    </button>
                  )
                );
              })()}
            </div>
            <button
              onClick={() => setPage(Math.min(totalPages - 1, page + 1))}
              disabled={page === totalPages - 1}
              className="px-3 py-2 rounded border border-border text-xs hover:bg-accent disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              Next
            </button>
          </div>
        </div>
      )}

      <ActivityDetailModal activityId={selectedId} onClose={() => setSelectedId(null)} />
    </>
  );
}
