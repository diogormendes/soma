"use client";

import { useEffect, useState, useMemo, useCallback, useRef } from "react";
import { Loader2, Save, Check, X, AlertTriangle, ShieldAlert } from "lucide-react";
import { Card } from "@/components/ui/card";
import { readinessScore } from "@/lib/readiness";
import { ComputationGraphView } from "@/components/computation-graph";
import { TrajectorySection } from "@/components/trajectory-section";
import { ReferencePanel, type ReferenceMetric } from "@/components/reference-panel";
import { TrainingPlanView, type ActivityMatch } from "@/components/training-plan-view";

import { TrainingPacesCard } from "@/components/training-paces-card";
import { ComparisonCharts } from "@/components/comparison-charts";
import { FloatingSlider } from "@/components/floating-slider";
import {
  type GraphApiResponse,
  type ComputationGraph,
  type DeltaWorkout,
  type Override,
  DEFAULT_BASE_PACE,
  recomputeGraphForSlider,
  adjustStepTargets,
  colorForNode } from "@/lib/training-engine";
import { hmSecondsFromVdot } from "banister";
import { normalizeSteps, type NormalizedStep } from "@/lib/normalize-steps";
import type { PlanDayWithPlan } from "@/lib/live-plan";
import { runForwardSimulation, type ProjectedDay, type SimulationSeeds } from "banister";

// ── Types ─────────────────────────────────────────────────────

export interface ReferenceData {
  readinessHistory: {
    date: string;
    composite_score: number | null;
    garmin_readiness_score: number | null;
  }[];
  fitnessHistory: {
    date: string;
    efficiency_factor: number | null;
    decoupling_pct: number | null;
    race_prediction_seconds: number | null;
    vdot_adjusted: number | null;
  }[];
  weightHistory: {
    date: string;
    weight_kg: number | null;
  }[];
}

export interface TrajectoryNorms {
  ctlMin: number; ctlRange: number;
  readinessMin: number; readinessRange: number;
  weightMin: number; weightRange: number;
}

interface TrainingDashboardProps {
  planDays: PlanDayWithPlan[];
  today: string;
  // A plan can exist without a goal time or a name; only the race date is required to be here.
  raceInfo: { race_date: string; goal_time_seconds: number | null; plan_name: string | null } | null;
  trajectoryData: { date: string; optimal: number; actual: number | null; projectedVdot?: number | null; ctl: number | null; readiness: number | null; weightEffect: number | null }[];
  trajectoryNorms: TrajectoryNorms | null;
  currentVdot: number;
  goalVdot: number;
  referenceData: ReferenceData;
  /** Whether a plan is live and why (#701). Absent means "assume live" for older callers. */
  engagement?: { state: string; planLive: boolean; basis: string; planName: string | null };
  /** What the athlete has actually been doing; the projection baseline when no plan is live. */
  fallback?: { windowDays: number; meanDailyLoad: number; activeDays: number; label: string };
}

// ── Helpers ───────────────────────────────────────────────────

function findNode(graph: ComputationGraph, id: string) {
  return graph.nodes.find((n) => n.id === id);
}

/** Format race prediction seconds into H:MM:SS or M:SS display. */
function formatRaceTime(totalSeconds: number): string {
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = Math.round(totalSeconds % 60);
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}

/** Build reference metrics from separately-queried external data — signals NOT in the formula graph. */
function buildReferenceMetrics(
  referenceData: ReferenceData,
  currentVdot: number,
): ReferenceMetric[] {
  const { readinessHistory, fitnessHistory, weightHistory } = referenceData;

  const latestReadiness = readinessHistory.at(-1);
  const latestFitness = fitnessHistory.at(-1);
  const latestWeight = weightHistory.at(-1);

  // Build race prediction sparkline: use DB values when available, fall back to
  // VDOT-derived estimates so sparklines are never empty when VDOT data exists.
  const racePredSparkline: number[] = [];
  for (const d of fitnessHistory) {
    if (d.race_prediction_seconds != null) {
      racePredSparkline.push(Number(d.race_prediction_seconds));
    } else if (d.vdot_adjusted != null && Number(d.vdot_adjusted) > 0) {
      racePredSparkline.push(hmSecondsFromVdot(Number(d.vdot_adjusted)));
    }
  }

  // Determine the latest race prediction from the CURRENT (banister) VDOT via the
  // same Daniels VO2 model, so it matches the displayed VDOT and the app. The
  // fitness_trajectory race_prediction_seconds / vdot_adjusted are stale (an
  // older, higher VDOT) and disagreed \u2014 e.g. banister 43.2 \u2192 1:43:49 (app match),
  // vs the stale 57.7 \u2192 1:20:50. Keep the stale values only as a fallback.
  let latestRacePrediction: string = "\u2014";
  if (currentVdot && currentVdot > 0) {
    latestRacePrediction = formatRaceTime(hmSecondsFromVdot(currentVdot));
  } else if (latestFitness?.race_prediction_seconds != null) {
    latestRacePrediction = formatRaceTime(Number(latestFitness.race_prediction_seconds));
  } else if (latestFitness?.vdot_adjusted != null && Number(latestFitness.vdot_adjusted) > 0) {
    latestRacePrediction = formatRaceTime(hmSecondsFromVdot(Number(latestFitness.vdot_adjusted)));
  }

  return [
    {
      id: "readiness",
      label: "Readiness",
      // soma's own model readiness (0-100 percentile of the recovery z-composite),
      // headlined; Garmin's readiness is the comparison. Was showing the raw
      // z-composite ("4.3") next to Garmin's 0-100 ("66") \u2014 different scales.
      value: latestReadiness?.composite_score != null
        ? String(readinessScore(Number(latestReadiness.composite_score)))
        : "\u2014",
      sparkline: readinessHistory
        .filter((r) => r.composite_score != null)
        .map((r) => readinessScore(Number(r.composite_score))),
      color: "oklch(65% 0.15 142)",
      tooltip:
        "soma\u2019s model readiness \u2014 the 0-100 percentile of today\u2019s recovery z-composite. Garmin\u2019s own readiness is shown for comparison.",
      comparison: {
        ours: latestReadiness?.composite_score != null
          ? String(readinessScore(Number(latestReadiness.composite_score)))
          : "\u2014",
        garmin: latestReadiness?.garmin_readiness_score != null
          ? String(Math.round(Number(latestReadiness.garmin_readiness_score)))
          : "\u2014" } },
    {
      id: "race-prediction",
      label: "Race Prediction",
      value: latestRacePrediction,
      sparkline: racePredSparkline,
      color: "oklch(65% 0.15 160)",
      tooltip:
        "Predicted half-marathon time from current VDOT. Based on Daniels/Gilbert VO2 model." },
    {
      id: "decoupling",
      label: "Pace:HR Decoupling",
      value: latestFitness?.decoupling_pct != null
        ? `${Number(latestFitness.decoupling_pct).toFixed(1)}%`
        : "\u2014",
      sparkline: fitnessHistory
        .filter((d) => d.decoupling_pct != null)
        .map((d) => Number(d.decoupling_pct)),
      color: "oklch(65% 0.15 142)",
      tooltip:
        "How much heart rate drifts up during steady runs. <3% = aerobically ready. >5% = not ready for that pace over race distance.",
      thresholds: [
        { label: "<3% good", color: "oklch(65% 0.15 142)" },
        { label: ">5% caution", color: "oklch(65% 0.15 50)" },
      ] },
    {
      id: "ef-trend",
      label: "Efficiency Factor",
      value: latestFitness?.efficiency_factor != null
        ? Number(latestFitness.efficiency_factor).toFixed(2)
        : "\u2014",
      sparkline: fitnessHistory
        .filter((d) => d.efficiency_factor != null)
        .map((d) => Number(d.efficiency_factor)),
      color: "oklch(65% 0.15 200)",
      tooltip:
        "Speed / heart rate. Rising = improving running economy. Measures how fast you go per heartbeat." },
    {
      id: "weight-trend",
      label: "Weight Trend",
      value: latestWeight?.weight_kg != null
        ? `${Number(latestWeight.weight_kg).toFixed(1)} kg`
        : "\u2014",
      sparkline: weightHistory
        .filter((w) => w.weight_kg != null)
        .map((w) => Number(w.weight_kg)),
      color: "oklch(65% 0.12 50)",
      tooltip:
        "Recent weight from fitness trajectory. Every 1 kg of fat loss \u2248 1:00\u20131:15 faster HM at your fitness level." },
  ];
}

/** Recompute shadow graph with a different slider value — full forward-pass through all nodes. */
function computeShadowGraph(
  baseGraph: ComputationGraph,
  sliderValue: number,
): ComputationGraph {
  return recomputeGraphForSlider(baseGraph, sliderValue);
}

/** Build a computation graph from a forward-simulation projected day (for future date hover). */
function buildGraphFromProjection(
  baseGraph: ComputationGraph,
  projected: ProjectedDay,
): ComputationGraph {
  // Raw signals and z-scores are unknown for future dates
  const unknownForFuture = new Set([
    "hrv_raw", "sleep_raw", "rhr_raw", "bb_raw", "epoc_raw", "weight_raw",
    "hrv_z", "sleep_z", "rhr_z", "bb_z", "weight_ema",
  ]);

  const nodes = baseGraph.nodes.map(n => {
    const clone = { ...n };

    if (unknownForFuture.has(n.id)) {
      clone.value = null;
      clone.color = "oklch(40% 0.02 250)";
      return clone;
    }

    switch (n.id) {
      case "ctl": clone.value = Math.round(projected.ctl * 10) / 10; break;
      case "atl": clone.value = Math.round(projected.atl * 10) / 10; break;
      case "tsb": clone.value = Math.round(projected.tsb * 10) / 10; break;
      case "readiness_factor":
        clone.value = projected.readinessFactor < 0 ? null : Math.round(projected.readinessFactor * 10000) / 10000;
        break;
      case "fatigue_factor": clone.value = Math.round(projected.fatigueFactor * 10000) / 10000; break;
      case "weight_factor": clone.value = Math.round(projected.weightFactor * 10000) / 10000; break;
      case "adjusted_pace": clone.value = projected.predictedHmPace; break;
      case "vdot": clone.value = Math.round(projected.projectedVdot * 10) / 10; break;
      case "slider_factor": clone.value = 1.0; break;
    }
    clone.color = colorForNode(n.id, clone.value);
    return clone;
  });
  return { ...baseGraph, nodes };
}

// ── Component ─────────────────────────────────────────────────

export function TrainingDashboard({
  planDays,
  today,
  raceInfo,
  trajectoryData,
  trajectoryNorms,
  currentVdot,
  goalVdot,
  referenceData,
  engagement,
  fallback }: TrainingDashboardProps) {
  // A plan is live unless the server said otherwise. Everything that is
  // ABOUT the plan (schedule, next session, edits) hides when it is not;
  // everything from Garmin (load, fitness, readiness, comparison) stays.
  const planLive = engagement ? engagement.planLive : true;

  // Client-side state
  const [sliderValue, setSliderValue] = useState(1.0);
  const [graphData, setGraphData] = useState<GraphApiResponse | null>(null);
  const [activityMatches, setActivityMatches] = useState<ActivityMatch[]>([]);
  const [hoveredDate, setHoveredDate] = useState<string | null>(null);
  const [hoveredGraph, setHoveredGraph] = useState<ComputationGraph | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveResult, setSaveResult] = useState<"idle" | "success" | "error">("idle");

  // Forward simulation state
  const [forwardSim, setForwardSim] = useState<ProjectedDay[] | null>(null);
  const [forwardSimSeeds, setForwardSimSeeds] = useState<SimulationSeeds | null>(null);

  // Edited workout steps (dayId -> modified steps) from inline editing
  const [editedSteps, setEditedSteps] = useState<Map<number, NormalizedStep[]>>(new Map());

  // Cache of fetched graph data per date (avoids re-fetching on re-hover)
  const graphCacheRef = useRef<Map<string, ComputationGraph>>(new Map());
  const hoverFetchTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const activeFetchRef = useRef<AbortController | null>(null);

  const isDirty = sliderValue !== 1.0 || editedSteps.size > 0;

  // Refetchable data loader — used on mount and after save
  const refetchData = useCallback(async () => {
    const [graphRes, matchRes, simRes] = await Promise.all([
      fetch(`/api/training/graph?date=${today}`),
      fetch("/api/training/activity-match"),
      fetch("/api/training/forward-sim"),
    ]);
    if (graphRes.ok) setGraphData(await graphRes.json());
    if (matchRes.ok) setActivityMatches(await matchRes.json());
    if (simRes.ok) {
      const simData: SimulationSeeds = await simRes.json();
      setForwardSimSeeds(simData);
      const projected = runForwardSimulation({
        ...simData,
        sliderMultiplier: sliderValue });
      setForwardSim(projected);
    }
  }, [today, sliderValue]);

  // Fetch graph data and activity matches on mount
  useEffect(() => {
    let cancelled = false;

    async function fetchData() {
      try {
        await refetchData();
      } catch {
        // Silently handle errors — graceful degradation
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    fetchData();
    return () => { cancelled = true; };
  }, [refetchData]);

  // Cleanup hover fetch timer and abort controller on unmount
  useEffect(() => {
    return () => {
      if (hoverFetchTimerRef.current) clearTimeout(hoverFetchTimerRef.current);
      if (activeFetchRef.current) activeFetchRef.current.abort();
    };
  }, []);

  // Re-run forward simulation when slider changes (no API call needed)
  useEffect(() => {
    if (!forwardSimSeeds) return;
    const projected = runForwardSimulation({
      ...forwardSimSeeds,
      sliderMultiplier: sliderValue });
    setForwardSim(projected);
  }, [sliderValue, forwardSimSeeds]);

  // Shadow graph recomputed when slider changes
  const shadowGraph = useMemo<ComputationGraph | null>(() => {
    if (!graphData || sliderValue === 1.0) return null;
    return computeShadowGraph(graphData.graph, sliderValue);
  }, [graphData, sliderValue]);

  // Trajectory from forward simulation — includes all days (rest included for continuous curve)
  const trajectoryFromSim = useMemo(() => {
    if (!forwardSim) return null;
    return forwardSim
      .map(d => ({
        date: d.dayDate,
        projectedVdot: d.projectedVdot,
        ctl: d.ctl,
        tsb: d.tsb,
        projectedZ: d.projectedZ,
        weightFactor: d.weightFactor,
        adaptationMagnitude: Math.abs(d.paceChangePct),
        adaptationColor: d.paceChangePct < -0.5 ? "oklch(0.7 0.15 142)"  // green = faster
          : d.paceChangePct > 0.5 ? "oklch(0.7 0.15 25)"   // red = slower
          : "oklch(0.7 0.05 250)",  // neutral
      }));
  }, [forwardSim]);

  // Expand normalization range to include projected values (prevents clamping to 100%)
  const expandedNorms = useMemo(() => {
    if (!trajectoryNorms) return null;
    if (!trajectoryFromSim || trajectoryFromSim.length === 0) return trajectoryNorms;
    const simCtls = trajectoryFromSim.map(d => d.ctl);
    const simZs = trajectoryFromSim.map(d => d.projectedZ);
    const histCtlMax = trajectoryNorms.ctlMin + trajectoryNorms.ctlRange;
    const histReadMax = trajectoryNorms.readinessMin + trajectoryNorms.readinessRange;
    const allCtlMin = Math.min(trajectoryNorms.ctlMin, ...simCtls);
    const allCtlMax = Math.max(histCtlMax, ...simCtls);
    const allReadMin = Math.min(trajectoryNorms.readinessMin, ...simZs);
    const allReadMax = Math.max(histReadMax, ...simZs);
    return {
      ctlMin: allCtlMin,
      ctlRange: Math.max(allCtlMax - allCtlMin, 1),
      readinessMin: allReadMin,
      readinessRange: Math.max(allReadMax - allReadMin, 1),
      weightMin: trajectoryNorms.weightMin,
      weightRange: trajectoryNorms.weightRange };
  }, [trajectoryNorms, trajectoryFromSim]);

  // Merge forward sim projections into trajectory data (fills future dims)
  const mergedTrajectory = useMemo(() => {
    if (!trajectoryFromSim || !trajectoryData.length) return trajectoryData;

    const norms = expandedNorms;
    const simMap = new Map(trajectoryFromSim.map(d => [d.date, d]));
    const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

    return trajectoryData.map(point => {
      const sim = simMap.get(point.date);
      if (!sim) return point;

      const isFuture = point.date > today;
      let ctlNorm = point.ctl;
      let readinessNorm = point.readiness;
      let weightNorm = point.weightEffect;

      if (isFuture && norms) {
        // Future dates: always use forward-sim projected values
        // (server forward-fill gives flat lines; sim evolves with planned loads)
        ctlNorm = clamp01((sim.ctl - norms.ctlMin) / norms.ctlRange);
        readinessNorm = clamp01((sim.projectedZ - norms.readinessMin) / norms.readinessRange);
        // Weight: keep last known value (we don't project weight changes)
        // weightNorm already forward-filled from server data — leave as-is
      } else {
        // Past dates: only fill when server data is missing
        if (ctlNorm == null && norms) {
          ctlNorm = clamp01((sim.ctl - norms.ctlMin) / norms.ctlRange);
        }
        if (readinessNorm == null && norms) {
          readinessNorm = clamp01((sim.projectedZ - norms.readinessMin) / norms.readinessRange);
        }
        if (weightNorm == null && norms && sim.weightFactor > 0) {
          weightNorm = clamp01(1 - (sim.weightFactor - 0.95) / 0.1);
        }
      }

      // For future dates, use forward sim's VDOT so slider affects the trajectory curve.
      // The forward sim responds to slider changes; the server's optimal is static.
      const optimal = isFuture && sim.projectedVdot > 0
        ? sim.projectedVdot
        : point.optimal;

      return {
        ...point,
        optimal,
        ctl: ctlNorm,
        readiness: readinessNorm,
        weightEffect: weightNorm,
        simCtl: sim.ctl,
        simTsb: sim.tsb };
    });
  }, [trajectoryData, trajectoryFromSim, expandedNorms, today]);

  // Shadow trajectory for delta simulation
  const shadowTrajectory = useMemo(() => {
    if (sliderValue === 1.0 || !trajectoryData.length) return null;
    // Scale the optimal curve by the slider's effect on progression rate
    return trajectoryData.map((entry) => {
      const baseGap = entry.optimal - currentVdot;
      const scaledGap = baseGap * sliderValue;
      return {
        date: entry.date,
        optimal: currentVdot + scaledGap,
        actual: entry.actual };
    });
  }, [trajectoryData, sliderValue, currentVdot]);

  // Delta workouts computed from slider
  const deltaWorkouts = useMemo<DeltaWorkout[]>(() => {
    if (sliderValue === 1.0 || !graphData) return [];
    const rfNode = findNode(graphData.graph, "readiness_factor");
    const ffNode = findNode(graphData.graph, "fatigue_factor");
    const wfNode = findNode(graphData.graph, "weight_factor");
    const rf = rfNode?.value ?? 1.0;
    const ff = ffNode?.value ?? 1.0;
    const wf = wfNode?.value ?? 1.0;
    const combined = rf * ff * wf;
    const delta = combined - 1.0;

    const todayIdx = planDays.findIndex((d) => d.day_date >= today);
    const futureDays = todayIdx >= 0 ? planDays.slice(todayIdx) : [];

    const origPace = DEFAULT_BASE_PACE * combined;
    const newPace = DEFAULT_BASE_PACE * (1.0 + delta * sliderValue);

    return futureDays
      .filter((d) => d.run_type !== "rest")
      .map((d) => {
        const distFactor = sliderValue > 1.0 ? 1.0 + (sliderValue - 1.0) * 0.3 : 1.0 - (1.0 - sliderValue) * 0.3;

        // Adjust per-step targets (pace/HR) using the day-level pace ratio
        let adjustedSteps: import("@/lib/normalize-steps").NormalizedStep[] | undefined;
        if (Array.isArray(d.workout_steps) && d.workout_steps.length > 0) {
          const baseSteps = normalizeSteps(d.workout_steps);
          adjustedSteps = adjustStepTargets(baseSteps, sliderValue, newPace, origPace);
        }

        // A plan day can carry no distance and no run type; a delta over nothing is zero, and
        // the label falls back to the empty string rather than rendering "null".
        const originalDistance = d.target_distance_km ?? 0;
        return {
          dayId: d.id,
          dayDate: d.day_date,
          originalPace: Math.round(origPace * 10) / 10,
          newPace: Math.round(newPace * 10) / 10,
          originalDistance,
          newDistance: Math.round(originalDistance * distFactor * 10) / 10,
          originalType: d.run_type ?? "",
          newType: d.run_type ?? "",
          changed: sliderValue !== 1.0,
          adjustedSteps,
        };
      });
  }, [sliderValue, graphData, planDays, today]);

  // Reference metrics from server-queried external data
  const referenceMetrics = useMemo<ReferenceMetric[]>(() => {
    return buildReferenceMetrics(referenceData, currentVdot);
  }, [referenceData, currentVdot]);

  // Dynamic VDOT: prefer graph node value, fall back to server-provided currentVdot prop
  const dynamicVdot = useMemo(() => {
    if (graphData) {
      const vdotNode = findNode(graphData.graph, "vdot");
      if (vdotNode?.value != null && vdotNode.value > 0) return vdotNode.value;
    }
    return currentVdot;
  }, [graphData, currentVdot]);

  const handleSliderChange = useCallback((value: number) => {
    setSliderValue(value);
  }, []);

  const handleHoverDate = useCallback((date: string | null) => {
    setHoveredDate(date);

    // Clear any pending debounced fetch
    if (hoverFetchTimerRef.current) {
      clearTimeout(hoverFetchTimerRef.current);
      hoverFetchTimerRef.current = null;
    }

    // If hover leaves or date is today, clear hovered graph
    if (!date || date === today) {
      if (activeFetchRef.current) {
        activeFetchRef.current.abort();
        activeFetchRef.current = null;
      }
      setHoveredGraph(null);
      return;
    }

    // For future dates, build graph from forward simulation (no API call needed)
    if (date > today && forwardSim && graphData) {
      const projected = forwardSim.find(d => d.dayDate === date);
      if (projected) {
        const builtGraph = buildGraphFromProjection(graphData.graph, projected);
        graphCacheRef.current.set(date, builtGraph);
        setHoveredGraph(builtGraph);
        return;
      }
    }

    // Check cache first
    const cached = graphCacheRef.current.get(date);
    if (cached) {
      setHoveredGraph(cached);
      return;
    }

    // Debounced fetch (150ms) to avoid flooding the API on quick sweeps
    hoverFetchTimerRef.current = setTimeout(async () => {
      // Abort any in-flight fetch
      if (activeFetchRef.current) {
        activeFetchRef.current.abort();
      }
      const controller = new AbortController();
      activeFetchRef.current = controller;

      try {
        const res = await fetch(`/api/training/graph?date=${date}`, {
          signal: controller.signal });
        if (res.ok) {
          const data: GraphApiResponse = await res.json();
          graphCacheRef.current.set(date, data.graph);
          setHoveredGraph(data.graph);
        }
      } catch {
        // Aborted or network error — silently ignore
      } finally {
        if (activeFetchRef.current === controller) {
          activeFetchRef.current = null;
        }
      }
    }, 150);
  }, [today, forwardSim, graphData]);

  const handleSave = useCallback(async () => {
    if (deltaWorkouts.length === 0 && editedSteps.size === 0) return;
    setSaving(true);
    setSaveResult("idle");

    try {
      // Merge delta workouts + edited steps into a single payload
      const workoutMap = new Map<number, { dayId: number; newDistance?: number; newType?: string; workoutSteps?: NormalizedStep[] }>();

      // Add slider-derived delta workouts
      for (const w of deltaWorkouts) {
        workoutMap.set(w.dayId, {
          dayId: w.dayId,
          newDistance: w.newDistance,
          newType: w.newType });
      }

      // Overlay edited steps
      for (const [dayId, steps] of editedSteps) {
        const existing = workoutMap.get(dayId) || { dayId };
        workoutMap.set(dayId, { ...existing, workoutSteps: steps });
      }

      const res = await fetch("/api/training/delta/save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sliderFactor: sliderValue,
          updatedWorkouts: Array.from(workoutMap.values()) }) });

      if (res.ok) {
        setSaveResult("success");
        // Reset slider and edited steps after brief success display
        setTimeout(() => {
          setSliderValue(1.0);
          setEditedSteps(new Map());
          setSaveResult("idle");
          refetchData();
        }, 1500);
      } else {
        setSaveResult("error");
        setTimeout(() => setSaveResult("idle"), 3000);
      }
    } catch {
      setSaveResult("error");
      setTimeout(() => setSaveResult("idle"), 3000);
    } finally {
      setSaving(false);
    }
  }, [deltaWorkouts, sliderValue, editedSteps, refetchData]);

  // Loading state
  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          <p className="text-sm text-muted-foreground">Loading training intelligence...</p>
        </div>
      </div>
    );
  }

  // Extract active overrides for hoisted alerts
  const activeOverrides: Override[] = graphData
    ? graphData.graph.overrides.filter((o) => o.triggered)
    : [];

  return (
    <div className="space-y-4">
      {/* Hoisted override alerts — always visible at top */}
      {activeOverrides.map((ov) => (
        <div
          key={ov.rule}
          className="flex items-center gap-2 rounded-md border px-3 py-2 text-xs"
          style={{
            backgroundColor:
              ov.severity === "red"
                ? "oklch(30% 0.08 25 / 0.3)"
                : "oklch(40% 0.1 85 / 0.25)",
            borderColor:
              ov.severity === "red"
                ? "oklch(55% 0.2 25 / 0.5)"
                : "oklch(70% 0.15 85 / 0.5)",
            color:
              ov.severity === "red"
                ? "oklch(80% 0.12 25)"
                : "oklch(85% 0.12 85)" }}
        >
          {ov.severity === "red" ? (
            <ShieldAlert className="h-4 w-4 shrink-0" />
          ) : (
            <AlertTriangle className="h-4 w-4 shrink-0" />
          )}
          <span>{ov.message}</span>
        </div>
      ))}

      {/* Computation Graph */}
      {graphData && (
        <Card className="p-4">
          <h3 className="text-sm font-medium text-muted-foreground mb-1">Model Computation</h3>
          <ComputationGraphView
            graph={hoveredDate && hoveredGraph ? hoveredGraph : graphData.graph}
            shadowGraph={shadowGraph}
            sliderValue={sliderValue}
            onSliderChange={handleSliderChange}
            hoveredDate={hoveredDate}
            hideOverrides
            calibration={graphData.calibration}
          />
        </Card>
      )}

      {/* Visual connector: graph output flows into trajectory */}
      {graphData && raceInfo && trajectoryData.length > 0 && (
        <div className="flex justify-center -my-2 relative z-10">
          <svg width="20" height="24" viewBox="0 0 20 24">
            <path d="M10 0 L10 20 M6 16 L10 22 L14 16" stroke="currentColor"
                  strokeWidth="1.5" fill="none" className="text-muted-foreground/50" />
          </svg>
        </div>
      )}

      {/* Trajectory Chart — output of the computation graph */}
      {raceInfo && trajectoryData.length > 0 && (
        <Card className="p-4">
          <h3 className="text-sm font-medium text-muted-foreground mb-1">Output: Fitness Trajectory</h3>
          <TrajectorySection
            baseTrajectory={mergedTrajectory}
            raceDate={raceInfo.race_date}
            today={today}
            goalVdot={goalVdot}
            currentVdot={currentVdot}
            sliderValue={sliderValue}
            onSliderChange={handleSliderChange}
            shadowTrajectory={shadowTrajectory}
            onHoverDate={handleHoverDate}
            projectedDays={forwardSim}
          />
        </Card>
      )}

      {/* Reference Panel + Training Paces — side by side on wide screens */}
      {referenceMetrics.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] gap-4">
          <ReferencePanel metrics={referenceMetrics} />
          <TrainingPacesCard vdot={dynamicVdot} />
        </div>
      ) : (
        <TrainingPacesCard vdot={dynamicVdot} />
      )}

      {/* Comparison Charts — our metrics vs Garmin */}
      {forwardSimSeeds?.comparison && (
        <>
          <h3 className="text-sm font-medium text-muted-foreground">Model vs Garmin</h3>
          <ComparisonCharts
            data={forwardSimSeeds.comparison}
            hoveredDate={hoveredDate}
            onHoverDate={handleHoverDate}
          />
        </>
      )}

      {/* Training Plan — only when a plan is LIVE. A dormant or unfollowed
          plan is not shown as a schedule with missed days; the page-level card
          has already said what the situation is, and the fallback label below
          says what the projections assume instead (#701, #703). */}
      {planLive ? (
        <>
          <h3 className="text-sm font-medium text-muted-foreground">Training Plan</h3>
          <div data-testid="training-plan-section">
            <TrainingPlanView
              days={planDays}
              today={today}
              activityMatches={activityMatches}
              deltaWorkouts={deltaWorkouts}
              onStepsEdited={setEditedSteps}
              projectedDays={forwardSim}
              sliderActive={Math.abs(sliderValue - 1.0) > 0.001}
            />
          </div>
        </>
      ) : (
        fallback && (
          <p className="text-xs text-muted-foreground" data-testid="training-fallback-note">
            Projections assume {fallback.label}: about {Math.round(fallback.meanDailyLoad)} load/day.
          </p>
        )
      )}

      {/* Delta save button — only meaningful against a live plan */}
      {planLive && isDirty && (
        <div className="sticky bottom-4 flex justify-center z-40">
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex items-center gap-2 px-6 py-3 rounded-full bg-primary text-primary-foreground shadow-lg hover:bg-primary/90 transition-all disabled:opacity-60"
          >
            {saving ? (
              <><Loader2 className="h-4 w-4 animate-spin" /> Saving...</>
            ) : saveResult === "success" ? (
              <><Check className="h-4 w-4" /> Saved!</>
            ) : saveResult === "error" ? (
              <><X className="h-4 w-4" /> Error — try again</>
            ) : (
              <><Save className="h-4 w-4" /> Apply Changes ({deltaWorkouts.length + editedSteps.size} workouts)</>
            )}
          </button>
        </div>
      )}

      {/* Floating training intensity slider — it scales PLAN workouts, so
          there is nothing for it to scale without a live plan */}
      {planLive && (
        <FloatingSlider
          value={sliderValue}
          onChange={setSliderValue}
          savedValue={1.0}
          onSave={handleSave}
          onReset={() => setSliderValue(1.0)}
        />
      )}
    </div>
  );
}
