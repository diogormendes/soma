"use client";

import { useState, useEffect } from "react";
import dynamic from "next/dynamic";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle } from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Download, Upload, Check, Loader2 } from "lucide-react";
import { ActivityPerformanceChart, type TimeSeriesPoint } from "@/components/activity-performance-chart";
import { RunSparklines, buildSparkPoints } from "@/components/run-sparklines";
import type { GarminActivitySummary, GarminGear, GarminHrZone, GarminLap } from "@/lib/garmin-types";
import { num, rec, str } from "@/lib/json";

const RunMap = dynamic(
  () => import("@/components/run-map").then((m) => m.RunMap),
  { ssr: false, loading: () => <div className="h-[300px] bg-muted animate-pulse rounded-lg" /> }
);

interface ActivityDetailModalProps {
  activityId: string | null;
  onClose: () => void;
}

function formatPace(speedMs: number) {
  if (!speedMs || speedMs <= 0) return "—";
  const paceMin = 1000 / speedMs / 60;
  const m = Math.floor(paceMin);
  const s = Math.round((paceMin - m) * 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

function formatDur(seconds: number) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.round(seconds % 60);
  if (h > 0) return `${h}h ${m}m`;
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export function ActivityDetailModal({ activityId, onClose }: ActivityDetailModalProps) {
  const [fetched, setData] = useState<Record<string, unknown> | null>(null);
  // Nothing is shown for a closed modal, so the effect never has to clear it.
  const data = activityId ? fetched : null;
  const [loading, setLoading] = useState(false);
  const [showBranding, setShowBranding] = useState(true);
  const [uploadState, setUploadState] = useState<"idle" | "uploading" | "done" | "error">("idle");
  const [uploadError, setUploadError] = useState<string | null>(null);

  async function handleStravaUpload() {
    if (!activityId) return;
    setUploadState("uploading");
    setUploadError(null);
    try {
      const resp = await fetch(`/api/activity/${activityId}/strava-photo`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ branding: showBranding }) });
      const json = await resp.json().catch(() => ({}));
      if (!resp.ok) {
        setUploadError((json as { error?: string }).error ?? "Upload failed");
        setUploadState("error");
      } else {
        setUploadState("done");
      }
    } catch {
      setUploadError("Network error");
      setUploadState("error");
    }
  }

  useEffect(() => {
    // Nothing selected: the modal shows nothing (derived below), so the effect just stops.
    if (!activityId) return;
    // eslint-disable-next-line react-hooks/set-state-in-effect -- fetch for the newly opened selection; the remaining setState calls run after the response.
    setLoading(true);
    setUploadState("idle");
    setUploadError(null);
    fetch(`/api/activity/${activityId}`)
      .then((r) => r.json())
      .then((d) => setData(d))
      .catch(() => setData(null))
      .finally(() => setLoading(false));
  }, [activityId]);

  // The route hands back the raw Garmin endpoints; each is read through its named shape.
  const summary = (data?.summary ?? {}) as GarminActivitySummary;
  const splits = data?.splits as { lapDTOs?: GarminLap[] } | undefined;
  const weather = rec(data?.weather);
  const hrZones = (Array.isArray(data?.hr_zones) ? data.hr_zones : []) as GarminHrZone[];
  const gear = data?.gear;

  const typeKey = summary.activityType?.typeKey || "";
  const isRunning = typeKey === "running" || typeKey === "treadmill_running";
  const isStrength = typeKey === "strength_training";

  const laps: GarminLap[] = splits?.lapDTOs ?? [];
  const hasLaps = laps.length > 0 && (laps[0]?.distance ?? 0) > 0;
  const shoeInfo = Array.isArray(gear) ? (gear as GarminGear[]).find((g) => g.gearTypeName === "Shoes") : null;
  const hasTimeSeries = isRunning && Array.isArray(data?.time_series) && data.time_series.length > 0;
  const gpsRoute = data?.gps_route ?? [];
  const hasGpsRoute = isRunning && Array.isArray(gpsRoute) && gpsRoute.length > 10;

  return (
    <Sheet open={!!activityId} onOpenChange={(open) => { if (!open) onClose(); }}>
      <SheetContent className="w-full sm:max-w-xl">
        <SheetHeader>
          <SheetTitle className="text-lg">
            {loading ? "Loading..." : summary?.activityName || "Activity"}
          </SheetTitle>
          {!!summary.startTimeLocal && (
            <div className="text-sm text-muted-foreground">
              {new Date(summary.startTimeLocal).toLocaleDateString("en-US", {
                weekday: "long",
                month: "long",
                day: "numeric",
                year: "numeric" })}
            </div>
          )}
        </SheetHeader>

        {loading && (
          <div className="flex items-center justify-center h-48 text-muted-foreground">
            Loading activity data...
          </div>
        )}

        {!loading && summary && (
          <Tabs defaultValue={hasGpsRoute ? "map" : "overview"} className="mt-4">
            <TabsList className="flex w-full h-11">
              {hasGpsRoute && <TabsTrigger value="map" className="flex-1 text-xs px-1">Map</TabsTrigger>}
              <TabsTrigger value="overview" className="flex-1 text-xs px-1">Overview</TabsTrigger>
              {hasTimeSeries && <TabsTrigger value="performance" className="flex-1 text-xs px-1">Charts</TabsTrigger>}
              {hasLaps ? <TabsTrigger value="splits" className="flex-1 text-xs px-1">Splits</TabsTrigger>
                       : <TabsTrigger value="splits" className="flex-1 text-xs px-1" disabled>Splits</TabsTrigger>}
              <TabsTrigger value="details" className="flex-1 text-xs px-1">Details</TabsTrigger>
              <TabsTrigger value="share" className="flex-1 text-xs px-1">Share</TabsTrigger>
            </TabsList>

            <div className="overflow-y-auto mt-2" style={{ maxHeight: "calc(100vh - 160px)" }}>
              {hasGpsRoute && (
                <TabsContent value="map" className="px-2 pb-6">
                  <RunMap points={gpsRoute} height={340} />
                  <div className="mt-3">
                    <RunSparklines points={buildSparkPoints(gpsRoute)} />
                  </div>
                </TabsContent>
              )}

              <TabsContent value="overview" className="space-y-4 px-4 pb-8">
                {/* Key Metrics Grid */}
                <div className="grid grid-cols-2 gap-3">
                  {(summary.distance ?? 0) > 0 && (
                    <MetricBox label="Distance" value={`${((summary.distance ?? 0) / 1000).toFixed(2)} km`} />
                  )}
                  <MetricBox label="Duration" value={formatDur(summary.duration ?? 0)} />
                  {isRunning && (summary.distance ?? 0) > 0 && (
                    <MetricBox
                      label="Avg Pace"
                      value={`${formatPace(summary.averageSpeed ?? 0)}/km`}
                    />
                  )}
                  {(summary.averageHR ?? 0) > 0 && (
                    <MetricBox label="Avg HR" value={`${Math.round(summary.averageHR ?? 0)} bpm`} />
                  )}
                  {(summary.maxHR ?? 0) > 0 && (
                    <MetricBox label="Max HR" value={`${Math.round(summary.maxHR ?? 0)} bpm`} />
                  )}
                  {(summary.calories ?? 0) > 0 && (
                    <MetricBox label="Calories" value={`${Math.round(summary.calories ?? 0)} kcal`} />
                  )}
                  {(summary.elevationGain ?? 0) > 0 && (
                    <MetricBox label="Elev Gain" value={`${Math.round(summary.elevationGain ?? 0)}m`} />
                  )}
                  {(summary.elevationLoss ?? 0) > 0 && (
                    <MetricBox label="Elev Loss" value={`${Math.round((summary.elevationLoss ?? 0))}m`} />
                  )}
                  {isRunning && (summary.averageRunningCadenceInStepsPerMinute ?? 0) > 0 && (
                    <MetricBox label="Cadence" value={`${Math.round(summary.averageRunningCadenceInStepsPerMinute ?? 0)} spm`} />
                  )}
                  {isRunning && (summary.avgStrideLength ?? 0) > 0 && (
                    <MetricBox label="Stride" value={`${Math.round((summary.avgStrideLength ?? 0))} cm`} />
                  )}
                  {(summary.vO2MaxValue ?? 0) > 0 && (
                    <MetricBox label="VO2max" value={`${Number(summary.vO2MaxValue).toFixed(1)}`} />
                  )}
                  {(summary.aerobicTrainingEffect ?? 0) > 0 && (
                    <MetricBox label="Aerobic TE" value={`${Number(summary.aerobicTrainingEffect).toFixed(1)}`} />
                  )}
                  {!isRunning && !isStrength && (summary.maxSpeed ?? 0) > 0 && (
                    <MetricBox
                      label="Max Speed"
                      value={
                        typeKey.includes("kite")
                          ? `${((summary.maxSpeed ?? 0) * 1.94384).toFixed(1)} kts`
                          : `${((summary.maxSpeed ?? 0) * 3.6).toFixed(1)} km/h`
                      }
                    />
                  )}
                </div>

                {/* HR Zones */}
                {hrZones.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">HR Zones</h4>
                    {hrZones.map((z) => {
                      const totalSecs = hrZones.reduce((s: number, zz) => s + (zz.secsInZone || 0), 0);
                      const pct = totalSecs > 0 ? ((z.secsInZone || 0) / totalSecs) * 100 : 0;
                      const colors = ["bg-slate-400", "bg-blue-400", "bg-green-400", "bg-orange-400", "bg-red-400"];
                      return (
                        <div key={String(z.zoneNumber)} className="flex items-center gap-2 text-xs">
                          <span className="w-8 text-muted-foreground">Z{z.zoneNumber}</span>
                          <div className="flex-1 h-3 bg-muted rounded-full overflow-hidden">
                            <div
                              className={`h-full ${colors[(z.zoneNumber ?? 1) - 1] || "bg-primary"} rounded-full`}
                              style={{ width: `${pct}%` }}
                            />
                          </div>
                          <span className="w-12 text-right">{formatDur(z.secsInZone || 0)}</span>
                          <span className="w-8 text-right text-muted-foreground">{pct.toFixed(0)}%</span>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Weather */}
                {num(weather?.temp) != null && (
                  <div className="space-y-2">
                    <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Weather</h4>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <span className="text-muted-foreground">Temp: </span>
                        {Math.round(((num(weather?.temp) ?? 0) - 32) * 5 / 9)}°C
                      </div>
                      {!!num(weather?.relativeHumidity) && (
                        <div>
                          <span className="text-muted-foreground">Humidity: </span>
                          {num(weather?.relativeHumidity)}%
                        </div>
                      )}
                      {(num(weather?.windSpeed) ?? 0) > 0 && (
                        <div>
                          <span className="text-muted-foreground">Wind: </span>
                          {typeKey.includes("kite") || typeKey.includes("wind")
                            ? `${((num(weather?.windSpeed) ?? 0) * 0.868976).toFixed(1)} kts`
                            : `${num(weather?.windSpeed)} mph`}
                          {!!str(weather?.windDirectionCompassPoint) && ` ${String(weather?.windDirectionCompassPoint).toUpperCase()}`}
                        </div>
                      )}
                      {!!str(rec(weather?.weatherTypeDTO)?.desc) && (
                        <div>
                          <span className="text-muted-foreground">Condition: </span>
                          {str(rec(weather?.weatherTypeDTO)?.desc)}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Gear Info */}
                {shoeInfo && (
                  <div className="space-y-2">
                    <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Gear</h4>
                    <div className="flex items-center gap-3 p-2.5 bg-muted/30 rounded-lg">
                      <span className="text-lg">👟</span>
                      <div>
                        <div className="text-sm font-medium">
                          {shoeInfo.customMakeModel || shoeInfo.displayName || "Unknown Shoe"}
                        </div>
                        {(shoeInfo.maximumMeters ?? 0) > 0 && (
                          <div className="text-xs text-muted-foreground">
                            {Math.round((shoeInfo.maximumMeters ?? 0) / 1000)} km max life
                            <span className={`ml-2 ${shoeInfo.gearStatusName === "active" ? "text-green-400" : "text-muted-foreground"}`}>
                              {shoeInfo.gearStatusName}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* Running Dynamics Summary */}
                {isRunning && (summary.avgGroundContactTime ?? 0) > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Running Dynamics</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {(summary.avgGroundContactTime ?? 0) > 0 && (
                        <MetricBox label="Ground Contact" value={`${Math.round((summary.avgGroundContactTime ?? 0))} ms`} />
                      )}
                      {(summary.avgVerticalOscillation ?? 0) > 0 && (
                        <MetricBox label="Vert Oscillation" value={`${Number((summary.avgVerticalOscillation ?? 0)).toFixed(1)} cm`} />
                      )}
                      {(summary.avgVerticalRatio ?? 0) > 0 && (
                        <MetricBox label="Vert Ratio" value={`${Number((summary.avgVerticalRatio ?? 0)).toFixed(1)}%`} />
                      )}
                      {(summary.averagePower ?? 0) > 0 && (
                        <MetricBox label="Avg Power" value={`${Math.round((summary.averagePower ?? 0))} W`} />
                      )}
                    </div>
                  </div>
                )}
              </TabsContent>

              {hasTimeSeries && (
                <TabsContent value="performance" className="px-4 pb-8">
                  <ActivityPerformanceChart timeSeries={(data?.time_series ?? []) as TimeSeriesPoint[]} />
                </TabsContent>
              )}

              <TabsContent value="splits" className="px-4 pb-8">
                {hasLaps && (
                  <div className="space-y-4">
                    {/* Visual pace bars */}
                    {isRunning && (() => {
                      const paceData = laps
                        .filter((l) => (l.averageSpeed ?? 0) > 0 && (l.distance ?? 0) > 0)
                        .map((l) => ({
                          pace: 1000 / (l.averageSpeed ?? 0) / 60,
                          hr: (l.averageHR ?? 0) }));
                      if (paceData.length < 2) return null;
                      const minPace = Math.min(...paceData.map((p) => p.pace));
                      const maxPace = Math.max(...paceData.map((p) => p.pace));
                      const range = maxPace - minPace || 1;
                      const avgPace = paceData.reduce((s: number, p) => s + p.pace, 0) / paceData.length;
                      return (
                        <div className="space-y-1">
                          <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
                            <span>Pace per Split</span>
                            <span>avg {formatPace(avgPace * 60)}/km</span>
                          </div>
                          <div className="flex items-end gap-[3px] h-24">
                            {paceData.map((p, i: number) => {
                              const normalized = 1 - (p.pace - minPace) / range;
                              const h = 20 + normalized * 80;
                              const isFast = p.pace < avgPace * 0.97;
                              const isSlow = p.pace > avgPace * 1.03;
                              return (
                                <div
                                  key={i}
                                  className={`flex-1 rounded-t-sm ${
                                    isFast ? "bg-green-500/70" : isSlow ? "bg-red-500/50" : "bg-primary/50"
                                  }`}
                                  style={{ height: `${h}%` }}
                                  title={`Split ${i + 1}: ${formatPace(p.pace * 60)}/km`}
                                />
                              );
                            })}
                          </div>
                          <div className="flex justify-between text-[9px] text-muted-foreground">
                            <span>{formatPace(minPace * 60)}/km</span>
                            <span>{formatPace(maxPace * 60)}/km</span>
                          </div>
                        </div>
                      );
                    })()}

                    {/* Card-based splits */}
                    {(() => {
                      const paces = laps
                        .filter((l) => (l.averageSpeed ?? 0) > 0 && (l.distance ?? 0) > 0)
                        .map((l) => 1000 / (l.averageSpeed ?? 1) / 60);
                      const avgPace = paces.length > 0
                        ? paces.reduce((s: number, p: number) => s + p, 0) / paces.length
                        : 0;

                      return (
                        <>
                          {/* Column headers */}
                          <div className="flex items-center gap-3 pb-1.5 border-b border-border/50 text-[10px] text-muted-foreground uppercase tracking-wider">
                            <div className="w-7 text-center shrink-0">#</div>
                            <div className="flex-1 grid grid-cols-4 gap-x-3">
                              <div>Dist</div>
                              <div>Pace</div>
                              <div>HR</div>
                              <div>Time</div>
                            </div>
                            <div className="w-16 text-right shrink-0">More</div>
                          </div>

                          <div className="space-y-0">
                            {laps.map((lap, i: number) => {
                              const pace = (lap.averageSpeed ?? 0) > 0 ? formatPace((lap.averageSpeed ?? 0)) : "—";
                              const paceVal = (lap.averageSpeed ?? 0) > 0 ? 1000 / (lap.averageSpeed ?? 0) / 60 : 0;
                              const isFast = paceVal > 0 && avgPace > 0 && paceVal < avgPace * 0.97;
                              const isSlow = paceVal > 0 && avgPace > 0 && paceVal > avgPace * 1.03;
                              const paceColor = isFast ? "text-green-400" : isSlow ? "text-red-400" : "text-foreground";
                              const distKm = (lap.distance ?? 0) > 0 ? ((lap.distance ?? 0) / 1000) : 0;

                              return (
                                <div key={i} className="flex items-center gap-3 py-2.5 border-b border-border/30 hover:bg-accent/10 -mx-2 px-2 rounded transition-colors">
                                  {/* Split number */}
                                  <div className="w-7 text-center shrink-0">
                                    <span className="text-[1rem] font-bold">{i + 1}</span>
                                  </div>

                                  {/* Main metrics */}
                                  <div className="flex-1 grid grid-cols-4 gap-x-3">
                                    <div>
                                      <div className="text-sm font-medium">
                                        {distKm > 0 ? `${distKm.toFixed(2)}` : "—"}
                                        {distKm > 0 && <span className="text-[10px] text-muted-foreground ml-0.5">km</span>}
                                      </div>
                                    </div>
                                    <div>
                                      <div className={`text-sm font-bold ${paceColor}`}>{pace}/km</div>
                                    </div>
                                    <div>
                                      <div className="text-sm font-medium">
                                        {(lap.averageHR ?? 0) > 0 ? `${Math.round((lap.averageHR ?? 0))}` : "—"}
                                        {(lap.averageHR ?? 0) > 0 && <span className="text-[10px] text-muted-foreground ml-0.5">bpm</span>}
                                      </div>
                                    </div>
                                    <div>
                                      <div className="text-sm text-muted-foreground">
                                        {(lap.duration ?? 0) > 0 ? formatDur((lap.duration ?? 0)) : "—"}
                                      </div>
                                    </div>
                                  </div>

                                  {/* Optional secondary metrics (elevation, cadence) shown small */}
                                  <div className="w-16 text-right shrink-0 space-y-0.5">
                                    {(lap.elevationGain ?? 0) > 0 && (
                                      <div className="text-[10px] text-muted-foreground">+{Math.round((lap.elevationGain ?? 0))}m</div>
                                    )}
                                    {(lap.averageRunCadence ?? 0) > 0 && (
                                      <div className="text-[10px] text-muted-foreground">{Math.round((lap.averageRunCadence ?? 0))} spm</div>
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                          </div>

                          {/* Summary footer */}
                          <div className="flex items-center justify-between pt-3 mt-2 border-t border-border">
                            <div className="text-xs text-muted-foreground">{laps.length} splits</div>
                            <div className="flex gap-4 text-xs">
                              <span className="font-medium">{(summary.averageSpeed ?? 0) > 0 ? `${formatPace(summary.averageSpeed ?? 0)}/km avg` : ""}</span>
                              <span className="text-muted-foreground">{(summary.averageHR ?? 0) > 0 ? `${Math.round(summary.averageHR ?? 0)} bpm avg` : ""}</span>
                              <span className="text-muted-foreground">{(summary.duration ?? 0) > 0 ? formatDur(summary.duration ?? 0) : ""}</span>
                            </div>
                          </div>
                        </>
                      );
                    })()}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="share" className="px-4 pb-8">
                {activityId && (
                  <div className="space-y-3">
                    {/* Branding toggle */}
                    <label className="flex items-center gap-2 text-xs text-muted-foreground cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={showBranding}
                        onChange={(e) => setShowBranding(e.target.checked)}
                        className="rounded"
                      />
                      Show branding
                    </label>

                    {/* Image preview */}
                    <div className="relative rounded-lg overflow-hidden border border-border/50 bg-black">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={`/api/activity/${activityId}/image?branding=${showBranding ? "1" : "0"}`}
                        alt={`${summary?.activityName || "Activity"} summary`}
                        className="w-full h-auto"
                        loading="eager"
                      />
                    </div>

                    {/* Download */}
                    <a
                      href={`/api/activity/${activityId}/image?branding=${showBranding ? "1" : "0"}`}
                      download={`${(summary?.activityName || "activity").replace(/\s+/g, "-").toLowerCase()}.png`}
                      className="flex items-center justify-center gap-1.5 w-full py-2 rounded-md text-xs font-medium border border-border bg-muted/50 hover:bg-accent/50 transition-colors"
                    >
                      <Download className="h-3.5 w-3.5" />
                      Download PNG
                    </a>

                    {/* Upload to Strava */}
                    <div className="space-y-1.5">
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full gap-1.5 text-xs"
                        disabled={!data?.strava_id || uploadState === "uploading" || uploadState === "done"}
                        onClick={handleStravaUpload}
                        title={!data?.strava_id ? "Sync this activity to Strava first" : undefined}
                      >
                        {uploadState === "uploading" && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
                        {uploadState === "done" && <Check className="h-3.5 w-3.5 text-green-500" />}
                        {uploadState !== "uploading" && uploadState !== "done" && <Upload className="h-3.5 w-3.5" />}
                        {uploadState === "uploading" ? "Uploading…" : uploadState === "done" ? "Uploaded to Strava" : "Upload to Strava"}
                      </Button>
                      {!data?.strava_id && (
                        <p className="text-[11px] text-muted-foreground/60 text-center">
                          Sync to Strava first from the Connections page
                        </p>
                      )}
                      {uploadState === "error" && uploadError && (
                        <p className="text-[11px] text-destructive text-center">{uploadError}</p>
                      )}
                    </div>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="details" className="space-y-4 px-4 pb-8">
                {/* All raw summary fields */}
                <div className="space-y-1">
                  {Object.entries(summary)
                    .filter(([k, v]) =>
                      v !== null && v !== 0 && v !== "" &&
                      typeof v !== "object" &&
                      !["activityUUID", "userProfilePK", "deviceId"].includes(k)
                    )
                    .sort(([a], [b]) => a.localeCompare(b))
                    .map(([key, value]) => (
                      <div key={key} className="flex items-center justify-between text-xs py-0.5">
                        <span className="text-muted-foreground truncate mr-2">
                          {key.replace(/([A-Z])/g, " $1").trim()}
                        </span>
                        <span className="font-mono shrink-0">
                          {typeof value === "number" ? Number(value).toFixed(2) : String(value)}
                        </span>
                      </div>
                    ))}
                </div>
              </TabsContent>
            </div>
          </Tabs>
        )}
      </SheetContent>
    </Sheet>
  );
}

function MetricBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="border border-border/50 rounded-lg p-3">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="text-lg font-bold mt-0.5">{value}</div>
    </div>
  );
}
