// web/components/playlist-builder.tsx
"use client";
import { useState, useRef, useEffect, useMemo } from "react";
import { toast } from "sonner";
import PlaylistTopBar from "./playlist-top-bar";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import RunSegmentTimeline from "./run-segment-timeline";
import SongAssignmentPanel from "./song-assignment-panel";
import SpotifyPlayer from "./spotify-player";
import PlaylistRunSelector from "./playlist-run-selector";
import PumpUpModal from "./pump-up-modal";
import { Segment, SegmentItem, RepeatGroup } from "./segment-editor";
import { flatItems } from "./run-segment-timeline";
import { SongData } from "./song-card";
import { useUndoRedo } from "@/hooks/use-undo-redo";
import { nanoid } from "nanoid";
import { parsedToItems as parsedToItemsWithIds, segsForGenerate as segsForGenerateWithIds, type ParsedStep } from "run-dj/segments";

// Parsed steps to segments and the song-pool bundling are run-dj's segments module, with nanoid ids.
const parsedToItems = (parsed: ParsedStep[]): SegmentItem[] => parsedToItemsWithIds(parsed, nanoid);
const segsForGenerate = (items: SegmentItem[]) => segsForGenerateWithIds(items, nanoid);

interface SegmentSongs { songs: SongData[]; loading?: boolean; poolCount?: number; warning?: string; }

export default function PlaylistBuilder() {
  const [items, setItems, undo, redo] = useUndoRedo<SegmentItem[]>([]);
  const [assignments, setAssignments] = useState<Record<number, SegmentSongs>>({});
  const [excludedIds, setExcludedIds] = useState<Set<string>>(new Set());
  const [focusedIdx, setFocusedIdx] = useState(-1);
  const [sources, setSources] = useState<string[]>(["liked"]);
  const [genres, setGenres] = useState<string[]>([]);
  const [genreThreshold, setGenreThreshold] = useState(0.03);
  const [previewSong, setPreviewSong] = useState<SongData | null>(null);
  const [saving, setSaving] = useState(false);
  const [savedUrl, setSavedUrl] = useState<string | undefined>();
  const [sessionId, setSessionId] = useState<number | null>(null);
  const [workoutName, setWorkoutName] = useState<string | undefined>();
  const [hasRun, setHasRun] = useState(false);
  const [pumpUpModalOpen, setPumpUpModalOpen] = useState(false);
  const [pumpUpBankKey, setPumpUpBankKey] = useState(0);
  // Tracks the Spotify playlist ID from a loaded session — if set, Save → Update (PUT)
  const [existingPlaylistId, setExistingPlaylistId] = useState<string | null>(null);
  const [shortcutsOpen, setShortcutsOpen] = useState(false);
  const [changeRunConfirm, setChangeRunConfirm] = useState(false);
  const [skipBannerDismissed, setSkipBannerDismissed] = useState(() =>
    typeof window !== "undefined" && !!localStorage.getItem("soma_skip_banner_dismissed")
  );
  const garminActivityIdRef = useRef<string | null>(null);
  // Refs for stale-closure-safe keyboard handlers
  const itemsRef = useRef(items);
  useEffect(() => { itemsRef.current = items; }, [items]);
  const focusedIdxRef = useRef(focusedIdx);
  useEffect(() => { focusedIdxRef.current = focusedIdx; }, [focusedIdx]);

  const leftRef = useRef<HTMLDivElement>(null);
  const rightRef = useRef<HTMLDivElement>(null);
  const syncingRef = useRef(false);
  const abortRef = useRef<AbortController | null>(null);
  const generateDebounceRef = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  // Per-segment abort controllers — keyed by flat index, so rapid "Widen BPM" clicks
  // cancel the previous SSE call for the same segment rather than racing.
  const segmentAbortRefs = useRef<Map<number, AbortController>>(new Map());

  // Global keyboard shortcuts
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const tag = (e.target as HTMLElement)?.tagName;
      const inInput = tag === "INPUT" || tag === "TEXTAREA" || (e.target as HTMLElement)?.isContentEditable;
      if (inInput) return; // don't intercept text fields

      if ((e.ctrlKey || e.metaKey) && e.key === "z" && !e.shiftKey) {
        e.preventDefault();
        undo();
      } else if ((e.ctrlKey || e.metaKey) && (e.key === "y" || (e.key === "z" && e.shiftKey))) {
        e.preventDefault();
        redo();
      } else if (e.key === "Escape") {
        setFocusedIdx(-1);
        setShortcutsOpen(false);
      } else if (e.key === "?") {
        setShortcutsOpen(v => !v);
      } else if (e.key === "j" && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        const total = flatItems(itemsRef.current).length;
        if (total > 0) setFocusedIdx(prev => (prev === -1 ? 0 : Math.min(prev + 1, total - 1)));
      } else if (e.key === "k" && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        const total = flatItems(itemsRef.current).length;
        if (total > 0) setFocusedIdx(prev => (prev <= 0 ? 0 : prev - 1));
      } else if (e.key === "r" && !e.ctrlKey && !e.metaKey && focusedIdxRef.current !== -1) {
        e.preventDefault();
        void generateSegmentOnly(focusedIdxRef.current, undefined, itemsRef.current);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [undo, redo]); // eslint-disable-line react-hooks/exhaustive-deps

  // Scroll sync between panels
  useEffect(() => {
    const left = leftRef.current;
    const right = rightRef.current;
    if (!left || !right) return;
    const syncLeft = () => { if (syncingRef.current) return; syncingRef.current = true; right.scrollTop = left.scrollTop; syncingRef.current = false; };
    const syncRight = () => { if (syncingRef.current) return; syncingRef.current = true; left.scrollTop = right.scrollTop; syncingRef.current = false; };
    left.addEventListener("scroll", syncLeft);
    right.addEventListener("scroll", syncRight);
    return () => { left.removeEventListener("scroll", syncLeft); right.removeEventListener("scroll", syncRight); };
  }, []);

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  function handleRunSelect(run: { type: "garmin" | "plan" | "session"; data: any; segments: any[] }) {
    if (run.type === "session") {
      const garminId = run.data?.garmin_activity_id ?? null;
      const songAssignments = run.data?.song_assignments ?? {};
      const hasAssignments = Object.keys(songAssignments).length > 0;

      if (hasAssignments && garminId) {
        // Restore session: fetch timeline segments, restore stored song assignments
        fetch(`/api/playlist/garmin-runs?id=${garminId}`)
          .then(r => r.json())
          .then(data => {
            const newItems = parsedToItems(data.segments ?? []);
            if (!newItems.length) return;
            const restoredAssignments: Record<number, SegmentSongs> = {};
            for (const [k, v] of Object.entries(songAssignments as Record<string, SongData[]>)) {
              restoredAssignments[Number(k)] = { songs: v as SongData[] };
            }
            garminActivityIdRef.current = garminId;
            setItems(newItems);
            setAssignments(restoredAssignments);
            setSessionId(run.data.id);
            setWorkoutName(data.activity_name ?? "Run");
            setHasRun(true);
            // If this session was previously saved to Spotify, offer to Update instead of Create
            setExistingPlaylistId(run.data.spotify_playlist_id ?? null);
            setSavedUrl(run.data.spotify_playlist_url ?? undefined);
          })
          .catch(() => {});
        return;
      }

      // No stored assignments or no garmin ID — re-generate
      if (!garminId) {
        toast.error("This session can't be restored — no run was linked to it");
        return;
      }
      fetch(`/api/playlist/garmin-runs?id=${garminId}`)
        .then(r => r.json())
        .then(data => {
          const newItems = parsedToItems(data.segments ?? []);
          if (!newItems.length) return;
          garminActivityIdRef.current = garminId;
          setItems(newItems);
          setWorkoutName(data.activity_name ?? "Run");
          setHasRun(true);
          setExistingPlaylistId(null);
          abortRef.current?.abort();
          abortRef.current = new AbortController();
          void generate(segsForGenerate(newItems), abortRef.current.signal);
        })
        .catch(() => {});
      return;
    }

    if (run.segments?.length > 0) {
      const newItems = parsedToItems(run.segments);
      garminActivityIdRef.current = run.type === "garmin" ? (run.data?.activity_id ?? null) : null;
      setItems(newItems);
      setWorkoutName(run.data?.activity_name ?? run.data?.name ?? "Run");
      setHasRun(true);
      setExistingPlaylistId(null);
      abortRef.current?.abort();
      abortRef.current = new AbortController();
      void generate(segsForGenerate(newItems), abortRef.current.signal);
    }
  }

  // Generate playlist via SSE — collapses short repeat groups via segsForGenerate
  async function generate({ segments: segs, flatIndexMap }: { segments: Segment[]; flatIndexMap: number[][] }, signal?: AbortSignal) {
    const flatCount = flatIndexMap.flat().length;
    setAssignments(Object.fromEntries(Array.from({ length: flatCount }, (_, i) => [i, { songs: [], loading: true }])));
    setSavedUrl(undefined);
    setSessionId(null);
    try {
      const res = await fetch("/api/playlist/sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ segments: segs, excluded_track_ids: Array.from(excludedIds), genre_selection: genres, genre_threshold: genreThreshold, source_playlist_ids: sources, garmin_activity_id: garminActivityIdRef.current }),
        signal });
      if (!res.body) return;
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          try {
            const event = JSON.parse(line.slice(6));
            if (event.type === "segment_done") {
              // Spread songs to all flat panel indices mapped from this API segment index
              const flatIndices = flatIndexMap[event.index] ?? [event.index];
              setAssignments(prev => {
                const next = { ...prev };
                for (const fi of flatIndices) {
                  next[fi] = { songs: event.songs, loading: false, poolCount: event.pool_count, warning: undefined };
                }
                return next;
              });
            } else if (event.type === "segment_warning") {
              const flatIndices = flatIndexMap[event.index] ?? [event.index];
              setAssignments(prev => {
                const next = { ...prev };
                for (const fi of flatIndices) {
                  next[fi] = { ...next[fi], warning: event.message };
                }
                return next;
              });
            } else if (event.type === "done") {
              setSessionId(event.session_id);
            } else if (event.type === "error") {
              console.error("Playlist generation error:", event.message);
              setAssignments(prev => {
                const next = { ...prev };
                for (const k in next) {
                  if (next[k].loading) next[k] = { ...next[k], loading: false, warning: "Generation failed" };
                }
                return next;
              });
            }
          } catch (err) {
            console.error("SSE parse error:", err);
          }
        }
      }
    } catch (err: unknown) {
      if (err instanceof Error && err.name === "AbortError") return; // Ignore cancellation
      console.error("Generate failed:", err);
      setAssignments(prev => {
        const next = { ...prev };
        for (const k in next) {
          if (next[k].loading) next[k] = { ...next[k], loading: false, warning: "Generation failed" };
        }
        return next;
      });
    }
  }

  // Per-segment regeneration: runs the SSE API for a single segment only.
  // Does NOT reset other assignments — only marks the targeted flat indices as loading.
  async function generateSegmentOnly(flatIdx: number, toleranceOverride?: number, currentItems?: SegmentItem[], excludedOverride?: Set<string>) {
    const { segments: allSegs, flatIndexMap } = segsForGenerate(currentItems ?? items);
    const apiIdx = flatIndexMap.findIndex(indices => indices.includes(flatIdx));
    if (apiIdx === -1) return;

    const flatIndices = flatIndexMap[apiIdx];
    const seg = allSegs[apiIdx];
    const segWithOverride = toleranceOverride !== undefined
      ? { ...seg, bpm_tolerance: toleranceOverride }
      : seg;

    // Cancel any previous per-segment call for this flat index (rapid Widen BPM clicks)
    segmentAbortRefs.current.get(flatIdx)?.abort();
    const ac = new AbortController();
    segmentAbortRefs.current.set(flatIdx, ac);

    // Mark only the targeted flat indices as loading
    setAssignments(prev => {
      const next = { ...prev };
      for (const fi of flatIndices) {
        next[fi] = { ...next[fi], loading: true };
      }
      return next;
    });

    try {
      const res = await fetch("/api/playlist/sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          segments: [segWithOverride],
          excluded_track_ids: Array.from(excludedOverride ?? excludedIds),
          genre_selection: genres,
          genre_threshold: genreThreshold,
          source_playlist_ids: sources,
          garmin_activity_id: garminActivityIdRef.current }),
        signal: ac.signal });
      if (!res.body) return;
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          try {
            const event = JSON.parse(line.slice(6));
            if (event.type === "segment_done") {
              // event.index is 0 (only one segment sent) — map to the real flat indices
              setAssignments(prev => {
                const next = { ...prev };
                for (const fi of flatIndices) {
                  next[fi] = { songs: event.songs, loading: false, poolCount: event.pool_count, warning: undefined };
                }
                return next;
              });
            } else if (event.type === "segment_warning") {
              setAssignments(prev => {
                const next = { ...prev };
                for (const fi of flatIndices) {
                  next[fi] = { ...next[fi], warning: event.message };
                }
                return next;
              });
            } else if (event.type === "error") {
              console.error("Segment regeneration error:", event.message);
              setAssignments(prev => {
                const next = { ...prev };
                for (const fi of flatIndices) {
                  if (next[fi]?.loading) next[fi] = { ...next[fi], loading: false, warning: "Generation failed" };
                }
                return next;
              });
            }
          } catch (err) {
            console.error("SSE parse error:", err);
          }
        }
      }
    } catch (err: unknown) {
      if (err instanceof Error && err.name === "AbortError") return;
      console.error("Segment regeneration failed:", err);
      setAssignments(prev => {
        const next = { ...prev };
        for (const fi of flatIndices) {
          if (next[fi]?.loading) next[fi] = { ...next[fi], loading: false, warning: "Generation failed" };
        }
        return next;
      });
    }
  }

  function handleWidenBpm(flatIdx: number) {
    // Persist the updated bpm_tolerance in items state, then regenerate only that segment.
    // Compute newTolerance once and pass as an absolute override to avoid double-adding
    // (generateSegmentOnly reads items from closure which hasn't updated yet).
    const flat = flatItems(items);
    const seg = flat[flatIdx];
    if (!seg) return;
    const newTolerance = Math.min(seg.bpm_tolerance + 15, 30);
    setItems(items.map(item => {
      if (item.type === "repeat") {
        const group = item as RepeatGroup;
        return { ...group, children: group.children.map(child =>
          (child as Segment).id === seg.id ? { ...child, bpm_tolerance: newTolerance } : child
        )};
      }
      const s = item as Segment;
      return s.id === seg.id ? { ...s, bpm_tolerance: newTolerance } : s;
    }));
    void generateSegmentOnly(flatIdx, newTolerance);
  }

  async function handleSave() {
    if (!sessionId) { toast.error("Generation not complete — wait for all songs to load"); return; }
    setSaving(true);
    const allTracks = [...new Set(Object.values(assignments).flatMap(a => a.songs.filter(s => !excludedIds.has(s.track_id)).map(s => s.track_id)))];
    try {
      if (existingPlaylistId) {
        // Update existing Spotify playlist (replace tracks in-place)
        const res = await fetch("/api/playlist/spotify/create", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            playlist_id: existingPlaylistId,
            session_id: sessionId,
            track_ids: allTracks,
            song_assignments: Object.fromEntries(
              Object.entries(assignments).map(([k, v]) => [k, v.songs])
            ) }) });
        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error((errData as { error?: string }).error ?? "Update failed");
        }
        const data = await res.json();
        setSavedUrl(data.playlist_url);
      } else {
        const name = `Soma: ${workoutName ?? "Run"} · ${new Date().toLocaleDateString()}`;
        const res = await fetch("/api/playlist/spotify/create", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            session_id: sessionId,
            name,
            track_ids: allTracks,
            song_assignments: Object.fromEntries(
              Object.entries(assignments).map(([k, v]) => [k, v.songs])
            ) }) });
        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error((errData as { error?: string }).error ?? "Save failed");
        }
        const data = await res.json();
        setSavedUrl(data.playlist_url);
        setExistingPlaylistId(data.playlist_id ?? null);
      }
    } catch (err) {
      toast.error("Failed to save to Spotify", { description: err instanceof Error ? err.message : "Check your Spotify connection in Sources" });
    } finally {
      setSaving(false);
    }
  }

  function handleExclude(segIdx: number, trackId: string) {
    const isExcluding = !excludedIds.has(trackId);
    const newExcluded = new Set(excludedIds);
    if (isExcluding) { newExcluded.add(trackId); } else { newExcluded.delete(trackId); }
    setExcludedIds(newExcluded);
    if (!isExcluding) return; // restoring — nothing more to do

    // Remove the song from ALL segment assignments locally (no SSE regeneration)
    setAssignments(prev => {
      const next: typeof prev = {};
      for (const k of Object.keys(prev)) {
        const n = Number(k);
        next[n] = { ...prev[n], songs: prev[n].songs.filter(s => s.track_id !== trackId) };
      }
      return next;
    });

    // Find the song name/artist for the toast message
    const song = Object.values(assignments).flatMap(a => a.songs).find(s => s.track_id === trackId);
    const songName = song?.name ?? "This song";
    const artistName = song?.artist_name ?? "";

    fetch("/api/playlist/blacklist", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ track_id: trackId }) })
      .then(r => r.json())
      .then((data: { count: number }) => {
        if (data.count >= 3) {
          toast(`${songName} — ${artistName}`, {
            description: "You've excluded this 3 times",
            action: {
              label: "Never suggest",
              onClick: () => {
                void fetch("/api/playlist/blacklist/confirm", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ track_id: trackId, name: songName, artist_name: artistName }) })
                  .then(r => {
                    if (r.ok) toast.success("Permanently blocked — won't appear again");
                    else toast.error("Failed to block song");
                  })
                  .catch(() => { toast.error("Failed to block song"); });
              } },
            duration: 8000 });
        }
      })
      .catch(() => {});
  }

  async function handlePumpUp(flatIdx: number) {
    // Capture current state before the async gap to avoid stale closure issues
    const currentAssignments = assignments;
    const currentExcludedIds = excludedIds;

    const bankSongs: { track_id: string; name: string; artist_name: string; tempo: number | null; energy: number | null; duration_ms: number }[] =
      await fetch("/api/playlist/pump-up").then(r => r.json()).catch(() => []);

    if (!bankSongs.length) {
      toast("Pump-up bank is empty", {
        description: "Add songs by clicking ⚡ on any song card",
        duration: 4000 });
      return;
    }
    // Collect all currently placed track IDs across all segments
    const allPlacedIds = new Set(
      Object.values(currentAssignments).flatMap(a => a.songs.map(s => s.track_id))
    );
    // Find first bank song not already placed and not excluded
    const song = bankSongs.find((s: { track_id: string }) => !allPlacedIds.has(s.track_id) && !currentExcludedIds.has(s.track_id));
    if (!song) {
      toast("No bank songs available", {
        description: "All pump-up songs are already placed or excluded in this playlist",
        duration: 4000 });
      return;
    }
    // Inject pump-up song before skip song, after other placed songs
    setAssignments(prev => {
      const existing = prev[flatIdx]?.songs ?? [];
      const nonSkip = existing.filter(s => !s.is_skip);
      const skip = existing.filter(s => s.is_skip);
      const pumpSong: SongData = {
        track_id: song.track_id,
        name: song.name,
        artist_name: song.artist_name,
        tempo: song.tempo ?? 0,
        energy: song.energy ?? 0,
        duration_ms: song.duration_ms ?? 0,
        is_skip: false };
      return { ...prev, [flatIdx]: { ...prev[flatIdx], songs: [...nonSkip, pumpSong, ...skip] } };
    });
    toast.success(`Added "${song.name}"`, { description: song.artist_name, duration: 3000 });
  }

  // Derive has_genre_warning for placed songs: true when a genre filter is active and
  // the song's genres don't intersect the selected genres (placed before filter changed).
  const assignmentsWithWarnings = useMemo(() => {
    if (genres.length === 0) return assignments;
    const result: Record<number, typeof assignments[number]> = {};
    for (const [k, v] of Object.entries(assignments)) {
      result[Number(k)] = {
        ...v,
        songs: v.songs.map(song => ({
          ...song,
          has_genre_warning: !!song.genres?.length && !song.genres.some(g => genres.includes(g)) })) };
    }
    return result;
  }, [assignments, genres]);

  function handleReplace(segIdx: number, targetTrackId: string, newSong: SongData) {
    setAssignments(prev => {
      const entry = prev[segIdx];
      if (!entry) return prev;
      return {
        ...prev,
        [segIdx]: { ...entry, songs: entry.songs.map(s => s.track_id === targetTrackId ? { ...newSong, is_skip: s.is_skip } : s) } };
    });
  }

  function resetRun() {
    abortRef.current?.abort();
    garminActivityIdRef.current = null;
    setHasRun(false);
    setItems([]);
    setAssignments({});
    setWorkoutName(undefined);
    setExistingPlaylistId(null);
    setSavedUrl(undefined);
  }

  const hasSongsPlaced = Object.values(assignments).some(a => a.songs.length > 0);

  return (
    <div className="flex flex-col h-full">
      <PlaylistTopBar sources={sources} onSourcesChange={setSources} genres={genres} onGenresChange={setGenres} genreThreshold={genreThreshold} onThresholdChange={setGenreThreshold} workoutName={workoutName} onChangeRun={() => { if (hasSongsPlaced) { setChangeRunConfirm(true); } else { resetRun(); } }} onOpenBank={() => setPumpUpModalOpen(true)} onOpenShortcuts={() => setShortcutsOpen(true)} />
      <div className="flex flex-col lg:flex-row flex-1 overflow-hidden">
        {/* Left: run selector (first time) or run timeline. Full-width stacked on
            mobile — the desktop w-[40%] crushed it to ~150px on a phone. */}
        <div ref={leftRef} className="w-full lg:w-[40%] border-b lg:border-b-0 lg:border-r overflow-y-auto">
          {!hasRun ? (
            <div className="h-full flex flex-col">
              <div className="px-3 py-2 border-b text-xs font-medium text-muted-foreground">Select a run to get started</div>
              <div className="flex-1 overflow-hidden">
                <PlaylistRunSelector onSelect={handleRunSelect} />
              </div>
            </div>
          ) : (
            <RunSegmentTimeline
              items={items}
              onSavePlan={async (name) => {
                // Store template-only hierarchical format (strip IDs)
                function serializeItems(its: SegmentItem[]) {
                  return its.map(it => {
                    if (it.type === "repeat") {
                      const { id: _id, children, ...rest } = it;
                      return { ...rest, children: children.slice(0, it.template_size).map(({ id: _cid, ...cr }) => cr) };
                    }
                    const { id: _id, ...rest } = it as Segment;
                    return rest;
                  });
                }
                const flat = flatItems(items);
                const res = await fetch("/api/playlist/workout-plans", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    name,
                    segments: serializeItems(items),
                    sport_type: "running",
                    total_duration_s: flat.reduce((s, seg) => s + seg.duration_s, 0),
                    source: "builder",
                    garmin_activity_id: garminActivityIdRef.current }) });
                if (!res.ok) throw new Error("Server error saving plan");
              }}
              onChange={(newItems) => {
                const oldFlat = flatItems(items);
                const newFlat = flatItems(newItems);
                setItems(newItems);
                if (newFlat.length === 0) return;

                // Detect structural change: segments added, removed, or reordered
                // (reorder changes flat-index→assignment mapping so full regen is needed)
                const oldIds = oldFlat.map(s => s.id).join(",");
                const newIds = newFlat.map(s => s.id).join(",");
                const isStructural = oldIds !== newIds;

                clearTimeout(generateDebounceRef.current);
                if (isStructural) {
                  // Structural change: full regenerate
                  generateDebounceRef.current = setTimeout(() => {
                    abortRef.current?.abort();
                    abortRef.current = new AbortController();
                    void generate(segsForGenerate(newItems), abortRef.current.signal);
                  }, 600);
                } else {
                  // Same segments, same order: find which changed (type/duration/bpm/valence)
                  const oldById = new Map(oldFlat.map(s => [s.id, s]));
                  const changedFlatIndices = newFlat.reduce<number[]>((acc, seg, fi) => {
                    const old = oldById.get(seg.id);
                    if (!old) return acc;
                    const changed = seg.type !== old.type || seg.duration_s !== old.duration_s
                      || seg.bpm_min !== old.bpm_min || seg.bpm_max !== old.bpm_max
                      || seg.bpm_tolerance !== old.bpm_tolerance
                      || seg.valence_min !== old.valence_min || seg.valence_max !== old.valence_max;
                    if (changed) acc.push(fi);
                    return acc;
                  }, []);

                  if (changedFlatIndices.length === 0) return; // no-op (e.g. only sync_mode changed)

                  // Per-segment regenerate: only affected indices, preserving all others
                  generateDebounceRef.current = setTimeout(() => {
                    for (const fi of changedFlatIndices) {
                      void generateSegmentOnly(fi, undefined, newItems);
                    }
                  }, 600);
                }
              }}
              focusedIdx={focusedIdx}
              onFocus={(i) => setFocusedIdx(i === focusedIdx ? -1 : i)}
              onPumpUp={handlePumpUp}
            />
          )}
        </div>
        {/* Right: song assignments */}
        <div className="flex-1 flex flex-col overflow-hidden">
          <div ref={rightRef} className="flex-1 overflow-y-auto">
            {/* One-time skip song explainer banner */}
            {hasRun && sessionId !== null && !skipBannerDismissed && (
              <div className="mx-3 mt-3 p-3 rounded-lg border border-primary/30 bg-primary/5 flex items-start gap-2 text-xs shrink-0">
                <span className="text-lg leading-none shrink-0">◄◄</span>
                <p className="text-muted-foreground flex-1">
                  <span className="text-foreground font-medium">How skip songs work: </span>
                  Each segment ends with a &quot;skip song&quot; — start it ~60s before your watch transitions, then skip it when your Garmin vibrates. The next segment&apos;s music begins immediately.
                </p>
                <button
                  type="button"
                  onClick={() => { localStorage.setItem("soma_skip_banner_dismissed", "1"); setSkipBannerDismissed(true); }}
                  className="text-muted-foreground hover:text-foreground shrink-0 p-0.5"
                  aria-label="Dismiss"
                >✕</button>
              </div>
            )}
            <SongAssignmentPanel
              items={items}
              assignments={assignmentsWithWarnings}
              excludedIds={excludedIds}
              selectedGenres={genres}
              focusedIdx={focusedIdx}
              onFocus={(i) => setFocusedIdx(i === focusedIdx ? -1 : i)}
              onExclude={handleExclude}
              onReplace={handleReplace}
              onPlace={(idx, song) => setAssignments(prev => {
                const existing = prev[idx]?.songs ?? [];
                if (existing.some(s => s.track_id === song.track_id)) return prev;
                return { ...prev, [idx]: { ...prev[idx], songs: [...existing.filter(s => !s.is_skip), song, ...existing.filter(s => s.is_skip)] } };
              })}
              onReorder={(idx, songs) => setAssignments(prev => ({ ...prev, [idx]: { ...prev[idx], songs } }))}
              onPreview={setPreviewSong}
              onPumpUp={handlePumpUp}
              onWidenBpm={handleWidenBpm}
              onAddPlaylists={() => {
                toast("Open the Sources menu to add more playlists", { duration: 4000 });
              }}
              onBankChanged={() => setPumpUpBankKey(k => k + 1)}
              onSave={handleSave}
              saving={saving}
              savedUrl={savedUrl}
            />
          </div>
        </div>
      </div>
      {/* Mini player */}
      <SpotifyPlayer currentSong={previewSong} />
      {/* Pump-up bank modal */}
      <PumpUpModal open={pumpUpModalOpen} onClose={() => setPumpUpModalOpen(false)} refreshKey={pumpUpBankKey} />
      {/* Change run confirmation */}
      <Dialog open={changeRunConfirm} onOpenChange={setChangeRunConfirm}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Change run?</DialogTitle>
            <DialogDescription>This will clear all song assignments. Your placed songs will be lost.</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setChangeRunConfirm(false)}>Cancel</Button>
            <Button variant="destructive" onClick={() => { setChangeRunConfirm(false); resetRun(); }}>Change run</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      {/* Keyboard shortcuts cheatsheet */}
      <Dialog open={shortcutsOpen} onOpenChange={setShortcutsOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Keyboard Shortcuts</DialogTitle>
            <DialogDescription>Available keyboard shortcuts for the playlist builder.</DialogDescription>
          </DialogHeader>
          <div className="space-y-1.5 text-sm">
            {([
              ["Ctrl + Z", "Undo"],
              ["Ctrl + Y / Ctrl + Shift + Z", "Redo"],
              ["j / k", "Next / previous segment"],
              ["r", "Regenerate focused segment"],
              ["Escape", "Collapse focused segment"],
              ["?", "Toggle this cheatsheet"],
            ] as [string, string][]).map(([key, label]) => (
              <div key={key} className="flex items-center justify-between gap-4">
                <span className="text-muted-foreground">{label}</span>
                <kbd className="text-xs bg-muted border rounded px-1.5 py-0.5 font-mono shrink-0">{key}</kbd>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
