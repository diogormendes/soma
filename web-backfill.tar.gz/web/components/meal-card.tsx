"use client";

import { useRouter } from "next/navigation";

import { useState, useMemo } from "react";
import { MACRO_COLORS } from "soma-style/colors";
import { Trash2, Plus, ChevronDown, ChevronUp, X } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { NumberInput } from "@/components/number-input";
import { IngredientPicker } from "@/components/ingredient-picker";
import { ComposeMealView } from "@/components/compose-meal-view";
import { MealDetailModal } from "@/components/meal-detail-modal";
import { type Ingredient, type PortionResult, solvePortions, computeItemMacros } from "@/lib/portion-solver";
import { ProteinQualityPill } from "@/lib/per-meal-protein";
import type { SlotBudget } from "@/lib/nutrition-types";
import type { MealItem, PresetItems } from "@/lib/meal-types";

/** Generate a readable name from meal items, e.g. "Salmon, Broccoli & Yogurt" */
function autoMealName(items: MealItem[]): string {
  if (!items || items.length === 0) return "Custom meal";
  // Sort by food type priority (solids first, supplements last), then by calories
  const namePriority = (id: string) => {
    const s = (id || "").toLowerCase();
    if (/whey|protein_powder|creatine|supplement|flax/.test(s)) return 3;
    if (/milk|water|juice|yogurt/.test(s)) return 2;
    return 1;
  };
  const sorted = [...items].sort((a, b) => {
    const pa = namePriority(a.ingredient_id || a.name || "");
    const pb = namePriority(b.ingredient_id || b.name || "");
    if (pa !== pb) return pa - pb;
    return (b.calories || 0) - (a.calories || 0);
  });
  const top = sorted.slice(0, 3);
  const names = top.map((item) => {
    // Use name field if present, otherwise prettify ingredient_id
    const raw = item.name || item.ingredient_id || "";
    return raw
      .replace(/_raw$/, "")
      .replace(/_(dry|whole)$/i, "")
      .replace(/_\d+pct$/i, "")
      .replace(/^protein_powder_whey$/, "whey")
      .replace(/^greek_yogurt.*/, "yogurt")
      .replace(/_/g, " ")
      .replace(/\b\w/g, (c: string) => c.toUpperCase())
      .trim();
  });
  if (names.length <= 1) return names[0] || "Custom meal";
  if (names.length === 2) return `${names[0]} & ${names[1]}`;
  return `${names[0]}, ${names[1]} & ${names[2]}`;
}

// ── Constants ─────────────────────────────────────────────────

const SLOT_LABELS: Record<string, string> = {
  breakfast: "Breakfast",
  lunch: "Lunch",
  dinner: "Dinner",
  pre_sleep: "Pre-Sleep",
  during_workout: "During Workout",
};

const SLOT_ICONS: Record<string, string> = {
  breakfast: "\u2600\uFE0F",
  lunch: "\uD83C\uDF24\uFE0F",
  dinner: "\uD83C\uDF19",
  pre_sleep: "\uD83C\uDF19",
  during_workout: "\uD83C\uDFC3",
};

const SLOT_TAG_MAP: Record<string, string[]> = {
  breakfast: ["breakfast"],
  lunch: ["lunch", "dinner"],
  dinner: ["lunch", "dinner"],
  pre_sleep: ["snack", "evening"],
  during_workout: ["pre-run", "during-run", "post-run"],
};

// ── Types ─────────────────────────────────────────────────────

interface Meal {
  id: number;
  meal_slot: string;
  source: string | null;
  preset_meal_id: string | null;
  preset_name: string | null;
  /** Logged on a future date: a plan, not a record (soma#873). */
  planned?: boolean;
  portion_multiplier: number;
  items: MealItem[];
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  notes: string | null;
  weigh_method: string | null;
  logged_at: string;
}

interface Preset {
  id: string;
  name: string;
  /** The preset_meals.items column: a bare list, or a list plus precomputed totals. */
  items: PresetItems;
  tags: string[] | null;
}

interface MealCardProps {
  slot: string;
  meals: Meal[];
  presets: Preset[];
  date: string;
  disabled: boolean;
  skipped?: boolean;
  slotBudget?: SlotBudget | null;
  ingredients?: Ingredient[];
  /** Daily P/C/F/Fi/kcal targets — drives goalposts in compose view. */
  dayTargets?: { protein: number; carbs: number; fat: number; fiber: number; calories: number } | null;
  /** Daily P/C/F/Fi/kcal consumed today across all slots, raw (no live preview). */
  dayConsumed?: { protein: number; carbs: number; fat: number; fiber: number; calories: number } | null;
  /** User body weight (kg) — used to compute g/kg goalposts on protein/fat bars. */
  weightKg?: number | null;
  /** Today's total burn (BMR + steps + workouts) — kcal "burn" goalpost. */
  totalBurn?: number | null;
  onMealLogged: (changedSlot?: string) => void;
  onSlotSkipped?: () => void;
  onTotalsPreview?: (slot: string, totals: { calories: number; protein: number; carbs: number; fat: number; fiber: number } | null) => void;
  locked?: boolean;
  onLockToggle?: (slot: string) => void;
}

// Read pre-computed macro totals from the preset JSONB blob.
// The preset_meals.items column stores: {items: [...], calories, protein, carbs, fat, fiber}
function estimatePresetMacros(itemsBlob: PresetItems): {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
} {
  if (itemsBlob && typeof itemsBlob === "object" && !Array.isArray(itemsBlob)) {
    return {
      calories: Number(itemsBlob.calories) || 0,
      protein: Number(itemsBlob.protein) || 0,
      carbs: Number(itemsBlob.carbs) || 0,
      fat: Number(itemsBlob.fat) || 0,
      fiber: Number(itemsBlob.fiber) || 0,
    };
  }
  return { calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 };
}

// ── Component ─────────────────────────────────────────────────

export function MealCard({
  slot,
  meals,
  presets,
  date,
  disabled,
  skipped,
  slotBudget,
  ingredients,
  dayTargets,
  dayConsumed,
  weightKg,
  totalBurn,
  onMealLogged,
  onSlotSkipped,
  onTotalsPreview,
  locked,
  onLockToggle,
}: MealCardProps) {
  const [expanded, setExpanded] = useState(meals.length > 0);
  const [showPicker, setShowPicker] = useState(false);
  const [selectedPreset, setSelectedPreset] = useState<Preset | null>(null);
  const [multiplier, setMultiplier] = useState(1);
  const [proportionsLocked, setProportionsLocked] = useState(true);
  const [logging, setLogging] = useState(false);
  const [deleting, setDeleting] = useState<number | null>(null);
  const [skipping, setSkipping] = useState(false);
  const [showCompose, setShowCompose] = useState(false);
  const [selectedIngredients, setSelectedIngredients] = useState<Set<string>>(new Set());
  const router = useRouter();   // T3a: refresh the server-loaded ingredient list after a confirm
  const [composedPortions, setComposedPortions] = useState<PortionResult[] | null>(null);
  const [showSavePrompt, setShowSavePrompt] = useState(false);
  const [savePresetName, setSavePresetName] = useState("");
  const [lastComposedItems, setLastComposedItems] = useState<MealItem[] | null>(null);
  const [lastComposedTotals, setLastComposedTotals] = useState<Record<string, number> | null>(null);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [detailMeal, setDetailMeal] = useState<Meal | null>(null);
  const [editingMealId, setEditingMealId] = useState<number | null>(null);
  const [editingMealMacros, setEditingMealMacros] = useState<{ calories: number; protein: number; carbs: number; fat: number; fiber: number } | null>(null);
  const [showQuickAdd, setShowQuickAdd] = useState(false);
  const [quickName, setQuickName] = useState("");
  const [quickCal, setQuickCal] = useState("");
  const [quickP, setQuickP] = useState("");
  const [quickC, setQuickC] = useState("");
  const [quickF, setQuickF] = useState("");

  const handleSkip = async () => {
    setSkipping(true);
    try {
      const res = await fetch("/api/nutrition/skip-slot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date, slot }),
      });
      if (res.ok) {
        onSlotSkipped?.();
      }
    } finally {
      setSkipping(false);
    }
  };

  const slotLabel = SLOT_LABELS[slot] || slot;
  const slotIcon = SLOT_ICONS[slot] || "";
  const totalCal = meals.reduce((s, m) => s + Number(m.calories || 0), 0);

  // Filter presets for this slot (memoized: a fresh array every render would defeat the memo below)
  const slotTags = useMemo(() => SLOT_TAG_MAP[slot] || [], [slot]);
  const filteredPresets = useMemo(
    () =>
      presets.filter((p) => {
        const tags = p.tags || [];
        // Show if any preset tag matches any slot tag, or show all if no tag filter
        if (slotTags.length === 0) return true;
        return tags.some((t) => slotTags.includes(t));
      }),
    [presets, slotTags]
  );

  // Preview macros for selected preset
  const previewMacros = useMemo(() => {
    if (!selectedPreset) return null;
    const base = estimatePresetMacros(selectedPreset.items);
    return {
      calories: Math.round(base.calories * multiplier),
      protein: Math.round(base.protein * multiplier),
      carbs: Math.round(base.carbs * multiplier),
      fat: Math.round(base.fat * multiplier),
      fiber: Math.round(base.fiber * multiplier),
    };
  }, [selectedPreset, multiplier]);

  const handleSelectPreset = (preset: Preset) => {
    setSelectedPreset(preset);
    setMultiplier(1);
  };

  const handleLog = async () => {
    if (!selectedPreset) return;
    setLogging(true);
    try {
      // Extract the actual items array from the JSONB blob,
      // and pass pre-computed macros so the API doesn't need the ingredient DB
      const blob = selectedPreset.items;
      const actualItems = Array.isArray(blob) ? blob : blob?.items ?? [];
      const baseMacros = estimatePresetMacros(blob);

      const res = await fetch("/api/nutrition/log-meal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          date,
          meal_slot: slot,
          preset_meal_id: selectedPreset.id,
          portion_multiplier: multiplier,
          items: actualItems,
          preset_macros: baseMacros,
        }),
      });
      if (res.ok) {
        setSelectedPreset(null);
        setShowPicker(false);
        setMultiplier(1);
        onMealLogged(slot);
      }
    } finally {
      setLogging(false);
    }
  };

  const handleDelete = async (mealId: number) => {
    setDeleting(mealId);
    try {
      const res = await fetch(`/api/nutrition/log-meal?id=${mealId}`, {
        method: "DELETE",
      });
      if (res.ok) {
        onMealLogged(slot);
      }
    } finally {
      setDeleting(null);
    }
  };

  const handleCancel = () => {
    setSelectedPreset(null);
    setShowPicker(false);
    setMultiplier(1);
    setEditingMealId(null);
  };

  const handleQuickAdd = async () => {
    setLogging(true);
    try {
      const cal = Number(quickCal) || 0;
      const p = Number(quickP) || 0;
      const c = Number(quickC) || 0;
      const f = Number(quickF) || 0;
      const items = [{
        ingredient_id: `custom_${Date.now()}`,
        grams: 0,
        calories: cal, protein: p, carbs: c, fat: f, fiber: 0,
        name: quickName || "Custom food",
      }];
      await fetch("/api/nutrition/log-meal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          date, meal_slot: slot, source: "quick_add",
          items, calories: cal, protein: p, carbs: c, fat: f, fiber: 0,
        }),
      });
      setShowQuickAdd(false);
      setQuickName(""); setQuickCal(""); setQuickP(""); setQuickC(""); setQuickF("");
      onMealLogged(slot);
    } finally {
      setLogging(false);
    }
  };

  const handleToggleIngredient = (id: string) => {
    setSelectedIngredients((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleIngredientsDone = () => {
    if (!ingredients?.length || selectedIngredients.size === 0) return;
    const selected = (ingredients as Ingredient[]).filter((i) =>
      selectedIngredients.has(i.id),
    );
    // Per-meal solver target: kcal from slot budget + MPS floor (30g default).
    // Carbs / fat / fiber emerge from ingredient selection.
    const kcal = slotBudget ? Number(slotBudget.calories) || 500 : 500;
    const portions = solvePortions(selected, { calories: kcal });
    setComposedPortions(portions);
  };

  const handleComposeLog = async (
    items: { ingredient_id: string; grams: number; calories: number; protein: number; carbs: number; fat: number; fiber: number }[],
    totals: { calories: number; protein: number; carbs: number; fat: number; fiber: number },
  ) => {
    setLogging(true);
    try {
      // If editing, delete the old meal first
      if (editingMealId) {
        await fetch(`/api/nutrition/log-meal?id=${editingMealId}`, { method: "DELETE" });
        setEditingMealId(null);
      }

      const res = await fetch("/api/nutrition/log-meal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          date,
          meal_slot: slot,
          items,
        }),
      });
      if (res.ok) {
        // Store for potential save-as-preset
        setLastComposedItems(items);
        setLastComposedTotals(totals);
        setComposedPortions(null);
        setSelectedIngredients(new Set());
        setShowCompose(false);
        onTotalsPreview?.(slot, null); // clear live preview before refresh
        onMealLogged(slot);
        // Pre-populate save prompt with auto-generated name
        setSavePresetName(autoMealName(items));
        setShowSavePrompt(true);
      }
    } finally {
      setLogging(false);
    }
  };

  const handleSavePreset = async () => {
    if (!savePresetName.trim() || !lastComposedItems) {
      console.warn("Save preset skipped: name empty or no items", { name: savePresetName, hasItems: !!lastComposedItems });
      return;
    }
    setSaving(true);
    setSaveError(null);
    try {
      const res = await fetch("/api/nutrition/presets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: savePresetName.trim(),
          items: lastComposedItems,
          slot,
          totals: lastComposedTotals,
        }),
      });
      if (!res.ok) {
        const msg = await res.text().catch(() => "Unknown error");
        setSaveError(`Save failed: ${msg}`);
        return;
      }
      setShowSavePrompt(false);
      setSavePresetName("");
      setLastComposedItems(null);
      setLastComposedTotals(null);
      onMealLogged(slot); // refresh to show the new preset in the picker
    } catch (_err) {
      setSaveError("Network error — could not save");
    } finally {
      setSaving(false);
    }
  };

  const handleDismissSave = () => {
    setShowSavePrompt(false);
    setSavePresetName("");
    setLastComposedItems(null);
    setLastComposedTotals(null);
  };

  const handleCustomizePreset = () => {
    if (!selectedPreset || !ingredients?.length) return;
    const blob = selectedPreset.items;
    const presetItems: MealItem[] = Array.isArray(blob) ? blob : blob?.items ?? [];
    const ingLookup = new Map(
      (ingredients as Ingredient[]).map((i) => [i.id, i]),
    );
    const portions: PortionResult[] = presetItems
      .map((item) => {
        const ing = item.ingredient_id ? ingLookup.get(item.ingredient_id) : undefined;
        if (!ing || !item.ingredient_id) return null;
        const grams = item.grams ?? 0;
        const macros = computeItemMacros(ing, grams);
        return {
          ingredient_id: item.ingredient_id,
          grams,
          increment:
            { protein: 25, carbs: 10, vegetable: 25, fat: 5, dairy: 25, sauce: 10, fruit: 25, supplement: 5 }[ing.category] ?? 10,
          ...macros,
        };
      })
      .filter((p): p is PortionResult => p !== null);
    setComposedPortions(portions);
    setSelectedPreset(null);
    setShowPicker(false);
  };

  const handleEditIngredients = () => {
    // Go back to picker, pre-selecting current ingredients from the composed portions
    if (composedPortions) {
      const ids = new Set(composedPortions.map((p) => p.ingredient_id));
      setSelectedIngredients(ids);
    }
    setComposedPortions(null);
    setShowCompose(true);
  };

  const handleComposeCancel = () => {
    setComposedPortions(null);
    setSelectedIngredients(new Set());
    setShowCompose(false);
    setEditingMealId(null);
    setEditingMealMacros(null);
    onTotalsPreview?.(slot, null); // clear live preview
  };

  return (
    <Card>
      <button
        className={`w-full flex items-center justify-between px-4 py-3 text-left ${skipped ? "opacity-50" : ""}`}
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center gap-2">
          <span className="text-lg">{slotIcon}</span>
          <span className="font-medium text-sm">{slotLabel}</span>
          {meals.length > 0 && (
            <span className="text-xs text-muted-foreground">
              ({meals.length})
            </span>
          )}
          {meals.length > 0 && onLockToggle && (
            <span
              onClick={(e) => { e.stopPropagation(); onLockToggle(slot); }}
              className={`cursor-pointer text-[9px] px-1.5 py-0.5 rounded-full font-medium transition-colors ${locked ? "bg-amber-500 text-black" : "bg-transparent border border-muted-foreground/20 text-muted-foreground/40 hover:text-muted-foreground"}`}
              title={locked ? "Locked — won't be rebalanced" : "Click to lock"}
            >
              {locked ? "fixed" : "flex"}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {totalCal > 0 && (
            <span className="text-xs font-medium tabular-nums">
              {Math.round(totalCal)} kcal
            </span>
          )}
          {slotBudget && totalCal > 0 && (
            <span
              className="text-[10px] text-muted-foreground/70 tabular-nums"
              title="Soft pacing hint — splits the daily calorie target across slots. Not a hard cap."
            >
              budget {Math.round(slotBudget.calories)}
            </span>
          )}
          {expanded ? (
            <ChevronUp className="h-4 w-4 text-muted-foreground" />
          ) : (
            <ChevronDown className="h-4 w-4 text-muted-foreground" />
          )}
        </div>
      </button>

      {expanded && (
        <CardContent className="pt-0 space-y-2">
          {/* Logged meals */}
          {meals.map((meal) => {
            const itemsList: MealItem[] = meal.items ?? [];
            const ingLookup = new Map(
              ((ingredients ?? []) as Ingredient[]).map((i) => [i.id, i]),
            );
            return (
              <div
                key={meal.id}
                className="rounded-md bg-muted/50 px-3 py-2 text-sm cursor-pointer hover:bg-muted/70 transition-colors"
                onClick={() => setDetailMeal(meal)}
              >
                <div className="flex items-center justify-between">
                  <div className="min-w-0">
                    <div className="font-medium truncate">
                      {meal.preset_name || autoMealName(meal.items)}
                      {meal.planned && (
                        <span className="ml-1.5 align-middle text-[9px] px-1.5 py-0.5 rounded-full bg-white/10 text-muted-foreground font-normal" data-testid="planned-pill">planned</span>
                      )}
                      {meal.portion_multiplier !== 1 && (
                        <span className="text-muted-foreground ml-1">
                          ({meal.portion_multiplier}x)
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {Math.round(meal.calories)} kcal &middot;{" "}
                      {Math.round(meal.protein)}P
                      <ProteinQualityPill grams={meal.protein} weightKg={weightKg} />
                      {" · "}
                      {Math.round(meal.carbs)}C &middot; {Math.round(meal.fat)}F
                      {!disabled && itemsList.some(i => { const ig = ingLookup.get(i.ingredient_id ?? ""); return ig?.is_raw && ig?.raw_to_cooked_ratio && ig.raw_to_cooked_ratio > 1; }) && <span className="text-[9px] ml-1.5 text-muted-foreground/60">20+ min</span>}
                    </div>
                  </div>
                  {!disabled && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 shrink-0"
                      onClick={(e) => { e.stopPropagation(); handleDelete(meal.id); }}
                      disabled={deleting === meal.id}
                    >
                      <Trash2 className="h-3.5 w-3.5 text-muted-foreground" />
                    </Button>
                  )}
                </div>
                {itemsList.length > 0 && (
                  <div className="mt-1 space-y-0.5">
                    {(() => {
                      const sortedItems = [...itemsList].sort((a, b) => {
                        const order: Record<string, number> = { vegetable: 0, protein: 1, carbs: 2, fruit: 3, dairy: 4, fat: 5, sauce: 6, supplement: 7 };
                        const catA = ingLookup.get(a.ingredient_id ?? "")?.category ?? "zzz";
                        const catB = ingLookup.get(b.ingredient_id ?? "")?.category ?? "zzz";
                        return (order[catA] ?? 99) - (order[catB] ?? 99);
                      });
                      return sortedItems.map((item, idx) => {
                        const ing = ingLookup.get(item.ingredient_id ?? "");
                        // A quick-add item has no catalog entry: its name lives on the item and it
                        // carries no weight, so show the name and no "0g" (soma#868).
                        const name = ing?.name ?? item.name ?? item.ingredient_id ?? "?";
                        const rawG = item.grams ?? 0;
                        const weightless = !ing && !(rawG > 0);
                        const ratio = ing?.raw_to_cooked_ratio;
                        const isRaw = ing?.is_raw && ratio && ratio > 0 && ratio !== 1;
                        const cookedG = item.cooked_grams ?? (isRaw ? Math.round(rawG * (ratio as number)) : 0);
                        return (
                          <div key={idx} className="text-[10px] text-muted-foreground flex justify-between">
                            <span>
                              {name}
                              {idx === 0 && ing?.category === "vegetable" && (
                                <span className="text-[8px] text-green-600 ml-1">eat first</span>
                              )}
                            </span>
                            <span className="tabular-nums">
                              {weightless
                                ? ""
                                : isRaw
                                  ? `${cookedG}g cooked (${rawG}g raw)`
                                  : `${rawG}g`}
                            </span>
                          </div>
                        );
                      });
                    })()}
                  </div>
                )}
              </div>
            );
          })}

          {/* Skipped state — show badge with undo */}
          {!disabled && skipped && meals.length === 0 && (
            <div className="flex items-center justify-between rounded-md bg-muted/30 px-3 py-2">
              <span className="text-xs text-muted-foreground italic">
                Skipped — budget moved to other meals
              </span>
              <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={handleSkip} disabled={skipping}>
                Undo
              </Button>
            </div>
          )}

          {/* Water preload reminder for unfilled slots */}
          {!disabled && !skipped && meals.length === 0 && !showPicker && !selectedPreset && !showCompose && !composedPortions && (
            <div className="text-[10px] text-blue-400 text-center py-0.5">
              Drink 500ml water 30 min before eating
            </div>
          )}

          {/* Quick add form */}
          {showQuickAdd && (
            <div className="space-y-2 p-3 border border-border/50 rounded-lg">
              <input
                placeholder="Name (e.g., Restaurant burger)"
                className="w-full text-sm bg-background border border-border rounded px-2 py-1"
                value={quickName}
                onChange={e => setQuickName(e.target.value)}
              />
              <div className="grid grid-cols-4 gap-2">
                <input placeholder="kcal" type="number" className="text-sm bg-background border border-border rounded px-2 py-1" value={quickCal} onChange={e => setQuickCal(e.target.value)} />
                <input placeholder="P" type="number" className="text-sm bg-background border border-border rounded px-2 py-1" value={quickP} onChange={e => setQuickP(e.target.value)} />
                <input placeholder="C" type="number" className="text-sm bg-background border border-border rounded px-2 py-1" value={quickC} onChange={e => setQuickC(e.target.value)} />
                <input placeholder="F" type="number" className="text-sm bg-background border border-border rounded px-2 py-1" value={quickF} onChange={e => setQuickF(e.target.value)} />
              </div>
              <div className="flex gap-2">
                <Button size="sm" className="text-xs" onClick={handleQuickAdd} disabled={logging || !quickCal}>Add</Button>
                <Button size="sm" variant="ghost" className="text-xs" onClick={() => setShowQuickAdd(false)}>Cancel</Button>
              </div>
            </div>
          )}

          {/* Empty slot — Add meal + Quick add + Skip side by side */}
          {!disabled && !skipped && !showPicker && !selectedPreset && !showCompose && !composedPortions && !showQuickAdd && meals.length === 0 && (
            <div className="flex gap-2">
              <Button variant="ghost" size="sm" className="flex-1 text-muted-foreground" onClick={() => setShowPicker(true)}>
                <Plus className="h-3.5 w-3.5 mr-1" /> Add meal
              </Button>
              <Button variant="ghost" size="sm" className="text-xs gap-1 text-muted-foreground" onClick={() => setShowQuickAdd(true)} disabled={disabled}>
                <Plus className="h-3 w-3" />
                Quick add
              </Button>
              <Button variant="ghost" size="sm" className="text-muted-foreground text-xs" onClick={handleSkip} disabled={skipping}>
                Skip
              </Button>
            </div>
          )}

          {/* Has meals — Add meal + Quick add buttons */}
          {!disabled && !skipped && !showPicker && !selectedPreset && !showCompose && !composedPortions && !showQuickAdd && meals.length > 0 && (
            <div className="flex gap-2">
              <Button variant="ghost" size="sm" className="flex-1 text-muted-foreground" onClick={() => setShowPicker(true)}>
                <Plus className="h-3.5 w-3.5 mr-1" /> Add meal
              </Button>
              <Button variant="ghost" size="sm" className="text-xs gap-1 text-muted-foreground" onClick={() => setShowQuickAdd(true)} disabled={disabled}>
                <Plus className="h-3 w-3" />
                Quick add
              </Button>
            </div>
          )}

          {/* Preset picker */}
          {!disabled && showPicker && !selectedPreset && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-muted-foreground">
                  Choose a preset
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6"
                  onClick={handleCancel}
                >
                  <X className="h-3.5 w-3.5" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {filteredPresets.length > 0 ? (
                  filteredPresets.map((p) => (
                    <div
                      key={p.id}
                      role="button"
                      tabIndex={0}
                      className="inline-flex items-center rounded-md border px-3 h-7 text-xs gap-1 pr-1.5 cursor-pointer hover:bg-accent"
                      onClick={() => handleSelectPreset(p)}
                      onKeyDown={(e) => { if (e.key === "Enter") handleSelectPreset(p); }}
                    >
                      {p.name}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (confirm(`Delete "${p.name}"?`)) {
                            fetch(`/api/nutrition/presets?id=${p.id}`, { method: "DELETE" })
                              .then(() => onMealLogged(slot));
                          }
                        }}
                        className="ml-auto p-1 text-muted-foreground/50 hover:text-rose-500"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </div>
                  ))
                ) : (
                  <span className="text-xs text-muted-foreground">
                    No presets available for this slot
                  </span>
                )}
              </div>
              {ingredients && ingredients.length > 0 && (
                <>
                  <div className="w-full border-t my-1.5" />
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-xs h-7 w-full"
                    onClick={() => {
                      setShowPicker(false);
                      setShowCompose(true);
                    }}
                  >
                    Compose custom meal...
                  </Button>
                </>
              )}
            </div>
          )}

          {/* Selected preset: macro preview + proportions + log */}
          {!disabled && selectedPreset && (() => {
            // Parse preset items
            const blob = selectedPreset.items;
            const presetItems: MealItem[] = Array.isArray(blob) ? blob : blob?.items ?? [];

            return (
            <div className="space-y-3 rounded-md border p-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">
                  {selectedPreset.name}
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setProportionsLocked(!proportionsLocked)}
                    className={`text-[10px] px-2 py-0.5 rounded-full font-medium transition-colors ${proportionsLocked ? "bg-amber-500 text-black" : "bg-transparent border border-muted-foreground/30 text-muted-foreground"}`}
                    title={proportionsLocked ? "Proportions locked — scaling together" : "Proportions unlocked — adjust independently"}
                  >
                    {proportionsLocked ? "Linked" : "Free"}
                  </button>
                  <Button variant="ghost" size="icon" className="h-6 w-6" onClick={handleCancel}>
                    <X className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>

              {/* Ingredients with portions */}
              <div className="space-y-1">
                {presetItems.map((item) => {
                  const ing = (ingredients as Ingredient[])?.find(i => i.id === item.ingredient_id);
                  const scaledGrams = Math.round((item.grams ?? 0) * multiplier);
                  const m = ing ? computeItemMacros(ing, scaledGrams) : null;
                  return (
                    <div key={item.ingredient_id} className="flex items-center justify-between text-xs">
                      <div className="flex-1 min-w-0">
                        <span className="truncate">{ing?.name || item.ingredient_id}</span>
                        {m && <span className="text-[10px] text-muted-foreground ml-1">{m.calories}kcal</span>}
                      </div>
                      <span className="tabular-nums text-muted-foreground">{scaledGrams}g</span>
                    </div>
                  );
                })}
              </div>

              {/* Macro preview */}
              {previewMacros && (
                <div className="grid grid-cols-4 gap-2 text-center text-xs">
                  <div>
                    <div className="font-bold tabular-nums">{previewMacros.calories}</div>
                    <div className="text-muted-foreground">kcal</div>
                  </div>
                  <div>
                    <div className={`font-bold tabular-nums ${MACRO_COLORS.protein.text}`}>{previewMacros.protein}g</div>
                    <div className="text-muted-foreground">P</div>
                  </div>
                  <div>
                    <div className={`font-bold tabular-nums ${MACRO_COLORS.carbs.text}`}>{previewMacros.carbs}g</div>
                    <div className="text-muted-foreground">C</div>
                  </div>
                  <div>
                    <div className={`font-bold tabular-nums ${MACRO_COLORS.fat.text}`}>{previewMacros.fat}g</div>
                    <div className="text-muted-foreground">F</div>
                  </div>
                </div>
              )}

              {/* Scale slider (locked) or Customize button (unlocked) */}
              {proportionsLocked ? (
                <NumberInput
                  value={multiplier}
                  onChange={setMultiplier}
                  min={0.5}
                  max={2.0}
                  step={0.05}
                  suffix="x"
                  label="Scale"
                />
              ) : (
                <div className="text-[10px] text-muted-foreground text-center">
                  Click &quot;Customize&quot; below to adjust individual portions
                </div>
              )}

              {/* Log + Customize + Cancel */}
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1"
                  onClick={handleCancel}
                >
                  Cancel
                </Button>
                {ingredients && ingredients.length > 0 && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={handleCustomizePreset}
                  >
                    Customize
                  </Button>
                )}
                <Button
                  size="sm"
                  className="flex-1"
                  onClick={handleLog}
                  disabled={logging}
                >
                  {logging ? "Logging..." : "Log"}
                </Button>
              </div>
            </div>
            );
          })()}

          {/* Ingredient picker (compose step 1) */}
          {!disabled && showCompose && !composedPortions && (
            <IngredientPicker
              ingredients={(ingredients ?? []) as Ingredient[]}
              selected={selectedIngredients}
              onToggle={handleToggleIngredient}
              onDone={handleIngredientsDone}
              onCancel={handleComposeCancel}
              onIngredientAdded={(ing) => { setSelectedIngredients((prev) => new Set(prev).add(ing.id)); router.refresh(); }}
            />
          )}

          {/* Compose meal view (compose step 2) */}
          {!disabled && composedPortions && (() => {
            // Per-meal compose budget: only kcal is slot-derived. Subtract kcal
            // already consumed by other meals in this slot so the composer
            // pacing bar reflects remaining headroom.
            const otherMeals = editingMealId ? meals.filter(m => m.id !== editingMealId) : [];
            const otherCal = otherMeals.reduce((s, m) => s + Number(m.calories || 0), 0);
            const slotKcal = slotBudget ? Number(slotBudget.calories) || 0 : 0;
            const composeBudget: SlotBudget | null = slotBudget
              ? { calories: Math.max(0, slotKcal - otherCal) }
              : null;
            // dayConsumed includes ALL day's logged meals; when editing, subtract the
            // meal being edited so the daily-progress bar isn't double-counting it.
            const dayConsumedExcl = dayConsumed && editingMealMacros
              ? {
                  protein: Math.max(0, dayConsumed.protein - editingMealMacros.protein),
                  carbs: Math.max(0, dayConsumed.carbs - editingMealMacros.carbs),
                  fat: Math.max(0, dayConsumed.fat - editingMealMacros.fat),
                  fiber: Math.max(0, dayConsumed.fiber - editingMealMacros.fiber),
                  calories: Math.max(0, dayConsumed.calories - editingMealMacros.calories),
                }
              : dayConsumed;
            return (
            <ComposeMealView
              portions={composedPortions}
              ingredients={(ingredients ?? []) as Ingredient[]}
              budget={composeBudget ?? null}
              dayTargets={dayTargets ?? null}
              dayConsumed={dayConsumedExcl ?? null}
              weightKg={weightKg ?? null}
              totalBurn={totalBurn ?? null}
              onLog={handleComposeLog}
              onCancel={handleComposeCancel}
              onEditIngredients={handleEditIngredients}
              logging={logging}
              onTotalsChange={onTotalsPreview ? (t) => {
                // When editing, send delta (preview - original) to avoid double-counting
                // The original meal is already in consumed totals from the meals array
                if (editingMealMacros) {
                  onTotalsPreview(slot, {
                    calories: t.calories - editingMealMacros.calories,
                    protein: t.protein - editingMealMacros.protein,
                    carbs: t.carbs - editingMealMacros.carbs,
                    fat: t.fat - editingMealMacros.fat,
                    fiber: t.fiber - editingMealMacros.fiber,
                  });
                } else {
                  onTotalsPreview(slot, t);
                }
              } : undefined}
            />
            );
          })()}

          {/* Save as preset prompt */}
          {showSavePrompt && (
            <div className="space-y-2 rounded-md border border-dashed p-3">
              <span className="text-xs text-muted-foreground">
                Save as preset for reuse?
              </span>
              <input
                type="text"
                placeholder="Preset name..."
                value={savePresetName}
                onChange={(e) => setSavePresetName(e.target.value)}
                className="w-full rounded-md border px-2 py-1.5 text-sm bg-background"
                autoFocus
              />
              {saveError && <div className="text-xs text-red-500">{saveError}</div>}
              <div className="flex gap-2">
                <Button variant="ghost" size="sm" className="flex-1" onClick={handleDismissSave}>
                  Skip
                </Button>
                <Button size="sm" className="flex-1" disabled={saving || !savePresetName.trim()} onClick={handleSavePreset}>
                  {saving ? "Saving..." : "Save"}
                </Button>
              </div>
            </div>
          )}

          {/* Meal detail modal */}
          <MealDetailModal
            open={detailMeal !== null}
            onClose={() => setDetailMeal(null)}
            meal={detailMeal}
            ingredients={(ingredients ?? []) as Ingredient[]}
            onEdit={detailMeal && !disabled ? () => {
              // Load meal into compose view for editing
              const itemsList: MealItem[] = detailMeal.items ?? [];
              const ids = new Set(itemsList.map((i) => i.ingredient_id).filter((id): id is string => !!id));
              setSelectedIngredients(ids);
              // Create portions from the meal's items
              const ingLookup = new Map(
                ((ingredients ?? []) as Ingredient[]).map((i) => [i.id, i]),
              );
              const portions: PortionResult[] = itemsList
                .map((item) => {
                  const ing = item.ingredient_id ? ingLookup.get(item.ingredient_id) : undefined;
                  if (!ing || !item.ingredient_id) return null;
                  const grams = item.grams ?? 0;
                  const macros = computeItemMacros(ing, grams);
                  return {
                    ingredient_id: item.ingredient_id,
                    grams,
                    increment: { protein: 25, carbs: 10, vegetable: 25, fat: 5, dairy: 25, sauce: 10, fruit: 25, supplement: 5 }[ing.category] ?? 10,
                    ...macros,
                  };
                })
                .filter((p): p is PortionResult => p !== null);
              setComposedPortions(portions);
              // Store original macros for delta preview
              setEditingMealMacros({
                calories: Number(detailMeal.calories) || 0,
                protein: Number(detailMeal.protein) || 0,
                carbs: Number(detailMeal.carbs) || 0,
                fat: Number(detailMeal.fat) || 0,
                fiber: Number(detailMeal.fiber) || 0,
              });
              // Mark the old meal for deletion on successful save
              setEditingMealId(detailMeal.id);
              setDetailMeal(null);
            } : undefined}
          />
        </CardContent>
      )}
    </Card>
  );
}
