"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Maximize2 } from "lucide-react";

interface ExpandableChartCardProps {
  title: string;
  subtitle?: string | React.ReactNode;
  icon?: React.ReactNode;
  className?: string;
  children: React.ReactNode | ((props: { expanded: boolean }) => React.ReactNode);
}

export function ExpandableChartCard({
  title,
  subtitle,
  icon,
  className,
  children,
}: ExpandableChartCardProps) {
  const [open, setOpen] = useState(false);

  const renderChildren = (expanded: boolean) =>
    typeof children === "function" ? children({ expanded }) : children;

  return (
    <>
      <Card
        className={`cursor-pointer transition-all duration-200 hover:shadow-md hover:shadow-primary/5 hover:border-primary/20 active:scale-[0.99] active:shadow-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background group ${className || ""}`}
        onClick={() => setOpen(true)}
        onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); setOpen(true); } }}
        tabIndex={0}
        role="button"
      >
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            {icon}
            {title}
            {subtitle && typeof subtitle === "string" ? (
              <span className="ml-auto text-xs font-normal">{subtitle}</span>
            ) : subtitle ? (
              <span className="ml-auto">{subtitle}</span>
            ) : null}
            <Maximize2 className="h-3.5 w-3.5 ml-auto opacity-40 md:opacity-30 md:group-hover:opacity-60 transition-opacity duration-200 shrink-0" />
          </CardTitle>
        </CardHeader>
        {/* No mobile height clamp: forcing the container to 200px didn't shrink
            the recharts SVG (which keeps its numeric `height` prop), so the SVG
            spilled 100px below the card and overlapped the next card. Let the
            container match the chart's natural height on every breakpoint. */}
        <CardContent>
          {renderChildren(false)}
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[95vw] sm:max-w-5xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {icon}
              {title}
            </DialogTitle>
            {subtitle && typeof subtitle === "string" && (
              <DialogDescription>{subtitle}</DialogDescription>
            )}
          </DialogHeader>
          <div className="mt-2">{renderChildren(true)}</div>
        </DialogContent>
      </Dialog>
    </>
  );
}
