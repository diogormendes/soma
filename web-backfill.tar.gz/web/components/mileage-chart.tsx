"use client";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

interface MileageEntry {
  month: string;
  km: number;
  runs: number;
}

export function MileageChart({ data }: { data: MileageEntry[] }) {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-[200px] text-muted-foreground text-sm">
        No data
      </div>
    );
  }

  const chartData = data.map((d) => ({
    month: d.month,
    km: Number(Number(d.km).toFixed(1)),
    runs: Number(d.runs),
  }));

  const max = Math.max(...chartData.map((d) => d.km));

  return (
    <ResponsiveContainer width="100%" height={200}>
      <BarChart data={chartData}>
        <XAxis
          dataKey="month"
          className="text-[10px]"
          tickLine={false}
          tickFormatter={(m) => {
            const [year, month] = m.split("-");
            const months = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            return `${months[parseInt(month)]} '${year.slice(2)}`;
          }}
          interval={Math.max(0, Math.floor(chartData.length / 8))}
        />
        <YAxis
          className="text-xs"
          tickFormatter={(v) => `${v}km`}
          tick={{ fontSize: 11 }}
        />
        <Tooltip
          cursor={{ fill: "var(--muted)", opacity: 0.3 }}
          formatter={(value, name) => {
            if (name === "km") return [`${value} km`, "Distance"];
            return [value, name];
          }}
          labelFormatter={(m) => {
            const [year, month] = m.split("-");
            const months = [
              "",
              "Jan",
              "Feb",
              "Mar",
              "Apr",
              "May",
              "Jun",
              "Jul",
              "Aug",
              "Sep",
              "Oct",
              "Nov",
              "Dec",
            ];
            return `${months[parseInt(month)]} ${year}`;
          }}
          contentStyle={{
            backgroundColor: "var(--card)",
            border: "1px solid var(--border)",
            borderRadius: "8px",
            color: "var(--card-foreground)",
          }}
        />
        <Bar dataKey="km" radius={[4, 4, 0, 0]}>
          {chartData.map((entry, index) => (
            <Cell
              key={index}
              fill={
                entry.km === max
                  ? "var(--primary)"
                  : "color-mix(in oklch, var(--muted-foreground) 30%, transparent)"
              }
            />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
