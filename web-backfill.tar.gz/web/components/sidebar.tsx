"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import {
  LayoutDashboard,
  Dumbbell,
  Footprints,
  Target,
  Mountain,
  Moon,
  Cable,
  Music2,
  UtensilsCrossed,
  Menu,
  X } from "lucide-react";
import { cn } from "@/lib/utils";
import { SyncButton } from "@/components/sync-button";
import { SomaLogo } from "@/components/soma-logo";

const navItems = [
  { href: "/", icon: LayoutDashboard, label: "Overview", shortcut: "1", mobile: true },
  { href: "/nutrition", icon: UtensilsCrossed, label: "Nutrition", shortcut: "0", mobile: true },
  { href: "/running", icon: Footprints, label: "Running", shortcut: "2", mobile: true },
  { href: "/training", icon: Target, label: "Training", shortcut: "3", mobile: false },
  { href: "/workouts", icon: Dumbbell, label: "Gym", shortcut: "4", mobile: true },
  { href: "/activities", icon: Mountain, label: "Activities", shortcut: "5", mobile: false },
  { href: "/sleep", icon: Moon, label: "Sleep", shortcut: "6", mobile: true },
  { href: "/playlist", icon: Music2, label: "Playlist", shortcut: "7", mobile: false },
  { href: "/connections", icon: Cable, label: "Sync", shortcut: "8", mobile: false },
];

export function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [navigatingTo, setNavigatingTo] = useState<string | null>(null);

  // Keyboard shortcuts
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (!(e.metaKey || e.ctrlKey)) return;
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement
      )
        return;

      const item = navItems.find((n) => n.shortcut === e.key);
      if (item) {
        e.preventDefault();
        router.push(item.href);
      }
    }

    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [router]);

  // Close the drawer and clear the pending navigation once the path has changed: state
  // adjusted during render (React's derived-state pattern), not a setState inside an effect.
  const [pathAtRender, setPathAtRender] = useState(pathname);
  if (pathname !== pathAtRender) {
    setPathAtRender(pathname);
    setDrawerOpen(false);
    setNavigatingTo(null);
  }

  return (
    <>
      {/* App header bar — mobile only. On desktop the sidebar is always visible
          (lg:translate-x-0 below), so the hamburger header is hidden. */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-background border-b border-border lg:hidden">
        {/* Status bar spacer — solid fill behind clock/notch/icons */}
        <div className="safe-area-pt" />
        {/* Header content */}
        <div className="flex h-11 items-center px-2 safe-area-pl safe-area-pr">
          <button
            onClick={() => setDrawerOpen(!drawerOpen)}
            className="flex h-9 w-9 items-center justify-center text-muted-foreground hover:text-foreground transition-colors rounded-lg shrink-0"
            aria-label="Toggle menu"
          >
            {drawerOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
          <div className="flex-1 flex items-center justify-center">
            <span className="text-sm font-semibold">
              {navItems.find((n) => n.href === "/" ? pathname === "/" : pathname.startsWith(n.href))?.label ?? "Soma"}
            </span>
          </div>
          <div className="w-9 shrink-0" /> {/* Balance the hamburger width */}
        </div>
      </header>

      {/* Overlay */}
      {drawerOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm"
          onClick={() => setDrawerOpen(false)}
        />
      )}

      {/* Slide-out drawer */}
      <aside
        className={cn(
          // Sizing model (soma#363): the slide-out drawer below lg keeps full labels; from lg the
          // sidebar is always visible as a 4rem icon rail (tablet / narrow desktop), grows to
          // 14rem with labels from xl and 16rem from 2xl. The content offset in app/layout.tsx and
          // the demo banner track the same steps.
          "fixed left-0 top-0 z-40 h-screen w-56 lg:w-16 xl:w-56 2xl:w-64 flex flex-col border-r border-border bg-sidebar transition-[transform,width] duration-200 safe-area-pt safe-area-pl safe-area-pb",
          // Slide-in drawer on mobile; always visible on desktop (lg+).
          drawerOpen ? "translate-x-0" : "-translate-x-full",
          "lg:translate-x-0"
        )}
      >
        {/* Logo + close area */}
        <div className="flex h-14 items-center gap-3 px-4 lg:justify-center lg:px-0 xl:justify-start xl:px-4 border-b border-border">
          <div className="w-8 lg:hidden xl:block" /> {/* spacer for hamburger */}
          <Link
            href="/"
            className="flex items-center gap-2"
            aria-label="Go to home"
          >
            <SomaLogo size={24} />
            <span className="text-[1rem] font-semibold lg:hidden xl:inline">Soma</span>
          </Link>
        </div>

        {/* Nav items */}
        <nav className="flex flex-1 flex-col gap-0.5 p-2 lg:px-1.5 xl:px-2 overflow-y-auto" aria-label="Primary">
          {navItems.map((item) => {
            const isActive = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
            const isLoading = navigatingTo === item.href;
            const Icon = item.icon;

            return (
              <Link
                key={item.label}
                href={item.href}
                onClick={() => { if (!isActive) setNavigatingTo(item.href); }}
                aria-current={isActive ? "page" : undefined}
                aria-label={item.label}
                title={`${item.label} (⌘${item.shortcut})`}
                className={cn(
                  // Type: 15px labels (one step above the app's 14px body) and a hint that stays
                  // readable at 12px / 70% (was 50%, soma#363). On the rail only the icon shows.
                  "flex items-center gap-3 px-3 py-2.5 lg:justify-center lg:px-0 lg:py-2.5 xl:justify-start xl:px-3 rounded-lg transition-all text-[15px] leading-5 active:scale-[0.96] active:opacity-70",
                  isActive
                    ? "bg-accent text-accent-foreground font-medium"
                    : isLoading
                    ? "bg-accent/50 text-foreground"
                    : "text-muted-foreground hover:bg-accent hover:text-foreground"
                )}
              >
                {isLoading ? (
                  <Loader2 className="h-4 w-4 lg:h-5 lg:w-5 xl:h-4 xl:w-4 shrink-0 animate-spin" />
                ) : (
                  <Icon className="h-4 w-4 lg:h-5 lg:w-5 xl:h-4 xl:w-4 shrink-0" />
                )}
                <span className="lg:hidden xl:inline">{item.label}</span>
                <span className="ml-auto text-xs tabular-nums text-muted-foreground/70 hidden xl:inline" aria-hidden="true">
                  ⌘{item.shortcut}
                </span>
              </Link>
            );
          })}

          {/* Sync button at bottom */}
          <div className="mt-auto pt-2 border-t border-border lg:flex lg:justify-center xl:block">
            <SyncButton />
          </div>
        </nav>
      </aside>

      {/* No bottom nav — hamburger drawer handles all navigation */}
    </>
  );
}

