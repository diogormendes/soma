"use client";

import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine,
} from "recharts";

interface StepPoint {
  date: string;
  steps: number;
}

export function StepsTrendChart({ data, goal = 10000 }: { data: StepPoint[]; goal?: number }) {
  if (data.length === 0) return null;

  const recent = data.slice(-21);

  const spanDays = recent.length > 1
    ? (new Date(recent[recent.length - 1].date).getTime() - new Date(recent[0].date).getTime()) / 86400000
    : 0;
  const longRange = spanDays > 60;

  return (
    <ResponsiveContainer width="100%" height={180}>
      <BarChart data={recent} margin={{ top: 5, right: 20, bottom: 5, left: 5 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.3} vertical={false} />
        <XAxis
          dataKey="date"
          className="text-[10px]"
          tickLine={false}
          tickFormatter={(d: string) => {
            const date = new Date(d);
            return longRange
              ? date.toLocaleDateString("en-US", { month: "short", year: "2-digit" })
              : date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
          }}
          interval={Math.max(Math.floor(recent.length / 5), 1)}
        />
        <YAxis
          className="text-[10px]"
          tickLine={false}
          width={45}
          tickFormatter={(v: number) => v >= 1000 ? `${(v / 1000).toFixed(0)}k` : String(v)}
        />
        <Tooltip
          cursor={{ fill: "var(--muted)", opacity: 0.3 }}
          contentStyle={{
            background: "var(--card)",
            border: "1px solid var(--border)",
            borderRadius: "8px",
            fontSize: "12px",
            color: "var(--card-foreground)",
          }}
          labelFormatter={(d) =>
            new Date(String(d)).toLocaleDateString("en-US", {
              weekday: "short",
              month: "short",
              day: "numeric",
            })
          }
          formatter={(value) => [Number(value).toLocaleString(), "Steps"]}
        />
        <ReferenceLine y={goal} stroke="oklch(65% 0.18 220)" strokeDasharray="4 2" strokeOpacity={0.5}
          label={{ value: "10K goal", position: "insideTopRight", fontSize: 9, fill: "oklch(65% 0.18 220)" }} />
        <Bar
          dataKey="steps"
          radius={[2, 2, 0, 0]}
          fill="oklch(65% 0.14 175)"
        />
      </BarChart>
    </ResponsiveContainer>
  );
}
