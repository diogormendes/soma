"use client";

import React, { useState, useRef, useCallback, useEffect, useMemo } from "react";
import { MACRO_COLORS } from "soma-style/colors";
import { Lock, Moon, Footprints, Dumbbell, ChevronLeft, ChevronRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { MealCaptureInput } from "@/components/meal-capture-input";
import { MealCaptureStatus } from "@/components/meal-capture-status";
import { slotForHour } from "@/lib/meal-capture";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MealCard } from "@/components/meal-card";
import { DrinkLogger } from "@/components/drink-logger";
import { ActivitySelector } from "@/components/activity-selector";
import { PrepSummary } from "@/components/prep-summary";
import type { SlotBudgets } from "@/lib/nutrition-types";
import type { MealItem } from "@/lib/meal-types";

// ── Types ─────────────────────────────────────────────────────

interface _NutritionPlan {
  date: string;
  plan: Record<string, unknown> | null;
  target_calories: number | null;
  target_protein: number | null;
  target_carbs: number | null;
  target_fat: number | null;
  target_fiber: number | null;
  tdee_used: number | null;
  exercise_calories: number | null;
  step_calories: number | null;
  deficit_used: number | null;
  adjustment_reason: string | null;
  sleep_quality_score: number | null;
  training_day_type: string | null;
  planned_workouts: unknown;
  step_goal: number | null;
  is_refeed: boolean;
  is_diet_break: boolean;
  status: string;
}

interface Meal {
  id: number;
  date: string;
  meal_slot: string;
  source: string | null;
  preset_meal_id: string | null;
  preset_name: string | null;
  preset_tags: string[] | null;
  portion_multiplier: number;
  items: MealItem[];
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  notes: string | null;
  weigh_method: string | null;
  logged_at: string;
}

interface Drink {
  id: number;
  date: string;
  drink_type: string;
  name: string;
  quantity: number;
  quantity_ml: number;
  calories: number;
  carbs: number;
  alcohol_grams: number;
  fat_oxidation_pause_hours: number;
  logged_at: string;
}

interface _Preset {
  id: string;
  name: string;
  items: MealItem[];
  tags: string[] | null;
}

interface _TrainingDay {
  run_type: string | null;
  run_title: string | null;
  target_distance_km: number | null;
  target_duration_min: number | null;
  load_level: string | null;
  gym_workout: string | null;
  plan_name: string | null;
}

interface _HealthSummary {
  total_steps: number | null;
  bmr_kilocalories: number | null;
  active_kilocalories: number | null;
  sleep_time_seconds: number | null;
}

interface _SleepDetail {
  total_sleep_seconds: number | null;
  deep_sleep_seconds: number | null;
  sleep_score: number | null;
}

/* eslint-disable @typescript-eslint/no-explicit-any */
interface NutritionDashboardProps {
  date: string;
  plan: any;
  meals: any[];
  drinks: any[];
  presets: any[];
  ingredients: any[];
  training: any;
  health: any;
  sleep: any;
}

// ── Helpers ───────────────────────────────────────────────────

const MEAL_SLOTS = ["breakfast", "lunch", "dinner", "pre_sleep"] as const;

/**
 * MacroBar — bounds-aware macro progress bar.
 *
 * Visual convention:
 *   - Floor marker (left-pointing wedge, teal): "eat at least here". When
 *     `current < floor` the text below the bar shows a muted "low" hint;
 *     fill stays macro color (we don't penalize mid-day under-eating with
 *     amber because the user is still filling up).
 *   - Ceiling marker (right-pointing wedge, warm): "don't cross this".
 *     When `current > ceiling` the fill and text turn amber.
 *   - If neither floor nor ceiling is passed, the bar renders as a pure
 *     progress fill with no markers.
 *
 * Per-macro usage:
 *   - Protein: floor = matrix target, ceiling = null (no scientific cap).
 *   - Fat: floor = target, ceiling = null.
 *   - Carbs: floor = target, ceiling = null (kcal-implicit upper).
 *   - Fiber: floor = target, ceiling = 60g (phytate cap, V2 §2.4).
 */
interface MacroMarker {
  value: number;
  label: string;
  /** 'achievement' (default): just a tier mark, no overlay past it.
   *  'softCeiling': orange overlay past this value (warning).
   *  'hardCeiling': red overlay + RED marker past this value (real ceiling). */
  kind?: "achievement" | "softCeiling" | "hardCeiling";
  /** Optimal hit-this target — renders the marker line in GREEN. Independent
   *  from `kind` (e.g. kcal target is BOTH softCeiling and optimal). */
  optimal?: boolean;
  /** Hover tooltip text. Falls back to "{label}: {value}" if not provided. */
  description?: string;
}

function MacroBar({
  label,
  current,
  target,
  color,
  floor,
  ceiling,
  markers,
  unit = "g" }: {
  label: string;
  current: number;
  target: number;
  color: string;
  floor?: number | null;
  ceiling?: number | null;
  /** Multi-goalposts. When provided, replaces floor/ceiling rendering with a
   *  research-anchored set of ticks. Crossed markers render dim, ahead markers
   *  bright. Bar fill stays in the macro's color until past the HIGHEST marker;
   *  past the highest, an extra red overlay signals "meaningfully over". */
  markers?: MacroMarker[];
  unit?: string;
}) {
  const useMulti = !!markers && markers.length > 0;
  const highest = useMulti ? Math.max(...markers!.map((m) => m.value)) : 0;
  const softCeiling = useMulti ? markers!.find((m) => m.kind === "softCeiling") : undefined;
  const hardCeiling = useMulti ? markers!.find((m) => m.kind === "hardCeiling") : undefined;

  // Axis scale: leave room past the highest anchor so all markers show.
  const axisAnchors = useMulti
    ? [highest * 1.15, current * 1.05, highest + 1]
    : [
        target * 1.15,
        floor != null ? floor * 1.15 : 0,
        ceiling != null ? ceiling * 1.05 : 0,
        current * 1.05,
        target + 1,
      ];
  const maxVal = Math.max(...axisAnchors);
  const fillPct = maxVal > 0 ? Math.min(100, (current / maxVal) * 100) : 0;

  const pastSoft = !!softCeiling && current > softCeiling.value;
  const pastHard = !!hardCeiling && current > hardCeiling.value;
  const softStartPct = softCeiling && maxVal > 0
    ? Math.min(100, (softCeiling.value / maxVal) * 100) : 0;
  const orangeEndValue = hardCeiling ? Math.min(current, hardCeiling.value) : current;
  const orangeEndPct = useMulti && maxVal > 0
    ? Math.min(100, (orangeEndValue / maxVal) * 100) : 0;
  const hardStartPct = hardCeiling && maxVal > 0
    ? Math.min(100, (hardCeiling.value / maxVal) * 100) : 100;

  // Display denominator: prefer soft ceiling if exists, else hard ceiling,
  // else highest achievement tier.
  const displayRef = useMulti ? (softCeiling?.value ?? hardCeiling?.value ?? highest) : target;

  // Legacy floor/ceiling support (used when markers prop not provided).
  const floorPct = !useMulti && floor != null && maxVal > 0
    ? Math.min(100, (floor / maxVal) * 100) : null;
  const ceilingPct = !useMulti && ceiling != null && maxVal > 0
    ? Math.min(100, (ceiling / maxVal) * 100) : null;
  const overCeiling = !useMulti && ceiling != null && current > ceiling;
  const underFloor = !useMulti && floor != null && current < floor;

  return (
    <div className="space-y-0.5">
      <div className="flex justify-between text-xs lg:text-sm text-muted-foreground">
        <span>{label}</span>
        <span className={pastHard || overCeiling ? "text-red-500 font-medium" : pastSoft ? "text-amber-500 font-medium" : ""}>
          {Math.round(current)}/{Math.round(displayRef)}{unit}
          {underFloor && (
            <span className="ml-1 text-[10px] text-muted-foreground/70">
              (−{Math.round(floor! - current)} to floor)
            </span>
          )}
        </span>
      </div>
      <div className="relative h-2 rounded-full overflow-hidden bg-muted">
        {/* Legacy ceiling danger zone (only when not using multi-markers) */}
        {!useMulti && ceilingPct !== null && (
          <div
            className="absolute right-0 top-0 h-full bg-amber-500/10"
            style={{ width: `${100 - ceilingPct}%` }}
          />
        )}
        {/* Fill */}
        <div
          className={`absolute left-0 top-0 h-full rounded-full transition-all ${
            overCeiling && !useMulti ? "bg-amber-500" : color
          }`}
          style={{ width: `${fillPct}%` }}
        />
        {/* Soft-ceiling overlay (orange) — only when macro has a soft ceiling
            and current has crossed it. Stops at the hard ceiling (or current). */}
        {useMulti && pastSoft && orangeEndPct > softStartPct && (
          <div
            className="absolute top-0 h-full bg-amber-500"
            style={{ left: `${softStartPct}%`, width: `${orangeEndPct - softStartPct}%` }}
          />
        )}
        {/* Hard-ceiling overlay (red) — only when macro has a hard ceiling
            and current has crossed it. */}
        {useMulti && pastHard && (
          <div
            className="absolute top-0 h-full bg-red-500"
            style={{ left: `${hardStartPct}%`, width: `${fillPct - hardStartPct}%` }}
          />
        )}
        {/* Multi-markers — color-coded by meaning, always visible.
            Red = hardCeiling (don't cross). Green = optimal hit-this target.
            White = other achievement tier. Crossed renders at /40 opacity.
            Dark 1px shadow ring ensures the marker stays visible even
            when its color matches the underlying bar fill (e.g. green
            optimal marker on a green fiber bar — would otherwise blend). */}
        {useMulti && markers!.map((m, i) => {
          const pct = Math.min(100, (m.value / maxVal) * 100);
          const crossed = current >= m.value;
          const colorClass =
            m.kind === "hardCeiling"
              ? (crossed ? "bg-red-500/40" : "bg-red-500")
              : m.optimal
                ? (crossed ? "bg-green-500/40" : "bg-green-500")
                : (crossed ? "bg-foreground/40" : "bg-foreground");
          return (
            <div
              key={i}
              className={`absolute top-0 h-full w-[2px] shadow-[0_0_0_1px_rgba(0,0,0,0.7)] ${colorClass}`}
              style={{ left: `calc(${Math.min(pct, 99.5)}% - 1px)` }}
              title={
                m.description
                  ? `${m.description} (${Math.round(m.value)}${unit})`
                  : `${m.label}: ${Math.round(m.value)}${unit}`
              }
            />
          );
        })}
        {/* Legacy floor marker */}
        {floorPct !== null && floor! > 0 && (
          <div
            className="absolute top-0 h-full w-[2px] bg-teal-500/70"
            style={{ left: `calc(${Math.min(floorPct, 99.5)}% - 1px)` }}
            title={`Floor: ${Math.round(floor!)}${unit} — aim to reach this`}
          />
        )}
        {/* Legacy ceiling marker */}
        {ceilingPct !== null && ceiling! > 0 && (
          <div
            className="absolute top-0 h-full w-[2px] bg-amber-500"
            style={{ left: `calc(${Math.min(ceilingPct, 99.5)}% - 1px)` }}
            title={`Ceiling: ${Math.round(ceiling!)}${unit} — do not exceed`}
          />
        )}
      </div>
    </div>
  );
}

// ── Component ─────────────────────────────────────────────────

export function NutritionDashboard({
  date,
  plan: initialPlan,
  meals: initialMeals,
  drinks: initialDrinks,
  presets: initialPresets,
  ingredients,
  training,
  health,
  sleep }: NutritionDashboardProps) {
  // Bumped on every send, so the status strip refetches at once rather than waiting for its
  // own poll. A counter rather than a boolean, because two sends in a row must both show.
  const [captureVersion, setCaptureVersion] = useState(0);
  const [plan, setPlan] = useState(initialPlan);
  const [meals, setMeals] = useState<Meal[]>(initialMeals);
  const [drinks, setDrinks] = useState<Drink[]>(initialDrinks);
  const [presets, setPresets] = useState(initialPresets);
  const [closing, setClosing] = useState(false);
  const [copying, setCopying] = useState(false);
  // workoutEnabled removed — activity toggles now flow through API via ActivitySelector
  const [runEnabled, setRunEnabled] = useState<boolean>(initialPlan?.run_enabled ?? true);
  const [selectedWorkouts, setSelectedWorkouts] = useState<string[]>(initialPlan?.selected_workouts ?? []);
  const [_gymCalories, setGymCalories] = useState<number>(0);
  const [skippedSlots, setSkippedSlots] = useState<string[]>(initialPlan?.skipped_slots ?? []);
  const [slotBudgets, setSlotBudgets] = useState<SlotBudgets | null>(null);
  const [budgetExpanded, setBudgetExpanded] = useState(false);
  const [breakdown, setBreakdown] = useState<any>(null);
  const [trend7d, setTrend7d] = useState<any>(null);
  // Today's estimate from the scale when the day is not fully logged (soma#891).
  const [deficitEstimate, setDeficitEstimate] = useState<any>(null);
  const fmtShort = (d: string | null | undefined) => d ? new Date(d + "T12:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "?";
  const [adaptive, setAdaptive] = useState<any>(null);
  // Engagement-aware rendering (#698): is nutrition actually in use this
  // week, and what does the scale say regardless of logging.
  const [engagement, setEngagement] = useState<any>(null);
  const [weightTrend, setWeightTrend] = useState<any>(null);
  const [weightTrendPrimary, setWeightTrendPrimary] = useState<boolean>(false);
  // Close-day prompt: which slots are neither logged nor explicitly skipped.
  const [closePrompt, setClosePrompt] = useState<string[] | null>(null);
  const [dataReady, setDataReady] = useState(false);
  const [rebalanceToast, setRebalanceToast] = useState<string | null>(null);

  const isClosed = plan?.status === "closed";

  const refreshData = useCallback(async () => {
    try {
      const [planRes, presetsRes] = await Promise.all([
        fetch(`/api/nutrition/plan?date=${date}`),
        fetch("/api/nutrition/presets"),
      ]);
      if (planRes.ok) {
        const data = await planRes.json();
        if (data.plan) setPlan(data.plan);
        if (data.meals) setMeals(data.meals);
        if (data.drinks) setDrinks(data.drinks);
        setRunEnabled(data.runEnabled ?? true);
        setSelectedWorkouts(data.selectedWorkouts ?? []);
        setGymCalories(data.gymCalories ?? 0);
        setSkippedSlots(data.skippedSlots ?? []);
        if (data.slotBudgets) setSlotBudgets(data.slotBudgets);
        if (data.breakdown) setBreakdown(data.breakdown);
        if (data.trend7d) setTrend7d(data.trend7d);
        setDeficitEstimate(data.deficitEstimate ?? null);
        setAdaptive(data.adaptive ?? null);
        setEngagement(data.engagement ?? null);
        setWeightTrend(data.weightTrend ?? null);
        setWeightTrendPrimary(Boolean(data.weightTrendPrimary));
      }
      if (presetsRes.ok) {
        const presetsData = await presetsRes.json();
        if (presetsData.presets) setPresets(presetsData.presets);
      }
      setDataReady(true);
    } catch {
      setDataReady(true);
    }
  }, [date]);

  const rebalanceMeals = useCallback(async (changedSlot?: string) => {
    try {
      const res = await fetch("/api/nutrition/rebalance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date, changedSlot, lockedSlots: Array.from(lockedSlotsRef.current) }) });
      if (!res.ok) return;
      const data = await res.json();
      if (data.changes && data.changes.length > 0) {
        const msg = data.changes
          .map((c: any) => `${c.ingredient} ${c.from}g \u2192 ${c.to}g`)
          .join(", ");
        setRebalanceToast(msg);
        setTimeout(() => setRebalanceToast(null), 5000);
        await refreshData();
      }
    } catch {}
  }, [date, refreshData]);

  const handleMealChanged = useCallback(async (changedSlot?: string) => {
    await refreshData();
    await rebalanceMeals(changedSlot);
  }, [refreshData, rebalanceMeals]);

  // Load breakdown + trend data on mount
  useEffect(() => {
    refreshData();
  }, [refreshData]);

  // The rebalance callback reads the locked slots through a ref written after render, so its
  // identity stays stable while the value it sends is always the current one (soma#958).
  const lockedSlotsRef = useRef<Set<string>>(new Set());

  // Locked slots (won't be rebalanced) — persisted in localStorage per date
  const [lockedSlots, setLockedSlots] = useState<Set<string>>(() => {
    if (typeof window === "undefined") return new Set();
    try {
      const stored = localStorage.getItem(`locked-slots-${date}`);
      return stored ? new Set(JSON.parse(stored)) : new Set();
    } catch { return new Set(); }
  });
  useEffect(() => {
    lockedSlotsRef.current = lockedSlots;
  }, [lockedSlots]);

  const handleLockToggle = useCallback((slot: string) => {
    setLockedSlots(prev => {
      const next = new Set(prev);
      if (next.has(slot)) next.delete(slot);
      else next.add(slot);
      try { localStorage.setItem(`locked-slots-${date}`, JSON.stringify([...next])); } catch {}
      return next;
    });
  }, [date]);

  // Live preview totals from compose view
  const [previewTotals, setPreviewTotals] = useState<Record<string, { calories: number; protein: number; carbs: number; fat: number; fiber: number }>>({});

  const handleTotalsPreview = useCallback((slot: string, totals: { calories: number; protein: number; carbs: number; fat: number; fiber: number } | null) => {
    setPreviewTotals(prev => {
      if (totals === null) {
        const next = { ...prev };
        delete next[slot];
        return next;
      }
      return { ...prev, [slot]: totals };
    });
  }, []);

  // Sum preview totals from any active compose views
  const previewCal = Object.values(previewTotals).reduce((s, t) => s + t.calories, 0);
  const previewProtein = Object.values(previewTotals).reduce((s, t) => s + t.protein, 0);
  const previewCarbs = Object.values(previewTotals).reduce((s, t) => s + t.carbs, 0);
  const previewFat = Object.values(previewTotals).reduce((s, t) => s + t.fat, 0);
  const previewFiber = Object.values(previewTotals).reduce((s, t) => s + t.fiber, 0);

  // Compute consumed totals (logged meals + live preview)
  const consumedCal =
    meals.reduce((s, m) => s + Number(m.calories || 0), 0) +
    drinks.reduce((s, d) => s + Number(d.calories || 0), 0) +
    previewCal;
  const consumedProtein = meals.reduce(
    (s, m) => s + Number(m.protein || 0),
    0
  ) + previewProtein;
  const consumedCarbs =
    meals.reduce((s, m) => s + Number(m.carbs || 0), 0) +
    drinks.reduce((s, d) => s + Number(d.carbs || 0), 0) +
    previewCarbs;
  const consumedFat = meals.reduce((s, m) => s + Number(m.fat || 0), 0) + previewFat;
  const consumedFiber = meals.reduce((s, m) => s + Number(m.fiber || 0), 0) + previewFiber;

  // Use breakdown-adjusted targets (computed by plan API accounting for run/gym toggles)
  // Fall back to raw plan values for initial render before breakdown loads
  const targetCal = breakdown?.adjustedTargets?.calories ?? (Number(plan?.target_calories) || 0);
  const targetProtein = breakdown?.adjustedTargets?.protein ?? (Number(plan?.target_protein) || 0);
  const targetCarbs = breakdown?.adjustedTargets?.carbs ?? (Number(plan?.target_carbs) || 0);
  const targetFat = breakdown?.adjustedTargets?.fat ?? (Number(plan?.target_fat) || 0);
  const targetFiber = breakdown?.adjustedTargets?.fiber ?? (Number(plan?.target_fiber) || 0);
  const remainingCal = targetCal - consumedCal;

  const _adjustmentReason =
    plan?.adjustment_reason ??
    (plan?.plan ? (plan.plan as Record<string, any>).adjustment_reason : null);

  const trainingDistanceKm = Number(training?.target_distance_km) || 0;
  const trainingDurationMin = Number(training?.target_duration_min) || 0;
  const showDuringWorkout = trainingDurationMin > 60 || trainingDistanceKm > 10;

  const slots = showDuringWorkout
    ? [...MEAL_SLOTS, "during_workout" as const]
    : [...MEAL_SLOTS];


  // Slots that are neither logged with calories nor explicitly skipped. These
  // are ABSENT, not zero: closing over them silently would turn a
  // breakfast-only day into a 600-kcal "intake" (#699, #703).
  const unloggedSlots = useMemo(() => {
    const logged = new Set(
      meals.filter((m: any) => Number(m.calories) > 0).map((m: any) => String(m.meal_slot)),
    );
    return ["breakfast", "lunch", "dinner", "pre_sleep"].filter(
      (s) => !logged.has(s) && !skippedSlots.includes(s),
    );
  }, [meals, skippedSlots]);

  const postClose = async () => {
    setClosing(true);
    try {
      const res = await fetch("/api/nutrition/close-day", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date }) });
      if (res.ok) {
        await refreshData();
      }
    } finally {
      setClosing(false);
      setClosePrompt(null);
    }
  };

  // Close day handler. Asks ONCE about unlogged slots so the day can become
  // complete (skipped) or stay open, instead of closing over absent data.
  const handleCloseDay = async () => {
    if (unloggedSlots.length > 0) {
      setClosePrompt(unloggedSlots);
      return;
    }
    await postClose();
  };

  // "I did not eat those": mark each unlogged slot skipped, then close.
  const skipUnloggedAndClose = async () => {
    setClosing(true);
    try {
      for (const slot of closePrompt ?? []) {
        await fetch("/api/nutrition/skip-slot", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ date, slot }) });
      }
    } finally {
      setClosing(false);
    }
    await postClose();
  };

  // Format sleep hours
  const sleepHours = sleep?.total_sleep_seconds
    ? (Number(sleep.total_sleep_seconds) / 3600).toFixed(1)
    : null;

  return (
    <div className="space-y-4 lg:grid lg:grid-cols-[420px_1fr] lg:gap-8 lg:space-y-0 lg:max-w-5xl lg:mx-auto">
      {/* ── LEFT COLUMN: summary & controls ──
          Not sticky/height-capped: the column's content is taller than the
          viewport, and a sticky element taller than the viewport pins its top so
          the bottom never scrolls into view (with scrollbar-none the overflow was
          also invisible → ~495px was unreachable). Flow it normally so page scroll
          reaches everything. */}
      <div className="space-y-4 lg:self-start">
        {/* Say what you ate. First thing on the page, because the old flow's friction is what
            stopped the logging, and this is the shortest path from a sentence to a meal. */}
        <MealCaptureInput
          slot={slotForHour(new Date().getHours())}
          defaultMode="log"
          onCaptured={() => { setCaptureVersion((v) => v + 1); void refreshData(); }}
        />
        {/* Where those sentences got to. Directly under the box, because the question it is
            answering is "did that go anywhere", and that is asked of the box. */}
        <MealCaptureStatus date={date} version={captureVersion} />

        {/* Date header with navigation */}
        <div className="flex items-center justify-between">
          <a href={`/nutrition?date=${(() => { const d = new Date(date + "T12:00:00"); d.setDate(d.getDate() - 1); return d.toISOString().slice(0, 10); })()}`}>
            <Button variant="ghost" size="icon"><ChevronLeft className="h-4 w-4" /></Button>
          </a>
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-semibold">
              {new Date(date + "T12:00:00").toLocaleDateString("en-US", {
                weekday: "long",
                month: "short",
                day: "numeric" })}
            </h1>
            {isClosed && (
              <Badge variant="secondary" className="gap-1">
                <Lock className="h-3 w-3" />
                Closed
              </Badge>
            )}
            {isClosed && (
              <button
                onClick={async () => {
                  await fetch("/api/nutrition/reopen-day", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ date }) });
                  await refreshData();
                }}
                className="text-[10px] text-muted-foreground hover:text-foreground underline ml-1"
              >
                reopen
              </button>
            )}
          </div>
          <a href={`/nutrition?date=${(() => { const d = new Date(date + "T12:00:00"); d.setDate(d.getDate() + 1); return d.toISOString().slice(0, 10); })()}`}>
            <Button variant="ghost" size="icon"><ChevronRight className="h-4 w-4" /></Button>
          </a>
        </div>

        {/* Sleep adjustment banner — disabled, sleep adjustments are off */}

        {/* Budget card */}
        {targetCal > 0 ? (
          <Card>
            <CardContent className="pt-4 space-y-3">
              {/* Main calories display */}
              <div className="text-center">
                {!dataReady ? (
                  <div className="h-12 flex items-center justify-center">
                    <div className="text-sm text-muted-foreground animate-pulse">calculating...</div>
                  </div>
                ) : (
                  <>
                    <div className={`text-4xl lg:text-5xl font-bold tabular-nums ${remainingCal < 0 ? "text-rose-500" : ""}`}>
                      {remainingCal < 0 ? `+${Math.abs(Math.round(remainingCal))}` : Math.round(remainingCal)}
                    </div>
                    <div className="text-xs lg:text-sm text-muted-foreground">
                      {remainingCal < 0 ? "over goal" : "to goal"}
                    </div>
                  </>
                )}
              </div>

              {/* Burn-based bar with goal marker */}
              {dataReady && breakdown && (() => {
                const totalBurn = breakdown.totalBurn || 0;
                // A closed day's breakdown carries no target, which read as "0 goal" (soma#869).
                const goalIntake = breakdown.targetIntake || Number(plan?.target_calories) || 0;
                const deficit = breakdown.deficit || 0;
                const eatPct = totalBurn > 0 ? Math.min(100, (consumedCal / totalBurn) * 100) : 0;
                const goalPct = totalBurn > 0 ? Math.min(100, (goalIntake / totalBurn) * 100) : 0;
                const currentDeficit = consumedCal - totalBurn;
                return (
                  <div className="space-y-1">
                    {/* Bar with 3 hover zones */}
                    <div className="relative h-3 rounded-full overflow-hidden bg-muted">
                      {/* Ceiling danger zone (right of goal) — muted warm */}
                      <div
                        className="absolute right-0 top-0 h-full bg-amber-500/10"
                        style={{ width: `${100 - goalPct}%` }}
                        title={`Deficit goal: −${deficit} kcal\nTotal burn: ${totalBurn} kcal`}
                      />
                      {/* Zone 2: Room to goal (between eaten and goal) — transparent hover target */}
                      {eatPct < goalPct && (
                        <div
                          className="absolute top-0 h-full"
                          style={{ left: `${eatPct}%`, width: `${goalPct - eatPct}%` }}
                          title={`${Math.round(goalIntake - consumedCal)} kcal to goal\nGoal: eat ≤ ${goalIntake} kcal`}
                        />
                      )}
                      {/* Zone 1: Eaten fill */}
                      <div
                        className={`absolute left-0 top-0 h-full rounded-full transition-all ${consumedCal > goalIntake ? "bg-amber-500" : "bg-primary"}`}
                        style={{ width: `${eatPct}%` }}
                        title={`Eaten: ${Math.round(consumedCal)} kcal`}
                      />
                      {/* Ceiling marker (warm) — 'don't cross' the kcal
                          goal. Clamped to stay inside overflow-hidden when
                          goalPct hits 100% (e.g. deficit=0 days). */}
                      <div
                        className="absolute top-0 h-full w-[2px] bg-amber-500"
                        style={{ left: `calc(${Math.min(goalPct, 99.5)}% - 1px)` }}
                        title={`Ceiling: eat ≤ ${goalIntake} kcal${deficit > 0 ? ` (−${deficit} deficit)` : " (maintenance)"}`}
                      />
                    </div>
                    {/* Labels under bar */}
                    <div className="flex justify-between text-[10px] text-muted-foreground">
                      <span>{Math.round(consumedCal)} eaten</span>
                      <span>{goalIntake} goal{deficit > 0 && <span className="text-muted-foreground/50"> (&minus;{deficit})</span>}</span>
                      <span>{totalBurn} burn</span>
                    </div>
                    {/* Current deficit — only a claim when today is actually
                        observed. With nothing logged, "eaten − burn" is a
                        fabricated −2363 in green, which is exactly the
                        "assumes I'm always in deficit" complaint (#698, #703).
                        Below the coverage floor, say what is true instead. */}
                    {(() => {
                      const loggedSlotCount = 4 - unloggedSlots.length;
                      // Observed = closed by hand or every slot logged or skipped (soma#891);
                      // the route says which. Without it, the older three-slot floor.
                      const todayObserved = isClosed || (deficitEstimate ? deficitEstimate.source === "observed" : loggedSlotCount >= 3);
                      if (todayObserved) {
                        return (
                          <div className="text-xs text-center" data-testid="hero-deficit">
                            <span className={currentDeficit < 0 ? "text-green-500" : "text-rose-500"}>{currentDeficit > 0 ? "+" : ""}{Math.round(currentDeficit)} current deficit</span>
                          </div>
                        );
                      }
                      // Not observed, but the scale knows the rate: say the estimate,
                      // marked as one, and between which weigh-ins it comes from (soma#891).
                      const est = deficitEstimate && (deficitEstimate.source === "partial" || deficitEstimate.source === "extrapolated") ? deficitEstimate : null;
                      if (est) {
                        return (
                          <div className="text-xs text-center text-muted-foreground" data-testid="hero-deficit-estimate">
                            <span className={est.deficit <= 0 ? "text-green-500/80" : "text-rose-500/80"}>~{est.deficit > 0 ? "+" : ""}{est.deficit} estimated deficit</span>
                            <span className="block text-[10px] text-muted-foreground/70">
                              {loggedSlotCount === 0 ? "nothing logged yet" : `${loggedSlotCount} of 4 meals logged`} · rest extrapolated between {fmtShort(est.intervalStart)} and {fmtShort(est.intervalEnd)}
                            </span>
                          </div>
                        );
                      }
                      return (
                        <div className="text-xs text-center text-muted-foreground" data-testid="hero-not-observed">
                          {loggedSlotCount === 0
                            ? "nothing logged yet · deficit unknown"
                            : `${Math.round(consumedCal)} eaten so far · ${loggedSlotCount} of 4 meals logged · deficit unknown`}
                        </div>
                      );
                    })()}
                    {/* The scale, at hero level, whenever logging is not
                        carrying the week — visible without expanding. */}
                    {weightTrendPrimary && weightTrend && (
                      <div className="text-[11px] text-center text-muted-foreground" data-testid="hero-weight-trend">
                        Scale: {weightTrend.basis}
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* Expand/collapse toggle — hidden on desktop (details always shown) */}
              <button
                className="w-full text-[10px] text-muted-foreground text-center hover:text-foreground transition-colors lg:hidden"
                onClick={() => setBudgetExpanded(!budgetExpanded)}
              >
                {budgetExpanded ? "\u25B2 hide details" : "\u25BC show details"}
              </button>

              {/* Expanded breakdown — always visible on desktop, toggle on mobile */}
              <div className={`${budgetExpanded ? "" : "hidden"} lg:block`}>
                {breakdown && (
                  <div className="space-y-3 border-t pt-3">
                    {/* Calorie equation breakdown */}
                    <div className="space-y-1">
                      <div className="text-[10px] lg:text-xs font-medium text-muted-foreground uppercase tracking-wider">Calorie Breakdown</div>
                      <div className="grid grid-cols-[1fr_auto] gap-x-4 gap-y-0.5 text-xs">
                        <span className="text-muted-foreground">Passive burn (BMR)</span>
                        <span className="tabular-nums text-right">{breakdown.bmr}</span>

                        <span className="text-muted-foreground">
                          Steps ({breakdown.actualSteps !== null && breakdown.actualSteps !== undefined
                            ? `${breakdown.actualSteps.toLocaleString()} actual`
                            : `${(breakdown.expectedSteps || breakdown.stepGoal || 10000).toLocaleString()} expected`})
                          {breakdown.runStepEstimate > 0 && (
                            <span className="text-[10px]"> excl. ~{breakdown.runStepEstimate} run steps</span>
                          )}
                        </span>
                        <span className="tabular-nums text-right text-green-500">
                          +{breakdown.stepCalories}
                          {breakdown.stepCaloriesPredicted !== undefined && breakdown.stepCalories !== breakdown.stepCaloriesPredicted && (
                            <span className="text-muted-foreground/50 text-[9px] ml-1">(~{breakdown.stepCaloriesPredicted})</span>
                          )}
                        </span>

                        {breakdown.runCalories > 0 && (
                          <>
                            <span className="text-muted-foreground">
                              Run ({breakdown.runActual && breakdown.runActualDistKm ? breakdown.runActualDistKm : breakdown.runDistanceKm}km)
                              <span className={`ml-1 text-[9px] ${breakdown.runActual ? "text-green-500" : "text-amber-500"}`}>
                                {breakdown.runActual ? "actual" : "predicted"}
                              </span>
                            </span>
                            <span className="tabular-nums text-right text-green-500">
                              +{breakdown.runCalories}
                              {breakdown.runActual && breakdown.runPredicted > 0 && breakdown.runCalories !== breakdown.runPredicted && (
                                <span className="text-muted-foreground/50 text-[9px] ml-1">(~{breakdown.runPredicted})</span>
                              )}
                            </span>
                          </>
                        )}

                        {breakdown.gymBreakdown && breakdown.gymBreakdown.length > 0 ? (
                          breakdown.gymBreakdown.map((w: any) => (
                            <React.Fragment key={w.title}>
                              <span className="text-muted-foreground">
                                Gym: {w.title}
                                <span className={`ml-1 text-[9px] ${w.actual ? "text-green-500" : "text-amber-500"}`}>
                                  {w.actual ? "actual" : "predicted"}
                                </span>
                              </span>
                              <span className="tabular-nums text-right text-green-500">
                                +{w.calories}
                                {w.actual && w.predicted > 0 && w.calories !== w.predicted && (
                                  <span className="text-muted-foreground/50 text-[9px] ml-1">(~{w.predicted})</span>
                                )}
                              </span>
                            </React.Fragment>
                          ))
                        ) : breakdown.gymCalories > 0 ? (
                          <>
                            <span className="text-muted-foreground">
                              Gym ({breakdown.selectedWorkouts?.join(", ")})
                            </span>
                            <span className="tabular-nums text-right text-green-500">+{breakdown.gymCalories}</span>
                          </>
                        ) : null}

                        <span className="text-muted-foreground font-medium border-t pt-1">Total burn</span>
                        <span className="tabular-nums text-right font-bold border-t pt-1">{breakdown.totalBurn}</span>
                      </div>
                    </div>

                    {/* Per-slot kcal pacing. P/C/F/Fi are intentionally not
                        split across slots — no scientific basis for per-slot
                        non-kcal allocation. See lib/nutrition-types.ts. */}
                    {slotBudgets && (
                      <div className="space-y-1">
                        <div className="text-[10px] lg:text-xs font-medium text-muted-foreground uppercase tracking-wider">Per-Meal kcal Pacing</div>
                        {skippedSlots.length >= 4 ? (
                          <div className="text-xs text-muted-foreground text-center py-2">Fasting day — all meals skipped</div>
                        ) : (
                          <div className="grid grid-cols-[1fr_auto] gap-x-3 gap-y-0.5 text-xs">
                            <span className="text-muted-foreground text-[10px]">Slot</span>
                            <span className="text-muted-foreground text-[10px] text-right">kcal</span>
                            {Object.entries(slotBudgets).map(([slot, macros]) => (
                              <React.Fragment key={slot}>
                                <span className={skippedSlots.includes(slot) ? "text-muted-foreground/50 line-through" : ""}>
                                  {slot.replace("_", "-")}
                                </span>
                                <span className="tabular-nums text-right">{Math.round(macros.calories)}</span>
                              </React.Fragment>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Engagement + the scale (#698, #702, #703).
                        The scale is the ground truth that survives not logging.
                        When the week is not fully engaged it leads; the
                        log-derived totals below are hidden rather than shown
                        as a deficit computed from nothing. */}
                    {engagement && (
                      <div className="space-y-1" data-testid="nutrition-engagement">
                        <div className="flex items-center justify-between">
                          <div className="text-[10px] lg:text-xs font-medium text-muted-foreground uppercase tracking-wider">
                            {weightTrendPrimary ? "Scale" : "This Week"}
                          </div>
                          <div className="text-[9px] text-muted-foreground/60" data-testid="nutrition-engagement-basis">
                            {engagement.basis}
                          </div>
                        </div>
                        {weightTrend && (
                          <div className="flex justify-between items-baseline gap-3 text-xs" data-testid="nutrition-weight-trend">
                            <span className="text-muted-foreground shrink-0">
                              {weightTrend.kgPerWindow != null ? "Weight trend" : "Weight"}
                            </span>
                            <span className={`tabular-nums text-right ${weightTrend.kgPerWindow == null ? "text-muted-foreground" : weightTrend.kgPerWindow < 0 ? "text-green-500" : weightTrend.kgPerWindow > 0 ? "text-amber-400" : ""}`}>
                              {weightTrend.basis}
                            </span>
                          </div>
                        )}
                        {engagement.state === "absent" && (
                          <div className="text-xs text-muted-foreground" data-testid="nutrition-not-tracking">
                            Not tracking meals this week. Weigh in to keep the trend honest.
                          </div>
                        )}
                        {engagement.state === "partial" && (
                          <div className="text-xs text-muted-foreground" data-testid="nutrition-partial">
                            Partly logged. Weekly totals show after {engagement.weekFloorDays} full days; skip a meal you did not eat so the day counts.
                          </div>
                        )}
                      </div>
                    )}

                    {/* 7-day trend table */}
                    {trend7d && trend7d.days.length > 0 && (
                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <div className="text-[10px] lg:text-xs font-medium text-muted-foreground uppercase tracking-wider">7-Day Trend</div>
                          <div className="text-[9px] text-muted-foreground/60">goal: &minus;{trend7d.goalDeficit}/day</div>
                        </div>
                        <div className="grid grid-cols-[1fr_auto] sm:grid-cols-[1fr_auto_auto] gap-x-3 gap-y-0.5 text-xs" data-testid="trend-table">
                          <span className="text-muted-foreground text-[10px]">Date</span>
                          <span className="text-muted-foreground text-[10px] text-right hidden sm:block">Ate / Burn</span>
                          <span className="text-muted-foreground text-[10px] text-right">Deficit / Goal</span>
                          {trend7d.days.map((d: any) => {
                            const dayLabel = new Date(d.date + "T12:00:00").toLocaleDateString("en-US", { weekday: "short", month: "numeric", day: "numeric" });
                            const deficitColor = d.deficit <= -trend7d.goalDeficit ? "text-green-500"
                              : d.deficit < 0 ? "text-amber-500"
                              : d.deficit > 0 ? "text-rose-500" : "text-muted-foreground";
                            // Any open day is in progress, today or a past day never
                            // closed: its ate is the running log (#717), so it reads
                            // parenthesised and muted, never as a settled deficit.
                            const isInProgress = !d.closed;
                            // Since soma#891 a day that was not fully logged is estimated from
                            // the scale: "~" marks it and the row is greyed. Only a day nothing
                            // can be said about (no plan, or no scale) shows a dash.
                            const src: string = d.source ?? (d.counted ? "observed" : "unknown");
                            const est = src === "extrapolated" || src === "partial";
                            const unobserved = src === "unknown" && (d.coverage ?? 0) === 0 && !(d.ate > 0);
                            // Colour is a verdict; only an observed, counted day earns one (#699).
                            const tone = est ? "text-muted-foreground" : d.counted ? deficitColor : "text-muted-foreground";
                            const sign = d.deficit > 0 ? "+" : "";
                            const ateText = unobserved ? "\u2013" : est ? `~${d.ate}` : isInProgress ? `(${d.ate})` : d.ate || "\u2013";
                            const defText = unobserved ? "\u2013" : est ? `~${sign}${d.deficit}` : isInProgress ? `(${sign}${d.deficit})` : d.ate > 0 ? `${sign}${d.deficit}` : "\u2013";
                            return (
                              <React.Fragment key={d.date}>
                                <span className={est ? "text-muted-foreground" : ""}>
                                  {dayLabel}
                                  <span className="block sm:hidden text-[9px] text-muted-foreground/60">
                                    ate {ateText} · burn {d.burn}
                                  </span>
                                </span>
                                <span className={`tabular-nums text-right hidden sm:block ${isInProgress || est ? "text-muted-foreground" : ""}`} data-testid={`trend-ate-${d.date}`}>
                                  {ateText} / {d.burn || "\u2013"}
                                </span>
                                <span className={`tabular-nums text-right font-medium ${tone}`} data-testid={`trend-deficit-${d.date}`} data-counted={d.counted ? "1" : "0"} data-source={src}>
                                  {defText} / &minus;{trend7d.goalDeficit}
                                </span>
                              </React.Fragment>
                            );
                          })}
                          {/* Total — only over a fully engaged week. A total over
                              two closed days is not a week's deficit (#699, #703). */}
                          {trend7d.closedDays > 0 && (engagement?.state === "complete" || trend7d.days.every((d: any) => d.counted)) && (() => {
                            const total = trend7d.totalDeficit; // negative = deficit
                            const goal = -(trend7d.closedDays * trend7d.goalDeficit); // negative target
                            return (
                              <React.Fragment key="trend-total">
                                <span className="font-medium border-t pt-1">Total ({trend7d.closedDays}d{trend7d.days.some((d: any) => d.source === "extrapolated" || d.source === "partial") ? " ~" : ""})</span>
                                <span className="border-t pt-1 hidden sm:block" />
                                <span className={`tabular-nums text-right font-bold border-t pt-1 ${total <= goal ? "text-green-500" : "text-amber-500"}`}>
                                  {total > 0 ? "+" : ""}{Math.round(total)} / {goal}
                                </span>
                              </React.Fragment>
                            );
                          })()}
                        </div>
                        {trend7d.adherence && (engagement?.state === "complete" || trend7d.days.every((d: any) => d.counted)) && (() => {
                          const a = trend7d.adherence;
                          const label = a.status === "on_track" ? "on track" : a.status === "under" ? "under goal" : "over goal";
                          const color = a.status === "on_track" ? "text-green-500" : "text-amber-400";
                          return (
                            <div className="flex justify-between items-baseline text-[10px] mt-1 pt-1 border-t border-white/10">
                              <span className="text-muted-foreground">Weekly adherence</span>
                              <span className={`${color} tabular-nums`}>{label} · {Math.round(a.ratio * 100)}%</span>
                            </div>
                          );
                        })()}
                        {(() => {
                          const e = trend7d.days.find((d: any) => d.source === "extrapolated" || d.source === "partial");
                          return e ? (
                            <div className="text-[9px] text-muted-foreground/60" data-testid="trend-estimate-note">~ estimated from the scale between {fmtShort(e.intervalStart)} and {fmtShort(e.intervalEnd)}</div>
                          ) : null;
                        })()}
                        {trend7d.days.some((d: any) => d.manual) && (
                          <div className="text-[9px] text-muted-foreground/60">* offset target in parentheses · +/− vs {trend7d.goalDeficit}/day goal</div>
                        )}
                      </div>
                    )}
                    {adaptive && (adaptive.driftFlag || adaptive.dietBreakLevel !== "none") && (() => {
                      const level = adaptive.dietBreakLevel as string;
                      const levelColor = level === "mandatory" ? "text-red-500"
                        : level === "strong" ? "text-orange-400"
                        : level === "suggested" ? "text-amber-400" : "text-muted-foreground";
                      const levelLabel = level === "mandatory" ? "Diet break due"
                        : level === "strong" ? "Diet break strongly advised"
                        : level === "suggested" ? "Diet break suggested" : null;
                      return (
                        <div className="mt-3 pt-3 border-t border-white/10 space-y-1">
                          <div className="text-[10px] lg:text-xs font-medium text-muted-foreground uppercase tracking-wider">Adaptive</div>
                          {levelLabel && (
                            <div className="flex justify-between items-baseline text-xs">
                              <span className={`font-medium ${levelColor}`}>{levelLabel}</span>
                              <span className="text-muted-foreground tabular-nums">{adaptive.deficitDurationDays}d in deficit</span>
                            </div>
                          )}
                          {adaptive.driftFlag && (
                            <div className="flex justify-between items-baseline text-xs">
                              <span className="text-amber-400">TDEE drift</span>
                              <span className="text-muted-foreground tabular-nums">
                                ~{Math.round(adaptive.effectiveTdee)} vs {Math.round(adaptive.reportedTdee)} kcal
                              </span>
                            </div>
                          )}
                          <div className="text-[9px] text-muted-foreground/60">Informational — your targets are unchanged.</div>
                        </div>
                      );
                    })()}
                  </div>
                )}
              </div>

              {/* Macro bars (always visible) — multi-goalpost mode.
                  Each macro gets its natural research-anchored markers, not a
                  forced "4 goalposts everywhere". Crossed markers dim, ahead
                  bright. Past the highest marker = red overlay. */}
              {dataReady ? (() => {
                const w = (breakdown as any)?.weightKg ?? 0;
                const proteinDescs: Record<string, string> = {
                  "1.6": "Hypertrophy minimum (Schoenfeld 2018 meta)",
                  "1.8": "Common cutting target",
                  "2.0": "Conservative high — diminishing returns past this",
                  "2.2": "Aggressive cut sweet spot — best muscle preservation in deficit" };
                const fatDescs: Record<string, string> = {
                  "0.6": "Hormone-risk floor — going below for long deficits suppresses test/T3",
                  "0.8": "Sufficient for hormones, leaves carbs for training (cutting consensus)",
                  "1.0": "Maintenance/bulk target — no extra hormonal benefit in deficit" };
                const proteinMarkers: MacroMarker[] = w > 0
                  ? [1.6, 1.8, 2.0, 2.2].map((g) => ({
                      value: w * g,
                      label: g.toFixed(1),
                      optimal: g === 2.2,
                      description: proteinDescs[g.toFixed(1)] }))
                  : [{ value: targetProtein, label: "target", optimal: true }];
                const fatMarkers: MacroMarker[] = w > 0
                  ? [0.6, 0.8, 1.0].map((g) => ({
                      value: w * g,
                      label: g.toFixed(1),
                      optimal: g === 0.8,
                      description: fatDescs[g.toFixed(1)] }))
                  : [{ value: targetFat, label: "target", optimal: true }];
                const carbMarkers: MacroMarker[] = [
                  {
                    value: 100, label: "min",
                    description: "Health floor — keto-ish below this" },
                  {
                    value: targetCarbs, label: "target",
                    optimal: true,
                    description: "Today's matrix-computed carb target" },
                ].sort((a, b) => a.value - b.value);
                const fiberMarkers: MacroMarker[] = [
                  {
                    value: targetFiber || 30, label: "target",
                    optimal: true,
                    description: "Daily fiber target — gut health + satiety" },
                  {
                    value: 60, label: "ceil",
                    kind: "hardCeiling",
                    description: "GI distress threshold — past this risks bloating/cramps" },
                ];
                return (
                  <div className="grid gap-2 pt-1">
                    <MacroBar label="Protein" current={consumedProtein} target={targetProtein}
                      color={MACRO_COLORS.protein.bg} markers={proteinMarkers} />
                    <MacroBar label="Carbs" current={consumedCarbs} target={targetCarbs}
                      color={MACRO_COLORS.carbs.bg} markers={carbMarkers} />
                    <MacroBar label="Fat" current={consumedFat} target={targetFat}
                      color={MACRO_COLORS.fat.bg} markers={fatMarkers} />
                    {targetFiber > 0 && (
                      <MacroBar label="Fiber" current={consumedFiber} target={targetFiber}
                        color={MACRO_COLORS.fiber.bg} markers={fiberMarkers} />
                    )}
                  </div>
                );
              })() : (
                <div className="h-24" />
              )}
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="pt-4 text-center text-sm text-muted-foreground">
              No plan for this day. Targets are computed the first time today or a future day is
              opened, so a past day that was never opened stays without one.
            </CardContent>
          </Card>
        )}

        {/* Training / health strip */}
        <div className="flex items-center gap-3 text-xs text-muted-foreground overflow-x-auto">
          {training && (
            <div className="flex items-center gap-1 shrink-0">
              {training.gym_workout ? (
                <Dumbbell className="h-3.5 w-3.5" />
              ) : (
                <Footprints className="h-3.5 w-3.5" />
              )}
              <span className="font-medium text-foreground">
                {training.run_title || training.gym_workout || training.run_type}
              </span>
              {Number(training.target_distance_km) > 0 && (
                <span>({Number(training.target_distance_km).toFixed(1)}km)</span>
              )}
              {training.load_level && (
                <Badge variant="outline" className="text-[10px] px-1 py-0">
                  {training.load_level}
                </Badge>
              )}
            </div>
          )}
          {health?.total_steps && (
            <div className="flex items-center gap-1 shrink-0">
              <Footprints className="h-3.5 w-3.5" />
              <span>{Number(health.total_steps).toLocaleString()} steps</span>
            </div>
          )}
          {sleepHours && (
            <div className="flex items-center gap-1 shrink-0">
              <Moon className="h-3.5 w-3.5" />
              <span>{sleepHours}h sleep</span>
              {sleep?.sleep_score && (
                <span className="text-muted-foreground/70">
                  (score {sleep.sleep_score})
                </span>
              )}
            </div>
          )}
        </div>

        {/* Activity selector */}
        <ActivitySelector
          date={date}
          training={training}
          runEnabled={runEnabled}
          selectedWorkouts={selectedWorkouts}
          exerciseCalories={Number(plan?.exercise_calories) || 0}
          expectedSteps={breakdown?.expectedSteps || Number(plan?.step_goal) || 10000}
          stepGoal={Number(plan?.step_goal) || 10000}
          runStepEstimate={breakdown?.runStepEstimate || 0}
          runActual={!!breakdown?.runActual}
          actualRunKm={Number(breakdown?.runActualDistKm) || 0}
          actualRunCalories={Number(breakdown?.runCalories) || 0}
          plannedRunKm={(plan as any)?.planned_run_km ?? null}
          weightKg={(breakdown as any)?.weightKg ?? null}
          onActivityChanged={refreshData}
          disabled={(() => {
            const isPast = date < new Date().toLocaleDateString("en-CA", { timeZone: "America/New_York" });
            const hasActuals = breakdown?.runActual || breakdown?.gymBreakdown?.some((w: any) => w.actual);
            return (isPast && hasActuals) || isClosed;
          })()}
          disabledReason={isClosed ? "Day is closed" : "Activities finalized"}
        />

        <div className="hidden lg:block">
          <PrepSummary meals={meals} ingredients={ingredients} desktop />
        </div>
      </div>

      {/* ── RIGHT COLUMN: meals, drinks, close day ── */}
      <div className="space-y-4">
        <div className="lg:hidden">
          <PrepSummary meals={meals} ingredients={ingredients} />
        </div>

        {/* Quick actions */}
        {!isClosed && meals.length === 0 && (
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              className="text-xs"
              disabled={copying}
              onClick={async () => {
                setCopying(true);
                try {
                  const yesterday = (() => {
                    const d = new Date(date + "T12:00:00");
                    d.setDate(d.getDate() - 1);
                    return d.toISOString().slice(0, 10);
                  })();
                  const res = await fetch("/api/nutrition/copy-day", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ from_date: yesterday, to_date: date }) });
                  if (res.ok) {
                    await refreshData();
                  }
                } finally {
                  setCopying(false);
                }
              }}
            >
              {copying ? "Copying..." : "Copy Yesterday"}
            </Button>
          </div>
        )}

        {/* Meal cards */}
        {slots.map((slot) => {
          // Day-level macros (raw, no live preview) so each compose view can render
          // day-progress bars + multi-goalposts.
          const dayConsumedRaw = {
            protein: meals.reduce((s, m) => s + Number(m.protein || 0), 0),
            carbs:
              meals.reduce((s, m) => s + Number(m.carbs || 0), 0) +
              drinks.reduce((s, d) => s + Number(d.carbs || 0), 0),
            fat: meals.reduce((s, m) => s + Number(m.fat || 0), 0),
            fiber: meals.reduce((s, m) => s + Number(m.fiber || 0), 0),
            calories:
              meals.reduce((s, m) => s + Number(m.calories || 0), 0) +
              drinks.reduce((s, d) => s + Number(d.calories || 0), 0) };
          const userWeightKg = (breakdown as any)?.weightKg ?? null;
          const todayTotalBurn = (breakdown as any)?.totalBurn ?? null;
          return (
            <MealCard
              key={slot}
              slot={slot}
              meals={meals.filter((m) => m.meal_slot === slot)}
              presets={presets}
              ingredients={ingredients}
              slotBudget={slotBudgets?.[slot] ?? null}
              dayTargets={{ protein: targetProtein, carbs: targetCarbs, fat: targetFat, fiber: targetFiber, calories: targetCal }}
              dayConsumed={dayConsumedRaw}
              weightKg={userWeightKg}
              totalBurn={todayTotalBurn}
              skipped={skippedSlots.includes(slot)}
              date={date}
              disabled={isClosed}
              onMealLogged={(slot?: string) => handleMealChanged(slot)}
              onSlotSkipped={refreshData}
              onTotalsPreview={handleTotalsPreview}
              locked={lockedSlots.has(slot)}
              onLockToggle={handleLockToggle}
            />
          );
        })}

        {/* Drink logger */}
        <DrinkLogger
          drinks={drinks}
          date={date}
          disabled={isClosed}
          onDrinkLogged={() => handleMealChanged()}
        />

        {/* Close Day button, with a one-time prompt about unlogged slots (#703) */}
        {!isClosed && targetCal > 0 && closePrompt && (
          <div className="rounded-lg border border-border bg-card p-3 space-y-2 text-sm" data-testid="close-day-prompt">
            <div>
              <span className="font-medium">{closePrompt.length} meal{closePrompt.length === 1 ? "" : "s"} not logged:</span>{" "}
              <span className="text-muted-foreground">{closePrompt.map((s) => s.replace("_", "-")).join(", ")}</span>
            </div>
            <div className="text-xs text-muted-foreground">
              Did you skip them, or did you just not log them? Skipped meals make the day count as complete; unlogged ones are unknown and the day will not feed your weekly numbers.
            </div>
            <div className="flex flex-wrap gap-2">
              <Button size="sm" onClick={skipUnloggedAndClose} disabled={closing} data-testid="close-day-skip">
                {closing ? "Closing..." : "I skipped them"}
              </Button>
              <Button size="sm" variant="outline" onClick={postClose} disabled={closing} data-testid="close-day-anyway">
                Close anyway
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setClosePrompt(null)} disabled={closing} data-testid="close-day-cancel">
                Leave open
              </Button>
            </div>
          </div>
        )}
        {!isClosed && targetCal > 0 && !closePrompt && (
          <Button
            variant="outline"
            className="w-full"
            onClick={handleCloseDay}
            disabled={closing}
            data-testid="close-day"
          >
            {closing ? "Closing..." : "Close Day"}
          </Button>
        )}
      </div>
      {rebalanceToast && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 bg-card border border-border rounded-lg px-4 py-2 text-sm shadow-lg z-50 max-w-sm text-center animate-in fade-in slide-in-from-bottom-2">
          Adjusted: {rebalanceToast}
          <button onClick={() => setRebalanceToast(null)} className="ml-2 text-muted-foreground hover:text-foreground">{"\u2715"}</button>
        </div>
      )}
    </div>
  );
}
