/**
 * Load stream / PMC — the two database steps that fill training_load (from
 * Garmin activity raw) and pmc_daily. The formulas (activity load, TRIMP, the
 * EWMA CTL/ATL/TSB curve, cross-modal scaling) live in the banister package
 * and are re-exported here for the callers that always imported them from
 * this module. DB-only, no external writes.
 */
import type { QueryFn } from "./db";
import { computeActivityLoad, computeTrimp, computePmc, crossModalScale, dailyLoadSeries, DEFAULT_TAU_CTL, DEFAULT_TAU_ATL } from "banister";

export { computeActivityLoad, computeTrimp, computePmc, crossModalScale, DEFAULT_TAU_CTL, DEFAULT_TAU_ATL };
export type { ActivityLoad, PmcEntry } from "banister";
import type { PmcEntry } from "banister";

const r = (x: number, n: number) => Number(x.toFixed(n)); // Python round(x, n) for n>=1

/**
 * Extract per-activity EPOC from garmin_activity_raw summaries into training_load.
 * Port of backfill_load_from_history. Skips activities already present
 * (ON CONFLICT DO NOTHING). Returns the count inserted. DB-only.
 */
export async function backfillLoadFromHistory(sql: QueryFn): Promise<number> {
  // Only read blobs for activities not already in training_load. Existing rows
  // are ON CONFLICT DO NOTHING no-ops below, so the computed result is identical
  // to reading everything — but this avoids re-downloading every 'summary' blob
  // from Neon on every sync run (that full re-read was the dominant network-
  // transfer cost and paused the Free-tier project). If training_load is ever
  // empty, NOT EXISTS matches nothing and the full history is rebuilt as before.
  // ::text on both sides keeps the join type-safe regardless of column types.
  const rows = await sql`
    SELECT g.activity_id, g.raw_json
    FROM garmin_activity_raw g
    WHERE g.endpoint_name = 'summary'
      AND NOT EXISTS (
        SELECT 1 FROM training_load tl
        WHERE tl.activity_id::text = g.activity_id::text
      )
      -- ⛔ AND NOT THE GARMIN TWIN OF A WORKOUT ALREADY LOADED FROM HEVY (soma#990).
      -- soma uploads its own gym sessions to Garmin, so each one comes back through this query
      -- and got a SECOND training_load row on top of the 'hevy' one computeHevyLoads already
      -- wrote for the same session. Both rows reach computeAndStorePmc below, which sums every
      -- row per day, so every gym day was counted twice: 78 rows since 2022-01-23, 13.5% of all
      -- load over 90 days and 19.3% of gym-day load, feeding CTL, ATL, TSB, the trajectory chart
      -- and the Banister fit.
      --
      -- Both halves of the predicate matter. A Hevy workout has to claim the activity, which is
      -- what tells a twin from the 8 strength sessions of 2020 that predate Hevy and are real
      -- standalone activities. And the activity has to be a strength one (soma#996), so that a
      -- mis-claim can only ever suppress the type soma uploads: the matcher does mis-claim, three
      -- activities are held by two Hevy workouts each, and if one ever landed on a run then
      -- excluding it would lose real load, because a hevy row belongs to a gym session and a
      -- garmin_running row belongs to a run. Two sessions, not one counted twice.
      AND NOT EXISTS (
        SELECT 1 FROM workout_enrichment we
        WHERE we.garmin_activity_id = g.activity_id
          AND (g.raw_json->'activityType'->>'typeKey') = 'strength_training'
      )`;
  // Build all candidate rows in JS, then batch-insert (a per-row loop is one
  // Neon round-trip per activity — hundreds of them). ON CONFLICT DO NOTHING +
  // RETURNING counts only the genuinely new activities.
  type Tuple = [string, number, string, string, number, number | null, string];
  const tuples: Tuple[] = [];
  for (const row of rows) {
    const raw = typeof row.raw_json === "string" ? JSON.parse(row.raw_json) : row.raw_json;
    const activityDateStr: string | undefined = raw.startTimeLocal;
    if (!activityDateStr) continue;
    const activityType = (raw.activityType || {}).typeKey || "unknown";
    const source = `garmin_${activityType}`;
    const load = computeActivityLoad(raw, source);
    const trimp = computeTrimp(Math.max((raw.duration || 0) / 60, 0), raw.averageHR ?? null, raw.minHR || 50, raw.maxHR || 190);
    const details = JSON.stringify({ activity_type: activityType, original_epoc: raw.activityTrainingLoad ?? null, trimp: trimp !== null ? r(trimp, 1) : null });
    tuples.push([activityDateStr.slice(0, 10), row.activity_id, load.source, load.load_metric, load.load_value, load.duration_seconds === null ? null : Math.trunc(load.duration_seconds), details]);
  }

  const client = sql as unknown as { query(text: string, params: unknown[]): Promise<unknown[]> };
  let inserted = 0;
  const CHUNK = 500; // 7 params/row → 3500 params/chunk, well under the cap
  for (let i = 0; i < tuples.length; i += CHUNK) {
    const chunk = tuples.slice(i, i + CHUNK);
    const params: unknown[] = [];
    const values = chunk.map((t) => {
      const b = params.length;
      params.push(t[0], t[1], t[2], t[3], t[4], t[5], t[6]);
      return `($${b + 1},$${b + 2},$${b + 3},$${b + 4},$${b + 5},$${b + 6},$${b + 7}::jsonb)`;
    });
    const res = await client.query(
      `INSERT INTO training_load (activity_date, activity_id, source, load_metric, load_value, duration_seconds, details)
       VALUES ${values.join(",")} ON CONFLICT DO NOTHING RETURNING activity_id`,
      params,
    );
    inserted += res.length;
  }
  return inserted;
}

/**
 * Sum training_load per day (cross-modal scaled), fill rest-day gaps with 0,
 * compute PMC, and upsert pmc_daily. Port of compute_and_store_pmc. DB-only.
 * Returns the PMC entries written. tau defaults to the classic 42/7.
 */
export async function computeAndStorePmc(sql: QueryFn, tauCtl = DEFAULT_TAU_CTL, tauAtl = DEFAULT_TAU_ATL): Promise<PmcEntry[]> {
  const rows = await sql`
    SELECT activity_date::text AS activity_date, source, load_value
    FROM training_load
    ORDER BY activity_date`;
  if (!rows.length) return [];

  // The same series the Banister fit reads: banister's dailyLoadSeries (cross-modal scaled, summed
  // per day, rest days as 0).
  const dailyLoads = dailyLoadSeries(rows.map((r) => ({ date: r.activity_date, source: r.source, load: Number(r.load_value) })));

  const pmc = computePmc(dailyLoads, tauCtl, tauAtl);
  // Batch the upsert (matches Python's execute_values): a per-row loop is ~4700
  // sequential Neon round-trips. Chunk to stay well under Postgres' param cap.
  const client = sql as unknown as { query(text: string, params: unknown[]): Promise<unknown[]> };
  const CHUNK = 1000;
  for (let i = 0; i < pmc.length; i += CHUNK) {
    const chunk = pmc.slice(i, i + CHUNK);
    const params: unknown[] = [];
    const rows = chunk.map((e) => {
      const b = params.length;
      params.push(e.date, e.ctl, e.atl, e.tsb, e.daily_load);
      return `($${b + 1},$${b + 2},$${b + 3},$${b + 4},$${b + 5})`;
    });
    await client.query(
      `INSERT INTO pmc_daily (date, ctl, atl, tsb, daily_load) VALUES ${rows.join(",")}
       ON CONFLICT (date) DO UPDATE SET ctl=EXCLUDED.ctl, atl=EXCLUDED.atl, tsb=EXCLUDED.tsb, daily_load=EXCLUDED.daily_load`,
      params,
    );
  }
  return pmc;
}
