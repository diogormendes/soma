/**
 * Soma sync pipeline — TS entrypoint that replaces the Python sync/src/pipeline.py
 * (#187 cutover). Run by the GitHub Actions sync workflow via `npx tsx` on the
 * 30-min schedule (no Vercel involvement → no 300s limit, no daily-cron cap).
 * Composes the same ported lib functions the Vercel crons use; each step is
 * non-fatal so one failure doesn't abort the rest, mirroring pipeline.py.
 */
import { GarminAuth, DBTokenStore } from "garmin-auth";
import { HevyClient } from "hevy2garmin";
import { getDb, type QueryFn } from "../lib/db";
import { runGarminIngest } from "../lib/garmin-ingest";
import { getHevyApiKey, syncAllWorkouts } from "../lib/hevy-ingest";
import { enrichNewWorkouts } from "../lib/hevy-enrich-run";
import { computeHevyLoads } from "../lib/training-load";
import { drainCaptures, reviveStalled } from "../lib/meal-worker";
import { backfillLoadFromHistory, computeAndStorePmc } from "../lib/pmc-stream";
import { fitFromDb } from "../lib/banister";
import { pushPlanToGarmin } from "../lib/garmin-workout-builder";
import { getLivePlan } from "../lib/live-plan";
import { enrichGarminRunActivities } from "../lib/garmin-run-enrich";
import { uploadEnrichedToGarmin } from "../lib/hevy-upload";
import { enrichGarminGymActivities } from "../lib/garmin-gym-enrich";
import { pushWeightsToGarmin } from "../lib/weight-push";
import { notifyPendingWorkouts } from "../lib/notify";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) { console.error("[sync] DATABASE_URL not set"); process.exit(1); }
// getDb() picks the driver from the URL: Neon's HTTP driver for a *.neon.tech host, a normal
// Postgres pool for anything else. Choosing `neon()` here meant the pipeline could only ever
// talk to Neon, and pointed at a local database it built `https://api.0.0.1/sql`.
const sql: QueryFn = getDb();
const webBaseUrl = process.env.NEXT_PUBLIC_BASE_URL || process.env.SOMA_WEB_URL || "https://soma.gkos.dev";

// Run record (#643): one sync_log row per pipeline run so /api/sync/status and the
// Connections screen reflect THIS pipeline, not the retired Python one (its last row
// was 2026-07-16). Derived, never asserted: "last sync" is simply the newest row.
const startedAt = new Date();
const failures: string[] = [];
let stepsRun = 0;
let recordsTouched = 0;

/** Sum every numeric leaf of a step result — a coarse "records touched" count. */
function countNumbers(v: unknown): number {
  if (typeof v === "number" && Number.isFinite(v)) return Math.max(0, Math.trunc(v));
  if (Array.isArray(v)) return v.reduce<number>((a, x) => a + countNumbers(x), 0);
  if (v && typeof v === "object") return Object.values(v).reduce<number>((a, x) => a + countNumbers(x), 0);
  return 0;
}

async function step(name: string, fn: () => Promise<unknown>): Promise<void> {
  const t0 = Date.now();
  stepsRun++;
  try {
    const r = await fn();
    recordsTouched += countNumbers(r);
    console.log(`[sync] ${name} OK (${Date.now() - t0}ms):`, JSON.stringify(r));
  } catch (e) {
    failures.push(`${name}: ${(e as Error).message}`);
    console.error(`[sync] ${name} FAILED (${Date.now() - t0}ms):`, (e as Error).message);
  }
}

/** Append the run to sync_log. Policy: a failed INSERT never fails the pipeline. */
async function recordRun(): Promise<void> {
  const status = failures.length === 0 ? "success" : failures.length === stepsRun ? "failed" : "partial";
  const error = failures.length ? failures.join("; ").slice(0, 2000) : null;
  try {
    await sql`
      INSERT INTO sync_log (sync_type, status, records_synced, error_message, started_at, completed_at)
      VALUES ('full_pipeline', ${status}, ${recordsTouched}, ${error}, ${startedAt.toISOString()}, NOW())`;
    console.log(`[sync] run recorded: ${status}, ${recordsTouched} records, ${failures.length}/${stepsRun} steps failed`);
  } catch (e) {
    console.error("[sync] could not record the run in sync_log:", (e as Error).message);
  }
}

// 1. Garmin daily + activities + parse + training-engine streams + kite.
await step("garmin-ingest", () => runGarminIngest(databaseUrl!, sql));

// 2. Hevy pull + enrich + training loads + PMC.
await step("hevy", async () => {
  const apiKey = await getHevyApiKey(sql);
  if (!apiKey) throw new Error("Hevy API key not configured");
  const client = new HevyClient(apiKey);
  const pull = await syncAllWorkouts(client, sql);
  const enrich = await enrichNewWorkouts(sql);
  const loadsComputed = await computeHevyLoads(sql);
  const garminLoads = await backfillLoadFromHistory(sql);
  const pmc = await computeAndStorePmc(sql);
  return { pull, enrich, loadsComputed, garminLoads, pmcDays: pmc.length };
});

// 2b. Refit the Banister parameters (soma#993). fitFromDb had no caller anywhere after the
// Python pipeline was deleted on 2026-07-16, so banister_params stayed frozen at that day's
// fit while four read paths went on using it: the training page, the graph, the trajectory and
// the forward simulation. That fit was made against the load soma#990 has since corrected.
//
// It runs after the step above because it reads training_load, and after garmin-ingest because
// it takes its anchor runs from garmin_activity_raw. It appends a row per run, which is what
// the Python runner did, and costs about 26 seconds of differential evolution.
//
// ⛔ The fitted tau still does NOT reach the PMC. With four anchors and five parameters the fit
// is under-determined, so feeding a personal tau into the daily curve would make it drift for
// reasons that are not training. computeAndStorePmc keeps the classic 42/7 constants.
await step("banister-fit", () => fitFromDb(sql));

// 2b. Meal captures. The capture route starts the worker without awaiting it, so a restart
// mid-flight would otherwise stand a row in `running` for ever and nothing would look at it
// again. This is also the only thing that picks up a sentence captured while the web process
// was down, which matters because the sentence is the one thing that cannot be recomputed.
await step("meal-captures", async () => {
  const revived = await reviveStalled(sql);
  const drained = await drainCaptures(sql, 10);
  return { revived, drained };
});

// 3+4. Garmin client for the external-write steps (plan push + run enrichment).
let garminClient: Awaited<ReturnType<GarminAuth["client"]>> | null = null;
try {
  garminClient = await new GarminAuth({ store: new DBTokenStore(databaseUrl) }).client();
} catch (e) {
  console.error("[sync] Garmin auth for push/enrich failed:", (e as Error).message);
}

if (garminClient) {
  await step("plan-push", async () => {
    // Only a LIVE plan reaches the watch (soma#926).
    const live = await getLivePlan(sql);
    if (!live.plan) return { activePlan: null, pushed: 0, engagement: live.engagement.state };
    return { activePlan: live.plan.id, ...(await pushPlanToGarmin(sql, garminClient!, live.plan.id)) };
  });
  await step("garmin-enrich", () => enrichGarminRunActivities(sql, garminClient!, webBaseUrl));
  // Upload newly-enriched Hevy workouts to Garmin as strength activities, so they then
  // forward to Strava via the bridge (strava-bridge-ts.yml). dryRun:false is safe here:
  // uploadEnrichedToGarmin's three dedup layers (match→demote, append-only garmin ledger,
  // Garmin 409) plus the bridge's own ledger guarantee no activity is uploaded or
  // forwarded twice. Runs before notify so "Synced" reflects an actual upload.
  await step("hevy-upload", () => uploadEnrichedToGarmin(sql, garminClient!, { dryRun: false }));
  // After the upload, so a workout uploaded in this pass is described in this pass too
  // (soma#982). Idempotent through the garmin_enrichment ledger, so a re-run is a no-op.
  await step("gym-enrich", () => enrichGarminGymActivities(sql, garminClient!, webBaseUrl));
  // Weigh-ins the phone read out of Health Connect, sent onward to Garmin.
  //
  // ⛔ ONLY rows soma itself originated go out, which is why weightsOwedToGarmin filters on
  // source_type = HEALTH_CONNECT and nothing else. Every other value in that column was minted by
  // Garmin (MANUAL means "typed into Garmin", not "typed into soma"), and sending those back
  // duplicates his own history beside itself. It already happened once, on 2026-09-24, to 29 rows.
  //
  // Each row is marked as it lands rather than after the batch, so a failure halfway through
  // re-sends only what never arrived.
  await step("weight-push", () => pushWeightsToGarmin(sql, garminClient!));
}

// 5. Telegram + push notifications for workouts now on Garmin.
await step("notify", () => notifyPendingWorkouts(sql));

await recordRun();
console.log("[sync] pipeline complete");
