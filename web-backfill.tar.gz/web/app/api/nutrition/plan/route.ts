import { NextRequest, NextResponse } from "next/server";
import { latestWeighIn, keepPlausible } from "@/lib/weigh-ins";
import { getDb } from "@/lib/db";
import { computeMacroTargetsFromContext } from "@/lib/macro-targets";
import type { Mode } from "@/lib/mode-engine";
import type { SlotBudgets } from "@/lib/nutrition-types";
import { computeAdaptiveContext } from "@/lib/adaptive-tdee";
import { computeWeeklyAdherence } from "@/lib/adherence";
import { isObservedDay } from "@/lib/observed-day";
import { getLivePlan } from "@/lib/live-plan";
import { reconcile, type DayIn } from "@/lib/energy-reconcile";
import { nutritionEngagement, WEEK_ENGAGEMENT_FLOOR_DAYS } from "@/lib/engagement";
import { getWeightTrend } from "@/lib/weight-trend";
import { trendAte } from "@/lib/trend-ate";
import { computeAlcoholDisplacement, computeRunCalories, KCAL_PER_STEP_PER_KG, redistributeRemaining } from "macro-engine-core";
import { isMissingRelation, warnMissingRelationOnce } from "@/lib/missing-relation";
import { num, rec } from "@/lib/json";
import { todayForRequest } from "@/lib/request-tz";


const VALID_MODES: readonly Mode[] = [
  "standard", "aggressive", "reverse", "maintenance", "bulk", "injured",
];

/**
 * Per-slot calorie budgets: what is left of the day, spread over the slots not yet eaten or skipped
 * by the plan's shares. macro-engine-core's `redistributeRemaining` does the split, with kcal only:
 * protein, carbs, fat and fiber have no scientific basis for per-slot allocation (Schoenfeld &
 * Aragon 2018; Trommelen 2023). See `web/lib/nutrition-types.ts` for the full invariant.
 */
function kcalSlotBudgets(
  dayKcalTarget: number,
  eatenKcalBySlot: Record<string, number>,
  skippedSlots: string[] = [],
): SlotBudgets {
  const kcalOnly = (calories: number) => ({ calories, protein: 0, carbs: 0, fat: 0, fiber: 0 });
  const eaten = Object.fromEntries(Object.entries(eatenKcalBySlot).map(([s, k]) => [s, kcalOnly(k)]));
  return Object.fromEntries(
    redistributeRemaining(kcalOnly(dayKcalTarget), eaten, skippedSlots)
      .map((b) => [b.slot, { calories: Math.round(b.calories) }]),
  );
}

/** What a day looks like before any nutrition table exists: nothing logged, nothing planned. */
const EMPTY_DAY = {
  plan: null,
  meals: [],
  drinks: [],
  consumed: { calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 },
  remaining: null,
  slotBudgets: {},
  skippedSlots: [],
  runEnabled: true,
  selectedWorkouts: [],
  gymCalories: 0,
  breakdown: null,
  trend7d: null,
  deficitEstimate: null,
  adaptive: null,
  engagement: null,
  weightTrend: null,
  weightTrendPrimary: false,
};

export async function GET(req: NextRequest) {
  try {
    return await planForDay(req);
  } catch (err) {
    // No nutrition tables (a fresh fork, an unseeded demo): an empty day, not a 500 (soma#947).
    if (!isMissingRelation(err)) throw err;
    warnMissingRelationOnce("nutrition/plan", err);
    return NextResponse.json(EMPTY_DAY);
  }
}

async function planForDay(req: NextRequest) {
  const sql = getDb();
  const todayStr = await todayForRequest();
  const date = req.nextUrl.searchParams.get("date") ?? todayStr;

  // Nothing else creates the day's row before something is logged, so the first view of a new
  // day had no plan on either client and the web told the user to run a generator that does not
  // exist (soma#867). Today and future days get their row on first read; the targets are then
  // computed below and written back. Past days stay as they are: a day that was never opened
  // cannot be planned after the fact.
  if (date >= todayStr) {
    await sql`INSERT INTO nutrition_day (date) VALUES (${date}) ON CONFLICT (date) DO NOTHING`;
  }

  const [planRows, mealRows, drinkRows] = await Promise.all([
    sql`SELECT * FROM nutrition_day WHERE date = ${date}`,
    sql`SELECT * FROM meal_log WHERE date = ${date} ORDER BY logged_at`,
    sql`SELECT * FROM drink_log WHERE date = ${date} ORDER BY logged_at`,
  ]);

  const plan = planRows[0] ?? null;
  const skippedSlots: string[] = plan?.skipped_slots ?? [];
  const runEnabled: boolean = plan?.run_enabled ?? true;
  const selectedWorkouts: string[] = plan?.selected_workouts ?? [];
  let gymCalories = 0;

  // Sum consumed macros from meals + drinks
  let calories = 0,
    protein = 0,
    carbs = 0,
    fat = 0,
    fiber = 0;

  for (const m of mealRows) {
    calories += Number(m.calories) || 0;
    protein += Number(m.protein) || 0;
    carbs += Number(m.carbs) || 0;
    fat += Number(m.fat) || 0;
    fiber += Number(m.fiber) || 0;
  }
  let drinkCalories = 0;
  for (const d of drinkRows) {
    drinkCalories += Number(d.calories) || 0;
    calories += Number(d.calories) || 0;
    carbs += Number(d.carbs) || 0;
  }

  const consumed = {
    calories: Math.round(calories),
    protein: Math.round(protein),
    carbs: Math.round(carbs),
    fat: Math.round(fat),
    fiber: Math.round(fiber),
  };

  // Compute day targets, remaining, and per-slot budgets
  let remaining: Record<string, number> | null = null;
  let slotBudgets: SlotBudgets | null = null;
  let breakdown: Record<string, unknown> | null = null;

  if (plan) {
    // Resolve fiber target (plan column first, fallback to profile)
    let targetFiber = Number(plan.target_fiber) || 0;
    if (!targetFiber) {
      const fiberRows = await sql`
        SELECT target_fiber FROM nutrition_profile WHERE id = 1
      `;
      targetFiber = Number(fiberRows[0]?.target_fiber) || 25;
    }

    const dayTargets: Record<string, number> = {
      calories: Number(plan.target_calories) || 0,
      protein: Number(plan.target_protein) || 0,
      carbs: Number(plan.target_carbs) || 0,
      fat: Number(plan.target_fat) || 0,
      fiber: targetFiber,
    };

    // ── Adjust targets based on activity selections ──
    const manualOverride: boolean = plan?.manual_override ?? false;

    const gymBreakdown: { title: string; calories: number }[] = [];

    if (selectedWorkouts.length > 0) {
      const gymRows = await sql`
        WITH ranked AS (
          SELECT hevy_title, calories,
                 ROW_NUMBER() OVER (PARTITION BY hevy_title ORDER BY workout_date DESC) as rn
          FROM workout_enrichment
          WHERE hevy_title = ANY(${selectedWorkouts})
            AND calories IS NOT NULL AND calories > 0
        )
        SELECT hevy_title, ROUND(AVG(calories))::int AS avg_cal
        FROM ranked WHERE rn <= 5
        GROUP BY hevy_title
      `;
      for (const r of gymRows) {
        const cal = Number(r.avg_cal) || 0;
        gymCalories += cal;
        gymBreakdown.push({ title: r.hevy_title as string, calories: cal });
      }
    }

    // ── Check for actual completed activities today ──
    let actualRunCalories: number | null = null;
    let actualRunDistKm = 0;
    const actualGymByTitle: Record<string, number> = {};

    try {
      // Actual run calories from Garmin (summary endpoint, running type)
      const runActualRows = await sql`
        SELECT COALESCE(SUM((raw_json->>'calories')::float), 0) AS total_cal,
               COALESCE(SUM((raw_json->>'distance')::float), 0) AS total_dist
        FROM garmin_activity_raw
        WHERE endpoint_name = 'summary'
          AND raw_json->'activityType'->>'typeKey' = 'running'
          AND (raw_json->>'startTimeLocal')::date = ${date}::date
      `;
      const runCal2 = Number(runActualRows[0]?.total_cal) || 0;
      // NB: assign to the outer-scope `actualRunDistKm`, not a new const.
      // Earlier this line was `const actualRunDistKm = ...` which shadowed
      // the outer variable, so `breakdown.runActualDistKm` always rendered
      // 0km in the dashboard even when a real run was completed.
      actualRunDistKm = Math.round((Number(runActualRows[0]?.total_dist) || 0) / 1000 * 10) / 10;
      if (runCal2 > 0) actualRunCalories = Math.round(runCal2);

      // Actual gym calories from workout_enrichment for today
      const gymActualRows = await sql`
        SELECT hevy_title, calories
        FROM workout_enrichment
        WHERE workout_date = ${date}::date
      `;
      for (const r of gymActualRows) {
        if (r.hevy_title) {
          actualGymByTitle[r.hevy_title as string] = Math.round(Number(r.calories) || 0);
        }
      }
    } catch {
      // Graceful — tables may not exist in demo
    }

    // Note: dayTargets.calories will be fully recomputed below from components

    // ── Dynamic step calories: recompute from weight + step formula ──
    const profileRows = await sql`SELECT weight_kg, step_goal, daily_deficit, tdee_estimate, estimated_bf_pct, deficit_mode FROM nutrition_profile WHERE id = 1`;
    let weightKg = Number(profileRows[0]?.weight_kg) || 79.2;

    // Use latest weight from weight_log (more current than profile)
    try {
      // ⛔ This was `ORDER BY date DESC LIMIT 1` with no date bound, so a mistyped weigh-in would
      // have set his calorie target until the next one arrived. Judged against its neighbours.
      const latest = await latestWeighIn(sql, new Date().toISOString().slice(0, 10), "plan");
      if (latest) {
        const lw = latest.weightKg;
        if (lw > 0) weightKg = lw;
      }
    } catch {}
    const defaultDeficit = profileRows[0]?.daily_deficit != null ? Number(profileRows[0].daily_deficit) : 500;

    let stepGoal = Number(plan.step_goal) || 0;
    if (!stepGoal || stepGoal === 10000) {
      const profileStepGoal = Number(profileRows[0]?.step_goal) || 0;
      if (profileStepGoal && profileStepGoal !== 10000) {
        stepGoal = profileStepGoal;
      } else {
        stepGoal = stepGoal || 10000;
      }
    }
    const expectedSteps = Number(plan.expected_steps) || stepGoal;

    // Actual steps from Garmin
    let actualSteps: number | null = null;
    try {
      const stepsRow = await sql`
        SELECT total_steps FROM daily_health_summary WHERE date = ${date}
      `;
      if (stepsRow[0]?.total_steps) {
        actualSteps = Number(stepsRow[0].total_steps);
      }
    } catch {}

    // Recompute step calories from scratch using weight-based formula
    const calPerStep = KCAL_PER_STEP_PER_KG * weightKg; // conservative: ~-50 kcal/day vs Garmin
    const isClosed = plan?.status === "closed";
    const isPast = date < (await todayForRequest());
    const stepsForCalc = (isClosed || isPast) && actualSteps !== null ? actualSteps : expectedSteps;
    const rawStepCalories = Math.round(stepsForCalc * calPerStep);

    let adjustedStepCalories = rawStepCalories;
    let runStepEstimate = 0;
    let runDistanceKm = 0;

    // Fetch run distance for step dedup. Resolution order:
    //   1. Ad-hoc planned run (nutrition_day.planned_run_km) — user-set
    //      via the Today's Activity panel for unplanned/ad-hoc runs.
    //   2. Coach plan (training_plan_day.target_distance_km) — fallback
    //      when no ad-hoc value and the plan is LIVE for that day (soma#926):
    //      a paused, finished or dropped plan prescribes nothing.
    //   3. 0 — no planned run.
    const adhocRunKm = Number(plan?.planned_run_km) || 0;
    if (adhocRunKm > 0) {
      runDistanceKm = adhocRunKm;
    } else {
      const live = await getLivePlan(sql, date);
      const planDay = live.days.find((d) => d.day_date === date);
      runDistanceKm = Number(planDay?.target_distance_km) || 0;
    }

    if (runEnabled && runDistanceKm > 0) {
      runStepEstimate = Math.round(runDistanceKm * 1300);
      const MIN_NEAT_STEPS = 3000;
      const netSteps = Math.max(MIN_NEAT_STEPS, expectedSteps - runStepEstimate);
      adjustedStepCalories = Math.round(netSteps * calPerStep);
    }

    // Predicted step calories (always from expectedSteps, with run dedup)
    const predictedStepCalories = runEnabled && runDistanceKm > 0
      ? Math.round(Math.max(3000, expectedSteps - runStepEstimate) * calPerStep)
      : Math.round(expectedSteps * calPerStep);

    // Compute run calories — use plan value, or estimate from distance × weight
    let baseRunCal = Number(plan.exercise_calories) || 0;
    if (baseRunCal === 0 && runDistanceKm > 0) {
      baseRunCal = computeRunCalories(runDistanceKm, weightKg);
    }
    const runCal = runEnabled ? baseRunCal : 0;

    // ── Reliable BMR: query most recent full-day from daily_health_summary ──
    let baseBmr = 0;
    try {
      const bmrRows = await sql`
        SELECT bmr_kilocalories FROM daily_health_summary
        WHERE date < ${date}::date AND bmr_kilocalories > 1500
        ORDER BY date DESC LIMIT 1
      `;
      baseBmr = Number(bmrRows[0]?.bmr_kilocalories) || 0;
    } catch {}
    if (baseBmr === 0) {
      baseBmr = Math.round((Number(profileRows[0]?.tdee_estimate) || 2600) * 0.75);
    }

    // Effective calories: actual if completed, predicted if pending
    const effectiveRunCal = runEnabled
      ? (actualRunCalories !== null ? actualRunCalories : runCal)
      : 0;

    let effectiveGymCal = 0;
    const gymBreakdownFinal: { title: string; calories: number; predicted: number; actual: boolean }[] = [];
    for (const workout of selectedWorkouts) {
      const predictedEntry = gymBreakdown.find((g) => g.title === workout);
      const predCal = predictedEntry?.calories ?? 0;
      if (actualGymByTitle[workout] !== undefined) {
        effectiveGymCal += actualGymByTitle[workout];
        gymBreakdownFinal.push({ title: workout, calories: actualGymByTitle[workout], predicted: predCal, actual: true });
      } else {
        effectiveGymCal += predCal;
        gymBreakdownFinal.push({ title: workout, calories: predCal, predicted: predCal, actual: false });
      }
    }

    // Use sleep-adjusted deficit from plan JSON if available, otherwise profile default
    // The sync engine sets plan->deficit_used based on sleep quality (0 for severe, halved for moderate)
    const planJsonDeficit = plan?.plan ? num(rec(plan.plan)?.deficit_used) : null;
    const effectiveDeficit = manualOverride
      ? (plan.deficit_used != null ? Number(plan.deficit_used) : defaultDeficit)
      : (planJsonDeficit != null ? planJsonDeficit : defaultDeficit);
    dayTargets.calories = Math.round(baseBmr + adjustedStepCalories + effectiveRunCal + effectiveGymCal - effectiveDeficit);

    // If manual_override, use stored target instead of computed
    if (manualOverride && Number(plan.target_calories) > 0) {
      dayTargets.calories = Number(plan.target_calories);
    }

    // ── M4 5-band × tier × mode matrix (Nutrition Batch 2 #67) ──
    // Route to the macro-engine matrix when we have BF% context. Falls
    // back to the legacy flat 2.2 / 0.8 formula when BF% is missing so
    // existing users without a tier continue to see their old numbers.
    const bfPct = profileRows[0]?.estimated_bf_pct != null
      ? Number(profileRows[0].estimated_bf_pct) : null;
    const rawMode = String(profileRows[0]?.deficit_mode ?? "standard");
    const mode: Mode = (VALID_MODES as readonly string[]).includes(rawMode)
      ? (rawMode as Mode) : "standard";
    if (bfPct != null) {
      const matrix = computeMacroTargetsFromContext({
        weightKg, bfPct, mode,
        runKcal: effectiveRunCal,
        gymKcal: effectiveGymCal,
        kcalTarget: dayTargets.calories,
        inDeficit: effectiveDeficit > 0,
      });
      dayTargets.protein = matrix.protein;
      dayTargets.fat = matrix.fat;
      dayTargets.carbs = matrix.carbs;
      dayTargets.fiber = matrix.fiber;
    } else {
      // Legacy flat fallback (preserved for users without BF%).
      dayTargets.protein = Math.round(weightKg * 2.2);
      dayTargets.fat = Math.round(weightKg * 0.8);
      dayTargets.carbs = Math.round(Math.max(0, (dayTargets.calories - dayTargets.protein * 4 - dayTargets.fat * 9) / 4));
    }

    // Scale protein+fat down if they exceed calorie budget (extreme deficit days)
    const macroFloorCal = dayTargets.protein * 4 + dayTargets.fat * 9;
    if (macroFloorCal > dayTargets.calories && dayTargets.calories > 0) {
      const scale = dayTargets.calories / macroFloorCal;
      dayTargets.protein = Math.round(dayTargets.protein * scale);
      dayTargets.fat = Math.round(dayTargets.fat * scale);
      dayTargets.carbs = 0;
    }

    // If no run, shift 10% of carb calories to fat
    if (!runEnabled && dayTargets.carbs > 0) {
      const carbShift = Math.round(dayTargets.carbs * 0.1);
      const fatEquiv = Math.round((carbShift * 4) / 9);
      dayTargets.carbs -= carbShift;
      dayTargets.fat += fatEquiv;
    }

    // ── Alcohol offset: reduce food macro targets by drink calories ──
    // Parity with macro-engine-core: alcohol kcal displace fat first (65%) then
    // carbs, capped at the day's budget, never protein.
    if (drinkCalories > 0) {
      dayTargets.calories = Math.max(0, dayTargets.calories - drinkCalories);
      const disp = computeAlcoholDisplacement(drinkCalories, dayTargets.fat, dayTargets.carbs);
      dayTargets.fat = Math.max(0, dayTargets.fat - disp.fat_reduction_g);
      dayTargets.carbs = Math.max(0, dayTargets.carbs - disp.carbs_reduction_g);
    }

    remaining = {
      calories: dayTargets.calories - consumed.calories,
      protein: Math.round(dayTargets.protein - consumed.protein),
      carbs: Math.round(dayTargets.carbs - consumed.carbs),
      fat: Math.round(dayTargets.fat - consumed.fat),
      fiber: Math.round(dayTargets.fiber - consumed.fiber),
    };

    // Aggregate eaten kcal by meal_slot — only kcal is budgeted per slot.
    const eatenKcalBySlot: Record<string, number> = {};
    for (const m of mealRows) {
      const slot = m.meal_slot as string;
      if (!slot) continue;
      eatenKcalBySlot[slot] = (eatenKcalBySlot[slot] ?? 0) + (Number(m.calories) || 0);
    }

    slotBudgets = kcalSlotBudgets(dayTargets.calories, eatenKcalBySlot, skippedSlots);

    // ── Build observability breakdown ──
    breakdown = {
      bmr: Math.round(baseBmr),
      stepCalories: adjustedStepCalories,
      stepCaloriesPredicted: predictedStepCalories,
      stepCaloriesRaw: rawStepCalories,
      stepGoal,
      expectedSteps,
      actualSteps,
      minSteps: runEnabled ? runStepEstimate : 0,
      runStepEstimate,
      runCalories: effectiveRunCal,
      runActual: actualRunCalories !== null,
      runActualDistKm: actualRunDistKm,
      runPredicted: runCal,
      runEnabled,
      runDistanceKm,
      gymCalories: effectiveGymCal,
      gymBreakdown: gymBreakdownFinal,
      selectedWorkouts,
      drinkCalories,
      deficit: effectiveDeficit,
      totalBurn: Math.round(baseBmr + adjustedStepCalories + effectiveRunCal + effectiveGymCal),
      targetIntake: dayTargets.calories,
      manualOverride,
      adjustedTargets: {
        calories: dayTargets.calories,
        protein: dayTargets.protein,
        carbs: dayTargets.carbs,
        fat: dayTargets.fat,
        fiber: dayTargets.fiber,
      },
      weightKg,
    };

    // ── Write-back: sync computed values to DB so stored matches dynamic ──
    // Only for current day, non-manual days, when values differ
    // Today and future days: the row now exists from the first read, so write the computed targets
    // back for them too (a future day's row otherwise sat with null targets). Past days are history.
    if (date >= todayStr && !manualOverride && breakdown) {
      const computedTarget = dayTargets.calories;
      const storedTarget = Number(plan.target_calories) || 0;
      if (Math.abs(computedTarget - storedTarget) > 10 || !plan.target_calories) {
        try {
          await sql`
            UPDATE nutrition_day SET
              target_calories = ${computedTarget},
              target_protein = ${dayTargets.protein},
              target_carbs = ${dayTargets.carbs},
              target_fat = ${dayTargets.fat},
              deficit_used = ${effectiveDeficit},
              tdee_used = ${Math.round(baseBmr + adjustedStepCalories + effectiveRunCal + effectiveGymCal)}
            WHERE date = ${date} AND manual_override = FALSE
          `;
        } catch {}
      }
    }
  }

  // ── 7-day rolling trend ──
  // `coverage` = (distinct slots with logged kcal ∪ explicitly skipped) / 4,
  // the same definition lib/adaptive-tdee uses (#699). Since soma#891 a day is
  // OBSERVED when a person closed it or every slot was logged or skipped; any
  // other day is reconciled against the scale: the weight change between two
  // weigh-ins, at 7700 kcal/kg, is spread over the unobserved share of the
  // days between them (lib/energy-reconcile). For that the query spans back to
  // the last weigh-in before the window, not just seven days. lib/adaptive-tdee
  // stays on observed days only: an extrapolated day is derived from the scale,
  // and feeding it back into a TDEE fit would be circular.
  const shiftDate = (d: string, n: number) => {
    const t = new Date(`${d}T00:00:00Z`);
    t.setUTCDate(t.getUTCDate() + n);
    return t.toISOString().slice(0, 10);
  };
  const weighIns = keepPlausible(
    (
      await sql`
        SELECT date::text AS date, weight_grams / 1000.0 AS weight_kg
        FROM weight_log WHERE coalesce(upper(source_type), '') <> 'USER_SETTING' AND weight_grams IS NOT NULL AND date <= ${date}::date ORDER BY date
      `
    ).map((w: Record<string, unknown>) => ({ date: String(w.date), weightKg: Number(w.weight_kg) })),
    "plan-span",
  );
  const windowStart = shiftDate(date, -6);
  // The span starts at the beginning of the last complete weigh-in interval
  // before the window: the rate that fills the window's unlogged days is that
  // interval's, and it needs every day of the interval to be computed.
  const before = weighIns.filter((w: { date: string }) => w.date <= windowStart);
  const intervalStart = before.length >= 2 ? before[before.length - 2] : before[0] ?? weighIns[0];
  const spanStart = intervalStart && intervalStart.date < windowStart ? intervalStart.date : windowStart;
  const spanRows = await sql`
    SELECT
      n.date::text AS date,
      n.target_calories,
      n.actual_calories,
      n.status,
      n.closed_by,
      n.manual_override,
      n.deficit_used,
      (
        SELECT COUNT(DISTINCT s)::float / 4
        FROM (
          SELECT m.meal_slot AS s FROM meal_log m
           WHERE m.date = n.date AND m.calories > 0
          UNION
          SELECT unnest(COALESCE(n.skipped_slots, ARRAY[]::text[]))
        ) u
        WHERE u.s IN ('breakfast', 'lunch', 'dinner', 'pre_sleep')
      ) AS coverage,
      (
        -- What was actually logged that day. Open days read this; closed
        -- days keep actual_calories, which close-day reconciled (#717).
        SELECT COALESCE((SELECT SUM(m.calories) FROM meal_log m WHERE m.date = n.date), 0)
             + COALESCE((SELECT SUM(d.calories) FROM drink_log d WHERE d.date = n.date), 0)
      ) AS logged_calories
    FROM nutrition_day n
    WHERE n.date >= ${spanStart}::date
      AND n.date <= ${date}::date
    ORDER BY n.date
  `;
  // The seven days the trend shows; the rows before them only feed the reconciliation.
  const trendRows = spanRows.filter((r: Record<string, unknown>) => String(r.date) >= windowStart);

  // Goal deficit from profile (the user's real target, e.g. 800/day)
  let goalDeficit = 800;
  try {
    const profRows = await sql`SELECT daily_deficit FROM nutrition_profile WHERE id = 1`;
    goalDeficit = profRows[0]?.daily_deficit != null ? Number(profRows[0].daily_deficit) : 800;
  } catch {}

  // Compute burn per day from stored plan data (consistent with budget card model)
  const computeBurn = (r: Record<string, unknown>, isCurrentDay: boolean) => {
    if (isCurrentDay && breakdown) return num(rec(breakdown)?.totalBurn) ?? 0;
    // Reconstruct from stored values: burn = target + deficit
    const target = Number(r.target_calories) || 0;
    const defUsed = Number(r.deficit_used) || goalDeficit;
    return target + defUsed;
  };

  const coverageOf = (r: Record<string, unknown>) =>
    typeof r.coverage === "number" ? r.coverage : r.coverage != null ? Number(r.coverage) : null;
  // A day with no plan has no burn (target 0 + deficit is not one), and
  // without a burn there is nothing to reconcile: it stays unknown.
  const hasBurn = (r: Record<string, unknown>) => String(r.date) === date || Number(r.target_calories) > 0;
  const spanDays: DayIn[] = spanRows.filter(hasBurn).map((r: Record<string, unknown>) => {
    const d = String(r.date);
    const isCurrentDay = d === date;
    const coverage = coverageOf(r);
    const observed = isObservedDay({
      status: (r.status as string | null) ?? null,
      closedBy: (r.closed_by as "user" | "auto" | null) ?? null,
      coverage,
    });
    // An observed closed day keeps actual_calories (close-day reconciled it);
    // an auto-closed day is read from its raw logs like an open one.
    const loggedKcal = trendAte({
      isToday: isCurrentDay,
      closed: observed && r.status === "closed",
      actualCalories: r.actual_calories as number | null,
      loggedCalories: r.logged_calories as number | null,
      todayConsumed: consumed.calories,
    });
    return {
      date: d,
      observed,
      loggedKcal,
      // The share of the day that was logged or skipped; the rest is estimated.
      loggedShare: observed ? 1 : Math.min(1, coverage ?? 0),
      burn: Math.round(computeBurn(r, isCurrentDay)),
    };
  });
  const reconciled = new Map(reconcile(weighIns, spanDays).map((o) => [o.date, o]));
  const windowOut = trendRows.map((r: Record<string, unknown>) => {
    const o = reconciled.get(String(r.date));
    if (o) return o;
    // Unknown day: the legacy numbers, for display only, never summed.
    const isCurrentDay = String(r.date) === date;
    const ate = trendAte({
      isToday: isCurrentDay,
      closed: r.status === "closed",
      actualCalories: r.actual_calories as number | null,
      loggedCalories: r.logged_calories as number | null,
      todayConsumed: consumed.calories,
    });
    const burn = Math.round(computeBurn(r, isCurrentDay));
    return { date: String(r.date), ate, burn, deficit: ate - burn, source: "unknown" as const, intervalStart: null, intervalEnd: null };
  });
  // A day feeds the cumulative deficit and weekly adherence when it is observed
  // or reconciled; only a day nothing can say anything about is left out.
  const counted = windowOut.filter((o) => o.source !== "unknown");

  const trend7d = {
    goalDeficit,
    days: trendRows.map((r: Record<string, unknown>, i: number) => {
      const o = windowOut[i];
      return {
        date: r.date,
        ate: Math.round(o.ate),
        burn: o.burn,
        deficit: Math.round(o.deficit), // negative = deficit (good), positive = surplus (bad)
        closed: r.status === "closed",
        coverage: coverageOf(r),
        counted: o.source !== "unknown",
        isToday: String(r.date) === date,
        // observed | partial | extrapolated | unknown, and the weigh-in interval
        // the estimate came from, so the UI can say "~" and between which dates.
        source: o.source,
        intervalStart: o.intervalStart,
        intervalEnd: o.intervalEnd,
      };
    }),
    // Cumulative deficit: sum of (ate - burn) over counted days
    totalDeficit: Math.round(counted.reduce((sum, o) => sum + o.deficit, 0)),
    closedDays: counted.length,
    goalExpectedDeficit: counted.length * goalDeficit,
    // Weekly adherence (±10% band). Achieved deficit = burn − ate, summed over
    // counted days (positive = in deficit); goal = counted days × goal/day.
    adherence: computeWeeklyAdherence(
      Math.round(counted.reduce((s, o) => s + (o.burn - o.ate), 0)),
      counted.length * goalDeficit,
    ),
  };
  // Today's own estimate for the hero: what the day will have come to once the
  // unlogged share is filled at the current interval's rate.
  const todayOut = reconciled.get(date);
  const deficitEstimate = todayOut
    ? {
        ate: Math.round(todayOut.ate),
        burn: todayOut.burn,
        deficit: Math.round(todayOut.deficit),
        source: todayOut.source,
        intervalStart: todayOut.intervalStart,
        intervalEnd: todayOut.intervalEnd,
      }
    : null;

  // Adaptive TDEE + deficit-duration (display-only — never changes targets).
  const adaptive = await computeAdaptiveContext(sql).catch(() => null);

  // Is nutrition actually in use this week? trendRows is exactly the 7-day
  // window ending today with per-day coverage, so no extra query (#700).
  const engagement = nutritionEngagement(
    trendRows.map((r: Record<string, unknown>) => ({
      date: String(r.date),
      status: (r.status as string | null) ?? null,
      coverage: typeof r.coverage === "number" ? r.coverage : null,
    })),
    date,
  );

  // The scale is the ground truth that survives not logging. When the week
  // is not fully engaged this is the PRIMARY signal and the log-derived
  // numbers above are secondary or hidden; when it is, the roles swap (#702).
  const weightTrend = await getWeightTrend(sql, date);
  const weightTrendPrimary = engagement.state !== "complete";

  return NextResponse.json({
    plan,
    meals: mealRows,
    drinks: drinkRows,
    consumed,
    remaining,
    slotBudgets,
    skippedSlots,
    runEnabled,
    selectedWorkouts,
    gymCalories,
    breakdown,
    trend7d,
    deficitEstimate,
    // Only meaningful when the week is engaged; the UI hides it otherwise
    // rather than showing a drift computed from nothing.
    adaptive: engagement.state === "complete" ? adaptive : null,
    engagement: { ...engagement, weekFloorDays: WEEK_ENGAGEMENT_FLOOR_DAYS },
    weightTrend,
    weightTrendPrimary,
  });
}
