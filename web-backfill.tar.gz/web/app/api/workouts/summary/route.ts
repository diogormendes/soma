import { NextResponse } from "next/server";
import { parseRangeDays } from "@/lib/time-ranges";
import { getDb } from "@/lib/db";
import { todayForRequest } from "@/lib/request-tz";


/**
 * Strength-training data as JSON so the native app can render the workouts
 * dashboard (the web page reads hevy_raw_data server-side). Mirrors the queries
 * in app/workouts/page.tsx: weekly volume, summary stats, recent list, top exercises.
 */
export async function GET(request: Request) {
  // His calendar date on the device making this request, never the database's New York clock.
  const today = await todayForRequest();
  const { searchParams } = new URL(request.url);
  const range = searchParams.get("range") || "90d";
  const days = parseRangeDays(range, 90); // all 10 web keys + legacy Nd (soma#754)

  const sql = getDb();

  // weekly training volume (normal sets: weight_kg * reps)
  const weeklyVolume = (await sql`
    WITH s AS (
      SELECT DATE_TRUNC('week', (raw_json->>'start_time')::timestamp)::date as week,
             (st->>'weight_kg')::float * (st->>'reps')::int as volume
      FROM hevy_raw_data,
        jsonb_array_elements(raw_json->'exercises') as e,
        jsonb_array_elements(e->'sets') as st
      WHERE endpoint_name = 'workout'
        AND (raw_json->>'start_time')::timestamp >= ${today}::date - ${days}::int
        AND st->>'type' = 'normal'
        AND (st->>'weight_kg')::float > 0
        AND (st->>'reps')::int > 0
    )
    SELECT week, ROUND(SUM(volume)::numeric) as total_volume
    FROM s GROUP BY week ORDER BY week ASC
  `) as { week: string; total_volume: number }[];

  // summary stats over the window
  const statsRows = (await sql`
    SELECT COUNT(*) as total_workouts,
      COUNT(DISTINCT (raw_json->>'start_time')::date) as training_days,
      AVG(EXTRACT(EPOCH FROM ((raw_json->>'end_time')::timestamp - (raw_json->>'start_time')::timestamp)) / 60) as avg_duration_min,
      AVG(jsonb_array_length(raw_json->'exercises')) as avg_exercises
    FROM hevy_raw_data
    WHERE endpoint_name = 'workout'
      AND (raw_json->>'start_time')::timestamp >= ${today}::date - ${days}::int
  `) as { total_workouts: number; training_days: number; avg_duration_min: number | null; avg_exercises: number | null }[];

  // recent workouts (with exercises to compute per-workout volume + top exercises)
  const recentRows = (await sql`
    SELECT raw_json->>'id' as id, raw_json->>'title' as title,
      raw_json->>'start_time' as start_time, raw_json->>'end_time' as end_time,
      jsonb_array_length(raw_json->'exercises') as exercise_count,
      raw_json->'exercises' as exercises
    FROM hevy_raw_data
    WHERE endpoint_name = 'workout'
      AND (raw_json->>'start_time')::timestamp >= ${today}::date - ${days}::int
    ORDER BY (raw_json->>'start_time') DESC
    LIMIT 20
  `) as { id: string; title: string; start_time: string; end_time: string; exercise_count: number; exercises: unknown }[];

  type Ex = { title?: string; sets?: { type?: string; weight_kg?: number; reps?: number }[] };
  const recent = recentRows.map((w) => {
    const exs: Ex[] = Array.isArray(w.exercises)
      ? (w.exercises as Ex[])
      : typeof w.exercises === "string"
      ? (JSON.parse(w.exercises) as Ex[])
      : [];
    let volume = 0;
    for (const e of exs) {
      for (const st of e.sets ?? []) {
        if (st.type === "normal" && (st.weight_kg ?? 0) > 0 && (st.reps ?? 0) > 0) {
          volume += (st.weight_kg as number) * (st.reps as number);
        }
      }
    }
    const durMin =
      w.start_time && w.end_time
        ? Math.round((new Date(w.end_time).getTime() - new Date(w.start_time).getTime()) / 60000)
        : null;
    return {
      id: w.id, title: w.title, start_time: w.start_time,
      exercise_count: w.exercise_count, duration_min: durMin, volume: Math.round(volume),
    };
  });

  // Count across the WHOLE range in SQL — the old JS loop only counted the
  // 20 most-recent workouts, capping every exercise at the same number.
  const topRows = (await sql`
    SELECT e->>'title' as name, COUNT(*) as sessions
    FROM hevy_raw_data, jsonb_array_elements(raw_json->'exercises') as e
    WHERE endpoint_name = 'workout'
      AND (raw_json->>'start_time')::timestamp >= ${today}::date - ${days}::int
      AND e->>'title' IS NOT NULL
    GROUP BY 1 ORDER BY 2 DESC LIMIT 8
  `) as { name: string; sessions: number | string }[];
  const topExercises = topRows.map((r) => ({ name: r.name, sessions: Number(r.sessions) }));

  return NextResponse.json({ stats: statsRows[0] ?? null, weeklyVolume, recent, topExercises });
}
