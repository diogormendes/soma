import type { Metadata } from "next";
import { latestWeighIn } from "@/lib/weigh-ins";
import { getDb } from "@/lib/db";
import { listIngredients } from "@/lib/ingredient-catalog";
import { getLivePlan } from "@/lib/live-plan";
import { NutritionDashboard } from "@/components/nutrition-dashboard";
import { NutritionOnboarding } from "@/components/nutrition-onboarding";
import { BodyCompChart } from "@/components/body-comp-chart";
import { todayForRequest } from "@/lib/request-tz";

export const metadata: Metadata = { title: "Nutrition" };
export const revalidate = 60;

/** Safe query wrapper — returns fallback on missing table or other DB error. */
async function safeQuery<T>(fn: () => Promise<T>, fallback: T): Promise<T> {
  try {
    return await fn();
  } catch {
    return fallback;
  }
}

/** Check if nutrition_profile exists; if not, gather bootstrap data for onboarding. */
async function getBootstrap() {
  const sql = getDb();

  // Check if profile already exists
  const profileRows = await sql`SELECT id FROM nutrition_profile WHERE id = 1`;
  if (profileRows.length > 0) return null;

  // No profile — gather bootstrap data from existing tables
  const [healthRows, weightRows, fitnessRows, profileRawRows] = await Promise.all([
    sql`
      SELECT bmr_kilocalories, active_kilocalories
      FROM daily_health_summary
      WHERE bmr_kilocalories IS NOT NULL
      ORDER BY date DESC LIMIT 1
    `,
    // ⛔ Was `ORDER BY date DESC LIMIT 1`, so a typo would have been the weight on the page.
    latestWeighIn(sql, new Date().toISOString().slice(0, 10), "nutrition-page").then((w) =>
      w ? [{ weight_kg: w.weightKg }] : [],
    ),
    sql`
      SELECT vo2max
      FROM fitness_trajectory
      WHERE vo2max IS NOT NULL
      ORDER BY date DESC LIMIT 1
    `,
    sql`
      SELECT raw_json
      FROM garmin_profile_raw
      WHERE endpoint_name = 'user_profile'
      LIMIT 1
    `,
  ]);

  const bmr = Number(healthRows[0]?.bmr_kilocalories) || 1800;
  const active = Number(healthRows[0]?.active_kilocalories) || 400;
  const tdee = bmr + active;

  const weight_kg = Number(weightRows[0]?.weight_kg) || 80;
  const vo2max = fitnessRows[0]?.vo2max ? Number(fitnessRows[0].vo2max) : null;

  // Extract profile fields from Garmin raw JSON (nested under userData)
  const rawProfile = profileRawRows[0]?.raw_json;
  const userData = rawProfile?.userData ?? rawProfile;
  const height_cm: number | null = userData?.height ? Number(userData.height) : null;
  const birthDateStr: string | null = userData?.birthDate ?? null;
  const genderRaw: string | null = userData?.gender ?? null;
  const sex = genderRaw ? genderRaw.toLowerCase() : null;

  // Compute age from birth date
  let age: number | null = null;
  if (birthDateStr) {
    const birth = new Date(birthDateStr);
    const now = new Date();
    age = now.getFullYear() - birth.getFullYear();
    const monthDiff = now.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && now.getDate() < birth.getDate())) {
      age--;
    }
  }

  // Compute NHANES BF% estimate
  let estimated_bf_pct: number | null = null;
  if (age !== null && height_cm !== null) {
    const isMale = sex === "male" ? 1 : 0;
    const bmi = weight_kg / ((height_cm / 100) ** 2);
    const raw = 47.35 + 0.035 * age - 11.07 * isMale - 0.177 * height_cm +
      0.191 * weight_kg + 0.345 * bmi - 0.137 * (vo2max || 40);
    estimated_bf_pct = Math.round(Math.max(5, Math.min(50, raw)) * 10) / 10;
  }

  // Fetch Hevy exercise names with session counts and template IDs
  let exercise_stats: { name: string; recent: number; total: number; template_id: string }[] = [];
  try {
    const exerciseRows = await sql`
      WITH workout_exercises AS (
        SELECT
          e->>'title' AS title,
          e->>'exercise_template_id' AS template_id,
          (raw_json->>'start_time')::timestamptz AS workout_date
        FROM hevy_raw_data,
             jsonb_array_elements(raw_json->'exercises') AS e
        WHERE endpoint_name = 'workout'
      )
      SELECT
        title AS name,
        MIN(template_id) AS template_id,
        COUNT(*)::int AS total,
        COUNT(*) FILTER (WHERE workout_date >= NOW() - INTERVAL '28 days')::int AS recent
      FROM workout_exercises
      WHERE title IS NOT NULL
      GROUP BY title
      ORDER BY recent DESC, total DESC
    `;
    exercise_stats = exerciseRows.map((r: Record<string, unknown>) => ({
      name: r.name as string,
      recent: Number(r.recent),
      total: Number(r.total),
      template_id: r.template_id as string,
    }));
  } catch {
    // Malformed data or missing table — proceed with empty list
  }

  return {
    tdee,
    weight_kg,
    height_cm,
    age,
    sex,
    vo2max,
    estimated_bf_pct,
    exercise_stats,
  };
}

async function getNutritionDay(date: string) {
  const sql = getDb();
  const rows = await sql`
    SELECT * FROM nutrition_day WHERE date = ${date}
  `;
  if (rows[0]) return rows[0];

  // Auto-create minimal row so meals can be logged
  try {
    await sql`
      INSERT INTO nutrition_day (date, status)
      VALUES (${date}, 'active')
      ON CONFLICT (date) DO NOTHING
    `;
  } catch {}
  return null;
}

async function getMeals(date: string) {
  const sql = getDb();
  return sql`
    SELECT ml.*, pm.name AS preset_name, pm.tags AS preset_tags
    FROM meal_log ml
    LEFT JOIN preset_meals pm ON ml.preset_meal_id = pm.id
    WHERE ml.date = ${date}
    ORDER BY ml.logged_at
  `;
}

async function getDrinks(date: string) {
  const sql = getDb();
  return sql`
    SELECT * FROM drink_log WHERE date = ${date} ORDER BY logged_at
  `;
}

async function getPresets() {
  const sql = getDb();
  return sql`SELECT * FROM preset_meals ORDER BY name`;
}

async function getIngredients() {
  return listIngredients(getDb());
}

/**
 * Today's prescribed session, but only from a LIVE plan (#701). A dormant
 * plan's day, if one even coincides with this date, is not a prescription and
 * must not add planned-run calories to today's budget.
 */
async function getTrainingDay(date: string) {
  const sql = getDb();
  const live = await getLivePlan(sql, date);
  const d = live.days.find((x) => x.day_date === date);
  if (!d || !live.plan) return null;
  return {
    run_type: d.run_type,
    run_title: d.run_title,
    target_distance_km: d.target_distance_km,
    target_duration_min: d.target_duration_min,
    load_level: d.load_level,
    gym_workout: d.gym_workout,
    plan_name: live.plan.plan_name,
  };
}

async function getHealthSummary(date: string) {
  const sql = getDb();
  const rows = await sql`
    SELECT total_steps, bmr_kilocalories, active_kilocalories,
           sleep_time_seconds
    FROM daily_health_summary
    WHERE date = ${date}
    LIMIT 1
  `;
  return rows[0] ?? null;
}

async function getSleepDetail(date: string) {
  const sql = getDb();
  const rows = await sql`
    SELECT total_sleep_seconds, deep_sleep_seconds, sleep_score
    FROM sleep_detail
    WHERE date = ${date}
    LIMIT 1
  `;
  return rows[0] ?? null;
}

export default async function NutritionPage({ searchParams }: { searchParams: Promise<{ date?: string; view?: string }> }) {
  const params = await searchParams;
  const today = params.date || (await todayForRequest());
  const view = params.view || "day";

  // Check if onboarding is needed (no nutrition_profile)
  const bootstrap = await safeQuery(() => getBootstrap(), undefined);

  if (bootstrap) {
    return (
      <div className="max-w-lg mx-auto px-4 py-6">
        <NutritionOnboarding bootstrap={bootstrap} />
      </div>
    );
  }

  // Tab switcher (rendered for both views)
  const tabBar = (
    <div className="max-w-lg mx-auto px-4 pt-4 lg:max-w-5xl">
      <div className="flex gap-1 bg-muted rounded-lg p-1 w-fit">
        <a
          href={`/nutrition?date=${today}`}
          className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${view === "day" ? "bg-background shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
        >
          Day
        </a>
        <a
          href="/nutrition?view=trajectory"
          className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${view === "trajectory" ? "bg-background shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
        >
          Trajectory
        </a>
      </div>
    </div>
  );

  if (view === "trajectory") {
    return (
      <>
        {tabBar}
        <div className="max-w-lg mx-auto px-4 py-6 lg:max-w-3xl">
          <BodyCompChart />
        </div>
      </>
    );
  }

  // Profile exists — load dashboard data
  const [plan, meals, drinks, presets, ingredients, training, health, sleep] =
    await Promise.all([
      safeQuery(() => getNutritionDay(today), null),
      safeQuery(() => getMeals(today), []),
      safeQuery(() => getDrinks(today), []),
      safeQuery(() => getPresets(), []),
      safeQuery(() => getIngredients(), []),
      safeQuery(() => getTrainingDay(today), null),
      safeQuery(() => getHealthSummary(today), null),
      safeQuery(() => getSleepDetail(today), null),
    ]);

  return (
    <>
      {tabBar}
      <div className="max-w-lg mx-auto px-4 py-6 lg:max-w-5xl">
        <NutritionDashboard
          date={today}
          plan={plan}
          meals={meals}
          drinks={drinks}
          presets={presets}
          ingredients={ingredients}
          training={training}
          health={health}
          sleep={sleep}
        />
      </div>
    </>
  );
}
