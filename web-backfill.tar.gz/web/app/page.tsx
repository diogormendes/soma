import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ExpandableChartCard } from "@/components/expandable-chart-card";
import { ClickableStatCards } from "@/components/clickable-stat-cards";
import { InteractiveChartCards } from "@/components/interactive-chart-cards";
import { ClickableRecentActivity } from "@/components/clickable-recent-activity";
import { ClickableRecoveryCard } from "@/components/clickable-recovery-card";
import { ClickableLastWorkout } from "@/components/clickable-last-workout";
import { StepsTrendChart } from "@/components/steps-trend-chart";
import { CalorieTrendChart } from "@/components/calorie-trend-chart";
import { WeightTrendChart } from "@/components/weight-trend-chart";
import { ActivityHeatmap } from "@/components/activity-heatmap";
import { RHRChart } from "@/components/rhr-chart";
import { StressChart } from "@/components/stress-chart";
import { ExpandableExerciseList } from "@/components/expandable-exercise-list";
import { InteractiveThisWeek } from "@/components/interactive-this-week";
import { TimeRangeSelector } from "@/components/time-range-selector";
import { rangeToDays } from "@/lib/time-ranges";
import { getDb } from "@/lib/db";
import type { Numeric } from "@/lib/json";
import type { HevyExercise } from "@/lib/hevy-types";
import { freshness, staleHeadline, todayKey, RECOVERY_MAX_AGE_DAYS } from "banister";
import { readinessScore, trafficLightText } from "@/lib/readiness";
import {
  Footprints,
  Flame,
  HeartPulse,
  Moon,
  Brain,
  BatteryCharging,
  Activity,
  Dumbbell,
  Wind,
  Snowflake,
  Mountain,
  Zap,
  Calendar,
  Bike,
  Waves,
  PersonStanding,
  Timer,
  Weight,
  Heart,
} from "lucide-react";
import { cutoffIso } from "@/lib/date-range";
import { requestTz, todayForRequest } from "@/lib/request-tz";

export const revalidate = 300;

/**
 * The shapes the queries below select. `Numeric` is a column the driver may hand back as a
 * number or a string (`COUNT`, `SUM`, `ROUND`, `::bigint`), and null when the group is empty.
 */
interface GymFreqRow {
  month: string;
  workouts: Numeric;
}

interface ActivityCountRow {
  type_key: string;
  cnt: Numeric;
}

interface HevyWorkoutRow {
  workout_id: string;
  title: string | null;
  start_time: string;
  end_time: string | null;
}

interface RecentActivity {
  activity_id: string | null;
  type_key: string;
  date: string;
  name: string;
  distance_km: Numeric;
  duration_min: Numeric;
  calories: Numeric;
  begin_ts?: Numeric;
  workout_id: string | null;
}

interface WeekSummaryRow {
  period: string;
  sessions: Numeric;
  total_hours: Numeric;
  total_km: Numeric;
  total_cal: Numeric;
}

interface StepsRow {
  date: string;
  steps: Numeric;
}

interface CalorieRow {
  date: string;
  active: Numeric;
  bmr: Numeric;
}

interface WeightRow {
  date: string;
  weight_kg: Numeric;
  body_fat: Numeric;
}

interface StressRow {
  date: string;
  avg_stress: Numeric;
  max_stress: Numeric;
}

interface RhrRow {
  date: string;
  rhr: Numeric;
}

/** One activity inside a heatmap day. Garmin days carry a begin_ts; Hevy-only days do not. */
interface HeatmapActivity {
  activity_id: string | null;
  type_key: string;
  name: string;
  begin_ts: Numeric;
  workout_id: string | null;
}

interface HeatmapDay {
  date: string;
  count: Numeric;
  types: string[];
  activities: HeatmapActivity[];
}

async function getTodayHealth() {
  const sql = getDb();
  // Pull the last 7 days, not just today. Today's row is often partial (Garmin
  // syncs fields at different times), so a field can be null while its weekly
  // delta is live — the KPI then rendered "—" next to "↑ +50%". Backfill each
  // null field from the most recent older day so the value matches the delta.
  const rows = await sql`
    SELECT * FROM daily_health_summary
    ORDER BY date DESC
    LIMIT 7
  `;
  if (!rows.length) return null;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const merged: Record<string, any> = { ...rows[0] };
  for (const row of rows.slice(1)) {
    for (const key of Object.keys(row)) {
      if (merged[key] == null && row[key] != null) merged[key] = row[key];
    }
  }
  return merged;
}

async function getWeeklyAverages() {
  // His calendar date on the device making this request, never the database's New York clock.
  const today = await todayForRequest();
  const sql = getDb();
  const rows = await sql`
    SELECT
      ROUND(AVG(total_steps)) as avg_steps,
      ROUND(AVG(sleep_time_seconds)) as avg_sleep,
      ROUND(AVG(resting_heart_rate)) as avg_rhr,
      ROUND(AVG(avg_stress_level)) as avg_stress,
      ROUND(AVG(active_kilocalories)) as avg_active_cal,
      COUNT(*) as days_count
    FROM daily_health_summary
    WHERE date >= ${today}::date - 7
  `;
  return rows[0] || null;
}

async function getPreviousWeekAverages() {
  // His calendar date on the device making this request, never the database's New York clock.
  const today = await todayForRequest();
  const sql = getDb();
  const rows = await sql`
    SELECT
      ROUND(AVG(total_steps)) as avg_steps,
      ROUND(AVG(sleep_time_seconds)) as avg_sleep,
      ROUND(AVG(resting_heart_rate)) as avg_rhr,
      ROUND(AVG(avg_stress_level)) as avg_stress,
      ROUND(AVG(active_kilocalories)) as avg_active_cal,
      COUNT(*) as days_count
    FROM daily_health_summary
    WHERE date >= ${today}::date - 14 AND date < ${today}::date - 7
  `;
  return rows[0] || null;
}

/** Compute % change between two numbers. Returns null if prev is 0/null. */
function pctChange(current: number | null, previous: number | null): number | null {
  if (!current || !previous || previous === 0) return null;
  return ((current - previous) / previous) * 100;
}

async function getWorkoutStats(cutoff: string) {
  const sql = getDb();
  // Range-scoped so the Gym Frequency headline matches the range-scoped
  // Activity Breakdown Gym count beside it (was an all-time COUNT(*)).
  const rows = await sql`
    SELECT
      COUNT(*) as total_workouts,
      MAX(raw_json->>'start_time') as last_workout
    FROM hevy_raw_data
    WHERE endpoint_name = 'workout'
      AND (raw_json->>'start_time')::timestamp >= ${cutoff}::date
  `;
  const recent = await sql`
    SELECT COUNT(*) as count_7d
    FROM hevy_raw_data
    WHERE endpoint_name = 'workout'
      AND (raw_json->>'start_time')::timestamp >= NOW() - INTERVAL '7 days'
  `;
  return {
    total: rows[0]?.total_workouts ?? 0,
    last: rows[0]?.last_workout ?? null,
    count_7d: recent[0]?.count_7d ?? 0,
  };
}

async function getGymFrequency(cutoff: string) {
  const sql = getDb();
  // Hevy's start_time is UTC. Cast to a plain timestamp it keeps the UTC wall clock, so a session just
  // after his midnight on the 1st landed in the previous month. Same conversion as workouts/page.tsx.
  const tz = await requestTz();
  const rows = await sql`
    SELECT
      TO_CHAR((raw_json->>'start_time')::timestamptz AT TIME ZONE ${tz}, 'YYYY-MM') as month,
      COUNT(*) as workouts
    FROM hevy_raw_data
    WHERE endpoint_name = 'workout'
      AND (raw_json->>'start_time')::timestamptz AT TIME ZONE ${tz} >= ${cutoff}::date
    GROUP BY month
    ORDER BY month ASC
  `;
  return rows as GymFreqRow[];
}

async function getRunningStats(cutoff: string) {
  const sql = getDb();
  const rows = await sql`
    SELECT
      COUNT(*) as total_runs,
      SUM((raw_json->>'distance')::float) / 1000.0 as total_km,
      -- VO2max is a point-in-time fitness metric, not a range aggregate: show the
      -- latest value regardless of the selected range (was MAX-over-range, which
      -- made it read 54 at 6M but 57 at "All").
      (SELECT (a.raw_json->>'vO2MaxValue')::float
         FROM garmin_activity_raw a
        WHERE a.endpoint_name = 'summary'
          AND a.raw_json->>'vO2MaxValue' IS NOT NULL
          AND a.raw_json->'activityType'->>'typeKey' IN ('running', 'treadmill_running')
        ORDER BY a.activity_id DESC
        LIMIT 1) as vo2max
    FROM garmin_activity_raw
    WHERE endpoint_name = 'summary'
      AND raw_json->'activityType'->>'typeKey' IN ('running', 'treadmill_running')
      AND (raw_json->>'startTimeLocal')::timestamp >= ${cutoff}::date
  `;
  return rows[0] || null;
}

async function getActivityCounts(cutoff: string) {
  const sql = getDb();
  // Garmin activities (non-strength)
  const garminRows = await sql`
    SELECT
      raw_json->'activityType'->>'typeKey' as type_key,
      COUNT(*) as cnt
    FROM garmin_activity_raw
    WHERE endpoint_name = 'summary'
      AND (raw_json->>'startTimeLocal')::timestamp >= ${cutoff}::date
    GROUP BY type_key
    ORDER BY cnt DESC
  `;
  // Hevy workouts (authoritative for gym/strength data)
  const hevyCount = await sql`
    SELECT COUNT(*) as cnt
    FROM hevy_raw_data
    WHERE endpoint_name = 'workout'
      AND (raw_json->>'start_time')::timestamp >= ${cutoff}::date
  `;
  const hevyCnt = Number(hevyCount[0]?.cnt || 0);

  // Replace Garmin strength counts with Hevy count (avoids double-counting)
  const strengthTypes = new Set(["strength_training", "gym"]);
  const rows = (garminRows as ActivityCountRow[]).filter((r) => !strengthTypes.has(r.type_key));
  if (hevyCnt > 0) {
    rows.push({ type_key: "strength_training", cnt: hevyCnt });
  }
  return rows;
}

async function getRecentActivities(cutoff: string) {
  const sql = getDb();
  // Get recent Garmin activities (dedup by startTime+name, keep highest-calorie entry)
  const garminRows = await sql`
    SELECT * FROM (
      SELECT DISTINCT ON ((raw_json->>'startTimeLocal'), raw_json->>'activityName')
        activity_id::text as activity_id,
        raw_json->'activityType'->>'typeKey' as type_key,
        (raw_json->>'startTimeLocal')::text as date,
        raw_json->>'activityName' as name,
        (raw_json->>'distance')::float / 1000.0 as distance_km,
        (raw_json->>'duration')::float / 60.0 as duration_min,
        (raw_json->>'calories')::float as calories,
        (raw_json->>'beginTimestamp')::bigint as begin_ts
      FROM garmin_activity_raw
      WHERE endpoint_name = 'summary'
        AND (raw_json->>'startTimeLocal')::timestamp >= ${cutoff}::date
      ORDER BY (raw_json->>'startTimeLocal'), raw_json->>'activityName', (raw_json->>'calories')::float DESC
    ) deduped
    ORDER BY date DESC
    LIMIT 15
  `;

  // Get all recent Hevy workouts (to match gym activities AND find Hevy-only workouts)
  const hevyRows = await sql`
    SELECT
      raw_json->>'id' as workout_id,
      raw_json->>'title' as title,
      raw_json->>'start_time' as start_time,
      raw_json->>'end_time' as end_time
    FROM hevy_raw_data
    WHERE endpoint_name = 'workout'
      AND (raw_json->>'start_time')::timestamp >= ${cutoff}::date
    ORDER BY raw_json->>'start_time' DESC
    LIMIT 20
  `;

  // Match Garmin strength activities to Hevy workouts by timestamp proximity (within 4 hours)
  // This avoids timezone mismatch: Garmin uses local time, Hevy uses UTC
  const matchedHevyIds = new Set<string>();
  const MATCH_WINDOW_MS = 4 * 3600 * 1000; // 4 hours

  const hevy = hevyRows as HevyWorkoutRow[];

  const merged: RecentActivity[] = (garminRows as Omit<RecentActivity, "workout_id">[]).map((r) => {
    if (r.type_key !== "strength_training") return { ...r, workout_id: null };

    const garminMs = Number(r.begin_ts);
    let bestMatch: HevyWorkoutRow | null = null;
    let bestDiff = Infinity;
    for (const h of hevy) {
      const hevyMs = new Date(h.start_time).getTime();
      const diff = Math.abs(garminMs - hevyMs);
      if (diff < MATCH_WINDOW_MS && diff < bestDiff) {
        bestDiff = diff;
        bestMatch = h;
      }
    }
    if (bestMatch) matchedHevyIds.add(bestMatch.workout_id);
    return { ...r, workout_id: bestMatch?.workout_id || null };
  });

  // Add Hevy-only workouts (not matched to any Garmin activity)
  for (const h of hevy) {
    if (matchedHevyIds.has(h.workout_id)) continue;
    const start = new Date(h.start_time);
    const end = h.end_time ? new Date(h.end_time) : start;
    const durationMin = (end.getTime() - start.getTime()) / 60000;
    merged.push({
      activity_id: null,
      type_key: "strength_training",
      date: h.start_time,
      name: h.title || "Workout",
      distance_km: 0,
      duration_min: durationMin > 0 ? durationMin : 0,
      calories: null,
      workout_id: h.workout_id,
    });
  }

  // Sort by date descending and limit
  merged.sort((a, b) => {
    const da = new Date(a.date).getTime();
    const db = new Date(b.date).getTime();
    return db - da;
  });

  return merged.slice(0, 15);
}

async function getWeeklyTrainingSummary() {
  // His calendar date on the device making this request, never the database's New York clock.
  const today = await todayForRequest();
  const sql = getDb();
  // This week (Mon-Sun) and last week
  // Use all Garmin activities (they have calorie/distance data)
  // Note: Hevy gym workouts also appear in Garmin via sync, so Garmin is complete for recent weeks
  const rows = await sql`
    WITH week_data AS (
      SELECT
        CASE
          WHEN (raw_json->>'startTimeLocal')::timestamp >= DATE_TRUNC('week', ${today}::date)
          THEN 'this_week'
          ELSE 'last_week'
        END as period,
        raw_json->'activityType'->>'typeKey' as type_key,
        (raw_json->>'duration')::float / 3600.0 as hours,
        (raw_json->>'distance')::float / 1000.0 as km,
        (raw_json->>'calories')::float as cal
      FROM garmin_activity_raw
      WHERE endpoint_name = 'summary'
        AND (raw_json->>'startTimeLocal')::timestamp >= DATE_TRUNC('week', ${today}::date) - INTERVAL '7 days'
    )
    SELECT
      period,
      COUNT(*) as sessions,
      ROUND(SUM(hours)::numeric, 1) as total_hours,
      ROUND(SUM(km)::numeric, 0) as total_km,
      ROUND(SUM(cal)::numeric, 0) as total_cal
    FROM week_data
    GROUP BY period
  `;
  const result: Record<string, WeekSummaryRow> = {};
  for (const r of rows as WeekSummaryRow[]) result[r.period] = r;
  return result;
}

async function getTrainingStreak() {
  const sql = getDb();
  // Get distinct training dates from both Garmin and Hevy
  const rows = await sql`
    SELECT DISTINCT day FROM (
      SELECT LEFT((raw_json->>'startTimeLocal')::text, 10) as day
      FROM garmin_activity_raw
      WHERE endpoint_name = 'summary'
      UNION
      SELECT LEFT((raw_json->>'start_time')::text, 10) as day
      FROM hevy_raw_data
      WHERE endpoint_name = 'workout'
    ) combined
    ORDER BY day DESC
    LIMIT 90
  `;
  if (!rows.length) return 0;

  let streak = 0;
  const today = new Date();
  const todayStr = today.toISOString().slice(0, 10);
  const days = new Set((rows as { day: string }[]).map((r) => r.day));

  // Check from today backwards
  const d = new Date(today);
  // If no activity today, start from yesterday
  if (!days.has(todayStr)) {
    d.setDate(d.getDate() - 1);
  }

  while (days.has(d.toISOString().slice(0, 10))) {
    streak++;
    d.setDate(d.getDate() - 1);
  }

  return streak;
}

async function getStepsTrend(cutoff: string) {
  const sql = getDb();
  const rows = await sql`
    SELECT
      date::text as date,
      total_steps as steps
    FROM daily_health_summary
    WHERE total_steps > 0
      AND date >= ${cutoff}::date
    ORDER BY date ASC
  `;
  return rows as StepsRow[];
}

async function getCalorieTrend(cutoff: string) {
  const sql = getDb();
  const rows = await sql`
    SELECT
      date::text as date,
      active_kilocalories as active,
      bmr_kilocalories as bmr
    FROM daily_health_summary
    WHERE active_kilocalories > 0
      AND bmr_kilocalories > 0
      AND date >= ${cutoff}::date
    ORDER BY date ASC
  `;
  return rows as CalorieRow[];
}

async function getFitnessAge() {
  const sql = getDb();
  const rows = await sql`
    SELECT
      date::text as date,
      (raw_json->>'fitnessAge')::float as fitness_age,
      (raw_json->>'chronologicalAge')::int as chrono_age,
      (raw_json->>'achievableFitnessAge')::float as achievable_age,
      raw_json->'components' as components
    FROM garmin_raw_data
    WHERE endpoint_name = 'fitnessage_data'
      AND raw_json->>'fitnessAge' IS NOT NULL
    ORDER BY date DESC
    LIMIT 1
  `;
  return rows[0] || null;
}

async function getIntensityMinutes() {
  const sql = getDb();
  const rows = await sql`
    SELECT
      date::text as date,
      (raw_json->>'weekGoal')::int as goal,
      (raw_json->>'weeklyTotal')::int as weekly_total,
      (raw_json->>'weeklyModerate')::int as weekly_moderate,
      (raw_json->>'weeklyVigorous')::int as weekly_vigorous
    FROM garmin_raw_data
    WHERE endpoint_name = 'intensity_minutes_data'
      AND raw_json->>'weekGoal' IS NOT NULL
    ORDER BY date DESC
    LIMIT 1
  `;
  return rows[0] || null;
}

async function getWeightTrend(cutoff: string) {
  const sql = getDb();
  const rows = await sql`
    SELECT
      date::text as date,
      (raw_json->'totalAverage'->>'weight')::float / 1000.0 as weight_kg,
      (raw_json->'totalAverage'->>'bodyFat')::float as body_fat
    FROM garmin_raw_data
    WHERE endpoint_name = 'body_composition'
      AND raw_json->'totalAverage'->>'weight' IS NOT NULL
      AND date >= ${cutoff}::date
    ORDER BY date ASC
  `;
  return rows as WeightRow[];
}

async function getRecoverySummary() {
  const sql = getDb();
  // Get latest body battery, HRV, Garmin training readiness, and soma's own
  // model readiness (headlined; Garmin is shown as the secondary comparison).
  const [bb, hrv, tr, model] = await Promise.all([
    sql`
      SELECT
        date::text as date,
        (raw_json->>'bodyBatteryChargedValue')::int as charged,
        (raw_json->>'bodyBatteryDrainedValue')::int as drained
      FROM garmin_raw_data
      WHERE endpoint_name = 'user_summary'
        AND raw_json->>'bodyBatteryChargedValue' IS NOT NULL
        AND (raw_json->>'bodyBatteryChargedValue')::int > 0
      ORDER BY date DESC LIMIT 1
    `,
    sql`
      SELECT
        date::text as date,
        (raw_json->'hrvSummary'->>'weeklyAvg')::int as weekly_avg,
        (raw_json->'hrvSummary'->>'lastNightAvg')::int as last_night,
        raw_json->'hrvSummary'->>'status' as status
      FROM garmin_raw_data
      WHERE endpoint_name = 'hrv_data'
        AND raw_json->'hrvSummary'->>'weeklyAvg' IS NOT NULL
      ORDER BY date DESC LIMIT 1
    `,
    sql`
      SELECT
        date::text as date,
        (raw_json->0->>'score')::int as score,
        raw_json->0->>'level' as level
      FROM garmin_raw_data
      WHERE endpoint_name = 'training_readiness'
        AND raw_json->0->>'score' IS NOT NULL
      ORDER BY date DESC LIMIT 1
    `,
    sql`
      SELECT date::text as date, traffic_light, composite_score
      FROM daily_readiness
      ORDER BY date DESC LIMIT 1
    `.catch(() => []),  // demo DB has no daily_readiness table — fall back to Garmin readiness
  ]);
  return {
    bodyBattery: bb[0] || null,
    hrv: hrv[0] || null,
    readiness: tr[0] || null,
    model: model[0] || null,
  };
}

async function getLatestSleep() {
  const sql = getDb();
  const rows = await sql`
    SELECT
      (raw_json->'dailySleepDTO'->>'sleepTimeSeconds')::int as total,
      (raw_json->'dailySleepDTO'->'sleepScores'->'overall'->>'value')::int as score,
      (raw_json->'dailySleepDTO'->'sleepScores'->'overall'->>'qualifierKey') as quality,
      date::text as date
    FROM garmin_raw_data
    WHERE endpoint_name = 'sleep_data'
      AND (raw_json->'dailySleepDTO'->>'sleepTimeSeconds')::int > 0
    ORDER BY date DESC
    LIMIT 1
  `;
  return rows[0] || null;
}

async function getStressTrend(cutoff: string) {
  const sql = getDb();
  const rows = await sql`
    SELECT
      date::text as date,
      avg_stress_level as avg_stress,
      max_stress_level as max_stress
    FROM daily_health_summary
    WHERE avg_stress_level > 0
      AND date >= ${cutoff}::date
    ORDER BY date ASC
  `;
  return rows as StressRow[];
}

async function getRestingHRTrend(cutoff: string) {
  const sql = getDb();
  const rows = await sql`
    SELECT
      date::text as date,
      resting_heart_rate as rhr
    FROM daily_health_summary
    WHERE resting_heart_rate > 0
      AND date >= ${cutoff}::date
    ORDER BY date ASC
  `;
  return rows as RhrRow[];
}



async function getActivityHeatmap(cutoff: string) {
  const sql = getDb();
  const rows = await sql`
    SELECT
      LEFT((raw_json->>'startTimeLocal')::text, 10) as date,
      COUNT(*) as count,
      array_agg(DISTINCT raw_json->'activityType'->>'typeKey') as types,
      json_agg(json_build_object(
        'activity_id', activity_id::text,
        'type_key', raw_json->'activityType'->>'typeKey',
        'name', raw_json->>'activityName',
        'begin_ts', (raw_json->>'beginTimestamp')::bigint
      )) as activities
    FROM garmin_activity_raw
    WHERE endpoint_name = 'summary'
      AND (raw_json->>'startTimeLocal')::timestamp >= ${cutoff}::date
    GROUP BY date
    ORDER BY date ASC
  `;

  // Get ALL Hevy workouts in range for matching and adding Hevy-only days
  const hevyRows = await sql`
    SELECT
      raw_json->>'id' as workout_id,
      raw_json->>'start_time' as start_time,
      raw_json->>'title' as title
    FROM hevy_raw_data
    WHERE endpoint_name = 'workout'
      AND (raw_json->>'start_time')::timestamp >= ${cutoff}::date
    ORDER BY raw_json->>'start_time' DESC
  `;
  const hevyList = (hevyRows as HevyWorkoutRow[]).map((r) => ({
    workout_id: r.workout_id,
    start_ms: new Date(r.start_time).getTime(),
    start_time: r.start_time,
    title: r.title,
  }));

  const MATCH_WINDOW_MS = 4 * 3600 * 1000;
  const matchedHevyIds = new Set<string>();

  // Match Garmin strength_training activities with Hevy workouts
  const garminResult: HeatmapDay[] = (rows as (Omit<HeatmapDay, "activities"> & {
    activities: HeatmapActivity[] | string;
  })[]).map((row) => {
    const acts: HeatmapActivity[] =
      typeof row.activities === "string" ? JSON.parse(row.activities) : row.activities;
    return {
      ...row,
      activities: acts.map((a) => {
        if (a.type_key !== "strength_training" || !a.begin_ts) return { ...a, workout_id: null };
        const garminMs = Number(a.begin_ts);
        let bestId: string | null = null;
        let bestDiff = Infinity;
        for (const h of hevyList) {
          const diff = Math.abs(garminMs - h.start_ms);
          if (diff < MATCH_WINDOW_MS && diff < bestDiff) {
            bestDiff = diff;
            bestId = h.workout_id;
          }
        }
        if (bestId) matchedHevyIds.add(bestId);
        return { ...a, workout_id: bestId };
      }),
    };
  });

  // Add Hevy-only workouts (not matched to any Garmin activity)
  const resultMap = new Map(garminResult.map((r) => [r.date, r]));
  for (const h of hevyList) {
    if (matchedHevyIds.has(h.workout_id)) continue;
    const dateStr = h.start_time.slice(0, 10);
    const existing = resultMap.get(dateStr);
    const hevyActivity: HeatmapActivity = {
      activity_id: null,
      type_key: "strength_training",
      name: h.title || "Gym",
      begin_ts: h.start_ms,
      workout_id: h.workout_id,
    };
    if (existing) {
      existing.count = Number(existing.count) + 1;
      existing.activities.push(hevyActivity);
      if (!existing.types.includes("strength_training")) {
        existing.types.push("strength_training");
      }
    } else {
      const newRow: HeatmapDay = {
        date: dateStr,
        count: 1,
        types: ["strength_training"],
        activities: [hevyActivity],
      };
      resultMap.set(dateStr, newRow);
    }
  }

  return Array.from(resultMap.values()).sort((a, b) => a.date.localeCompare(b.date));
}

async function getLastWorkoutDetail() {
  const sql = getDb();
  const rows = await sql`
    SELECT
      raw_json->>'id' as workout_id,
      raw_json->>'title' as title,
      raw_json->>'start_time' as start_time,
      raw_json->>'end_time' as end_time,
      raw_json->'exercises' as exercises
    FROM hevy_raw_data
    WHERE endpoint_name = 'workout'
    ORDER BY raw_json->>'start_time' DESC
    LIMIT 1
  `;
  if (!rows[0]) return null;
  const w = rows[0];
  const exercises: HevyExercise[] =
    typeof w.exercises === "string" ? JSON.parse(w.exercises) : w.exercises;
  // An exercise Hevy returned without a title, or without a sets array, is skipped rather than
  // rendered as "undefined" or counted as zero volume.
  const exerciseNames = exercises.map((e) => e.title).filter((t): t is string => Boolean(t));
  let totalSets = 0;
  let totalVolume = 0;
  for (const ex of exercises) {
    for (const s of ex.sets ?? []) {
      const kg = s.weight_kg ?? 0;
      const reps = s.reps ?? 0;
      if (s.type === "normal" && kg > 0 && reps > 0) {
        totalSets++;
        totalVolume += kg * reps;
      }
    }
  }
  const durationMin = Math.round(
    (new Date(w.end_time).getTime() - new Date(w.start_time).getTime()) / 60000
  );
  return {
    workoutId: w.workout_id,
    title: w.title,
    date: w.start_time,
    exercises: exerciseNames,
    totalSets,
    totalVolume: Math.round(totalVolume),
    durationMin,
  };
}

const _ACTIVITY_ICONS: Record<string, React.ReactNode> = {
  running: <Footprints className="h-3.5 w-3.5 text-green-400" />,
  strength_training: <Dumbbell className="h-3.5 w-3.5 text-orange-400" />,
  kiteboarding_v2: <Wind className="h-3.5 w-3.5 text-cyan-400" />,
  wind_kite_surfing: <Wind className="h-3.5 w-3.5 text-cyan-400" />,
  resort_snowboarding: <Snowflake className="h-3.5 w-3.5 text-blue-300" />,
  resort_skiing_snowboarding_ws: <Snowflake className="h-3.5 w-3.5 text-blue-300" />,
  hiking: <Mountain className="h-3.5 w-3.5 text-green-400" />,
  walking: <PersonStanding className="h-3.5 w-3.5 text-emerald-400" />,
  lap_swimming: <Waves className="h-3.5 w-3.5 text-blue-400" />,
  cycling: <Bike className="h-3.5 w-3.5 text-yellow-400" />,
  e_bike_fitness: <Bike className="h-3.5 w-3.5 text-yellow-400" />,
  indoor_cardio: <Heart className="h-3.5 w-3.5 text-red-400" />,
  indoor_cycling: <Bike className="h-3.5 w-3.5 text-yellow-400" />,
  stand_up_paddleboarding_v2: <Waves className="h-3.5 w-3.5 text-cyan-300" />,
};

const _ACTIVITY_BAR_COLORS: Record<string, string> = {
  running: "bg-green-500/70",
  strength_training: "bg-orange-500/70",
  kiteboarding_v2: "bg-cyan-500/70",
  resort_snowboarding: "bg-blue-400/70",
  hiking: "bg-emerald-500/70",
  walking: "bg-emerald-400/70",
  lap_swimming: "bg-blue-500/70",
  cycling: "bg-yellow-500/70",
  e_bike_fitness: "bg-yellow-500/70",
  indoor_cardio: "bg-red-400/70",
  indoor_cycling: "bg-yellow-500/70",
  stand_up_paddleboarding_v2: "bg-cyan-400/70",
  other: "bg-violet-400/70",
};

const _ACTIVITY_LABELS: Record<string, string> = {
  running: "Run",
  strength_training: "Gym",
  kiteboarding_v2: "Kite",
  wind_kite_surfing: "Kite",
  resort_snowboarding: "Snow",
  resort_skiing_snowboarding_ws: "Snow",
  hiking: "Hike",
  e_bike_fitness: "E-Bike",
  lap_swimming: "Swim",
  walking: "Walk",
  indoor_cardio: "Cardio",
  indoor_rowing: "Row",
  yoga: "Yoga",
  cycling: "Cycle",
  elliptical: "Elliptical",
  stand_up_paddleboarding_v2: "SUP",
  other: "Other",
};

// Merge these activity type_keys into a single group for display
const MERGE_TYPES: Record<string, string> = {
  wind_kite_surfing: "kiteboarding_v2",
  resort_skiing_snowboarding_ws: "resort_snowboarding",
  treadmill_running: "running",
  indoor_cycling: "cycling",
  swimming: "lap_swimming",
  open_water_swimming: "lap_swimming",
};

function _formatDuration(mins: number) {
  const h = Math.floor(mins / 60);
  const m = Math.round(mins % 60);
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

export default async function HomePage({
  searchParams,
}: {
  searchParams: Promise<{ range?: string }>;
}) {
  const { range: rangeParam } = await searchParams;
  const rangeDays = rangeToDays(rangeParam);
  const cutoff = cutoffIso(rangeDays);
  const heatmapCutoff = cutoffIso(Math.min(rangeDays, 365));

  const [health, weekly, prevWeekly, workouts, gymFreq, runStats, activityCounts, recentActivities, lastWorkout, weeklyTraining, streak, stepsTrend, fitnessAge, intensityMin, weightTrend, calorieTrend, heatmapData, latestSleep, recovery, rhrTrend, stressTrend] =
    await Promise.all([
      getTodayHealth(),
      getWeeklyAverages(),
      getPreviousWeekAverages(),
      getWorkoutStats(cutoff),
      getGymFrequency(cutoff),
      getRunningStats(cutoff),
      getActivityCounts(cutoff),
      getRecentActivities(cutoff),
      getLastWorkoutDetail(),
      getWeeklyTrainingSummary(),
      getTrainingStreak(),
      getStepsTrend(cutoff),
      getFitnessAge(),
      getIntensityMinutes(),
      getWeightTrend(cutoff),
      getCalorieTrend(cutoff),
      getActivityHeatmap(heatmapCutoff),
      getLatestSleep(),
      getRecoverySummary(),
      getRestingHRTrend(cutoff),
      getStressTrend(cutoff),
    ]);

  // Compute 7-day vs prior-7-day trends
  const stepsTrendPct = pctChange(Number(weekly?.avg_steps), Number(prevWeekly?.avg_steps));
  const calTrendPct = pctChange(Number(weekly?.avg_active_cal), Number(prevWeekly?.avg_active_cal));
  const rhrTrendPct = pctChange(Number(weekly?.avg_rhr), Number(prevWeekly?.avg_rhr));
  const sleepTrendPct = pctChange(Number(weekly?.avg_sleep), Number(prevWeekly?.avg_sleep));
  const stressTrendPct = pctChange(Number(weekly?.avg_stress), Number(prevWeekly?.avg_stress));

  // Merge duplicate activity types
  const mergedCounts: { type_key: string; cnt: number }[] = [];
  const seen = new Set<string>();
  for (const row of activityCounts) {
    const canonical = MERGE_TYPES[row.type_key] || row.type_key;
    if (seen.has(canonical)) {
      const existing = mergedCounts.find((m) => m.type_key === canonical);
      if (existing) existing.cnt += Number(row.cnt);
    } else {
      seen.add(canonical);
      mergedCounts.push({ type_key: canonical, cnt: Number(row.cnt) });
    }
  }
  mergedCounts.sort((a, b) => b.cnt - a.cnt);
  const totalActivities = mergedCounts.reduce((s, r) => s + r.cnt, 0);

  return (
    <div className="container mx-auto px-3 sm:px-6 py-4 sm:py-8 max-w-7xl">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between mb-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Overview</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {health?.date
              ? `Latest: ${new Date(health.date).toLocaleDateString("en-US", {
                  weekday: "long",
                  month: "long",
                  day: "numeric",
                })}`
              : "No data synced yet."}
          </p>
        </div>
        <TimeRangeSelector />
      </div>

      {/* Clickable Stat Cards with Detail Dialogs */}
      <ClickableStatCards
        primaryCards={[
          {
            metric: "steps",
            title: "Steps",
            value: health?.total_steps?.toLocaleString() ?? "—",
            subtitle: health?.total_distance_meters
              ? `${(health.total_distance_meters / 1000).toFixed(1)} km`
              : undefined,
            icon: <Footprints className="h-4 w-4 text-muted-foreground" />,
            info: "Daily step count from your Garmin watch",
            trend: stepsTrendPct != null ? { value: stepsTrendPct, label: "7-day avg vs prior week" } : null,
          },
          {
            metric: "calories",
            title: "Active Calories",
            value: health?.active_kilocalories?.toLocaleString() ?? "—",
            subtitle: health?.total_kilocalories
              ? `${health.total_kilocalories.toLocaleString()} total`
              : undefined,
            icon: <Flame className="h-4 w-4 text-orange-400" />,
            info: "Calories burned above your BMR through activity",
            trend: calTrendPct != null ? { value: calTrendPct, label: "7-day avg vs prior week" } : null,
          },
          {
            metric: "rhr",
            title: "Resting HR",
            value: health?.resting_heart_rate ? `${health.resting_heart_rate}` : "—",
            subtitle: health?.min_heart_rate && health?.max_heart_rate
              ? `Range: ${health.min_heart_rate}–${health.max_heart_rate} bpm`
              : undefined,
            icon: <HeartPulse className="h-4 w-4 text-red-400" />,
            info: "Lower resting HR generally indicates better cardiovascular fitness. Elite athletes: 40-50 bpm",
            // For RHR, lower is better — invert so a decrease shows green
            trend: rhrTrendPct != null ? { value: -rhrTrendPct, label: "7-day avg vs prior week (lower is better)" } : null,
          },
          {
            metric: "vo2max",
            title: "VO2max",
            value: runStats?.vo2max ? `${Number(runStats.vo2max).toFixed(1)}` : "—",
            subtitle: "ml/kg/min",
            icon: <Zap className="h-4 w-4 text-yellow-400" />,
            info: "Maximum oxygen uptake. Higher is better. Excellent: 50+ ml/kg/min",
          },
        ]}
        secondaryCards={[
          {
            metric: "sleep",
            title: "Sleep",
            // A night older than the watch's cadence is not the headline: absent is
            // unknown, not the last night we saw (#713, #731).
            value: (() => {
              if (health?.sleep_time_seconds) return `${(health.sleep_time_seconds / 3600).toFixed(1)}h`;
              const f = freshness(latestSleep?.date ?? null, todayKey());
              return !f.stale && latestSleep?.total ? `${(latestSleep.total / 3600).toFixed(1)}h` : "—";
            })(),
            subtitle: (() => {
              if (health?.sleep_time_seconds) return latestSleep?.score ? `Score: ${latestSleep.score}` : undefined;
              const f = freshness(latestSleep?.date ?? null, todayKey());
              if (!f.stale) return [latestSleep?.score ? `Score: ${latestSleep.score}` : "", latestSleep?.date ?? ""].filter(Boolean).join(" · ") || undefined;
              const last = latestSleep?.total ? ` · last ${(latestSleep.total / 3600).toFixed(1)}h` : "";
              return `${staleHeadline("night", f)}${last}`;
            })(),
            icon: <Moon className="h-4 w-4 text-indigo-400" />,
            info: "Total sleep time from Garmin sleep tracking. Recommended: 7-9 hours",
            trend: sleepTrendPct != null ? { value: sleepTrendPct, label: "7-day avg vs prior week" } : null,
          },
          {
            metric: "stress",
            title: "Avg Stress",
            value: health?.avg_stress_level ? health.avg_stress_level : "—",
            subtitle: health?.max_stress_level
              ? `Peak: ${health.max_stress_level}`
              : undefined,
            icon: <Brain className="h-4 w-4 text-yellow-400" />,
            info: "Garmin stress score (0-100). Lower is better. 0-25 = Rest, 26-50 = Low, 51-75 = Medium, 76-100 = High",
            // For stress, lower is better — invert so a decrease shows green
            trend: stressTrendPct != null ? { value: -stressTrendPct, label: "7-day avg vs prior week (lower is better)" } : null,
          },
          {
            metric: "activities",
            title: "Total Activities",
            value: totalActivities,
            subtitle: `${Number(runStats?.total_km || 0).toFixed(0)} km running`,
            icon: <Activity className="h-4 w-4 text-purple-400" />,
            info: "Total tracked activities across all sports in this period",
          },
        ]}
      />

      {/* This Week Training Summary (clickable with dialog) */}
      <InteractiveThisWeek
        metrics={(() => {
          const tw = weeklyTraining.this_week;
          const lw = weeklyTraining.last_week;
          if (!tw) return [];
          return [
            { label: "Sessions", value: Number(tw.sessions), prev: lw ? Number(lw.sessions) : null, unit: "" },
            { label: "Duration", value: Number(tw.total_hours), prev: lw ? Number(lw.total_hours) : null, unit: "h" },
            { label: "Distance", value: Number(tw.total_km), prev: lw ? Number(lw.total_km) : null, unit: "km" },
            { label: "Calories", value: Number(tw.total_cal), prev: lw ? Number(lw.total_cal) : null, unit: "kcal" },
          ];
        })()}
        streak={streak}
      />

      {/* Recovery Summary */}
      {(recovery.bodyBattery || recovery.hrv || recovery.readiness) && (
        <ClickableRecoveryCard>
          <Card className="mb-6">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <BatteryCharging className="h-4 w-4 text-green-400" />
                Recovery Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {(recovery.model || recovery.readiness) && (
                  <div>
                    <div className="text-xs text-muted-foreground mb-1">Readiness</div>
                    {recovery.model?.traffic_light === "unknown" ? (
                      // soma's own model says it cannot know (no night): say so, Garmin as the comparison (#731).
                      <>
                        <div className="text-2xl font-bold text-muted-foreground" data-testid="overview-readiness-unknown">unknown</div>
                        <div className="text-xs text-muted-foreground">
                          {[recovery.readiness ? `Garmin ${recovery.readiness.score}` : "", latestSleep?.date ? `no night recorded since ${latestSleep.date}` : "no night recorded"].filter(Boolean).join(" · ")}
                        </div>
                      </>
                    ) : recovery.model?.composite_score != null ? (
                      // soma's own model readiness (headlined); Garmin below as the comparison.
                      <>
                        <div className={`text-2xl font-bold ${trafficLightText(recovery.model.traffic_light)}`}>
                          {readinessScore(Number(recovery.model.composite_score))}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {recovery.readiness ? `Garmin ${recovery.readiness.score}` : "model"}
                        </div>
                      </>
                    ) : recovery.readiness ? (
                      <>
                        <div className={`text-2xl font-bold ${
                          Number(recovery.readiness.score) >= 70 ? "text-green-400" :
                          Number(recovery.readiness.score) >= 40 ? "text-yellow-400" : "text-red-400"
                        }`}>
                          {recovery.readiness.score}
                        </div>
                        <div className="text-xs text-muted-foreground capitalize">
                          {recovery.readiness.level?.toLowerCase().replace(/_/g, " ")}
                        </div>
                      </>
                    ) : null}
                  </div>
                )}
                {recovery.bodyBattery && (() => {
                  const f = freshness(recovery.bodyBattery.date, todayKey());
                  return (
                  <div data-testid="overview-body-battery" data-freshness={f.stale ? "stale" : "fresh"} data-observed={recovery.bodyBattery.date} data-max-age-days={RECOVERY_MAX_AGE_DAYS}>
                    <div className="text-xs text-muted-foreground mb-1">Body Battery{f.stale ? "" : ` · ${recovery.bodyBattery.date}`}</div>
                    <div className="text-2xl font-bold">
                      {f.stale ? "—" : `+${recovery.bodyBattery.charged}`}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {f.stale ? `${staleHeadline("body battery reading", f)}` : `−${recovery.bodyBattery.drained} drained`}
                    </div>
                  </div>
                  );
                })()}
                {recovery.hrv && (() => {
                  const f = freshness(recovery.hrv.date, todayKey());
                  return (
                  <div data-testid="overview-hrv" data-freshness={f.stale ? "stale" : "fresh"} data-observed={recovery.hrv.date} data-max-age-days={RECOVERY_MAX_AGE_DAYS}>
                    <div className="text-xs text-muted-foreground mb-1">HRV{f.stale ? "" : ` · ${recovery.hrv.date}`}</div>
                    <div className="text-2xl font-bold">
                      {f.stale ? "—" : `${recovery.hrv.last_night ?? recovery.hrv.weekly_avg} ms`}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {f.stale ? `${staleHeadline("HRV reading", f)} · last ${recovery.hrv.last_night ?? recovery.hrv.weekly_avg} ms` : `Weekly avg: ${recovery.hrv.weekly_avg} ms`}
                    </div>
                  </div>
                  );
                })()}
                {recovery.hrv?.status && !freshness(recovery.hrv.date, todayKey()).stale && (
                  <div>
                    <div className="text-xs text-muted-foreground mb-1">HRV Status</div>
                    <div className={`text-2xl font-bold ${
                      recovery.hrv.status === "BALANCED" ? "text-green-400" :
                      recovery.hrv.status === "LOW" ? "text-yellow-400" : "text-blue-400"
                    }`}>
                      {recovery.hrv.status.charAt(0) + recovery.hrv.status.slice(1).toLowerCase()}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </ClickableRecoveryCard>
      )}

      {/* Steps & Calorie Trends */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {stepsTrend.length > 0 && (
          <ExpandableChartCard
            title="Daily Steps"
            icon={<Footprints className="h-4 w-4" />}
            subtitle={weekly?.avg_steps ? `7-day avg: ${Number(weekly.avg_steps).toLocaleString()}` : undefined}
          >
            <StepsTrendChart
              data={stepsTrend.map((s) => ({
                date: s.date,
                steps: Number(s.steps),
              }))}
            />
          </ExpandableChartCard>
        )}

        {calorieTrend.length > 0 && (
          <ExpandableChartCard
            title="Daily Calories"
            icon={<Flame className="h-4 w-4 text-orange-400" />}
            subtitle={weekly?.avg_active_cal ? `7-day active avg: ${Number(weekly.avg_active_cal).toLocaleString()} kcal` : undefined}
          >
            <CalorieTrendChart
              data={calorieTrend.map((c) => ({
                date: c.date,
                active: Number(c.active),
                bmr: Number(c.bmr),
              }))}
            />
          </ExpandableChartCard>
        )}
      </div>

      {/* RHR + Stress Trends */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {rhrTrend.length > 0 && (() => {
          const rhrData = rhrTrend.filter((r) => Number(r.rhr) > 0);
          if (rhrData.length === 0) return null;
          const latest = Number(rhrData[rhrData.length - 1].rhr);
          const avg7d = rhrData.slice(-7).reduce((s: number, r) => s + Number(r.rhr), 0) / Math.min(rhrData.length, 7);
          return (
            <ExpandableChartCard
              title="Resting Heart Rate"
              icon={<HeartPulse className="h-4 w-4 text-red-400" />}
              subtitle={`${latest} bpm · avg ${Math.round(avg7d)}`}
            >
              <RHRChart
                data={rhrData.map((r) => ({
                  date: r.date,
                  rhr: Number(r.rhr),
                }))}
              />
            </ExpandableChartCard>
          );
        })()}

        {stressTrend.length > 0 && (() => {
          const stressData = stressTrend;
          if (stressData.length === 0) return null;
          const latest = Number(stressData[stressData.length - 1].avg_stress);
          const avg7d = stressData.slice(-7).reduce((s: number, r) => s + Number(r.avg_stress), 0) / Math.min(stressData.length, 7);
          return (
            <ExpandableChartCard
              title="Stress Trend"
              icon={<Brain className="h-4 w-4 text-yellow-400" />}
              subtitle={`Today: ${latest} · avg ${Math.round(avg7d)}`}
            >
              <StressChart
                data={stressData.map((s) => ({
                  date: s.date,
                  avg_stress: Number(s.avg_stress),
                  max_stress: Number(s.max_stress),
                }))}
              />
            </ExpandableChartCard>
          );
        })()}
      </div>

      {/* Fitness Metrics Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {/* Fitness Age */}
        {fitnessAge && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Heart className="h-4 w-4 text-red-400" />
                Fitness Age
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end gap-3 mb-2">
                <div className="text-4xl font-bold text-green-400">
                  {Number(fitnessAge.fitness_age).toFixed(1)}
                </div>
                <div className="text-sm text-muted-foreground mb-1">
                  vs {fitnessAge.chrono_age} actual
                </div>
              </div>
              <div className="text-xs text-muted-foreground mb-3">
                {(Number(fitnessAge.chrono_age) - Number(fitnessAge.fitness_age)).toFixed(1)} years younger
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden mb-3">
                <div
                  className="h-full bg-gradient-to-r from-green-500 to-emerald-400 rounded-full"
                  style={{ width: `${Math.min((Number(fitnessAge.fitness_age) / Number(fitnessAge.chrono_age)) * 100, 100)}%` }}
                />
              </div>
              <div className="flex justify-between text-[10px] text-muted-foreground mb-4">
                <span>Best: {Number(fitnessAge.achievable_age).toFixed(1)}</span>
                <span>Actual: {fitnessAge.chrono_age}</span>
              </div>
              {/* Components breakdown */}
              {fitnessAge.components && (() => {
                const comps = typeof fitnessAge.components === "string"
                  ? JSON.parse(fitnessAge.components)
                  : fitnessAge.components;
                const items = [
                  { key: "rhr", label: "Resting HR", value: comps.rhr?.value, unit: "bpm", color: "text-red-400" },
                  { key: "bodyFat", label: "Body Fat", value: comps.bodyFat?.value, unit: "%", target: comps.bodyFat?.targetValue, color: "text-yellow-400" },
                  { key: "vigorousMinutesAvg", label: "Vigorous Min/wk", value: comps.vigorousMinutesAvg?.value, unit: "min", target: comps.vigorousMinutesAvg?.targetValue, color: "text-orange-400" },
                  { key: "vigorousDaysAvg", label: "Vigorous Days/wk", value: comps.vigorousDaysAvg?.value, unit: "days", target: comps.vigorousDaysAvg?.targetValue, color: "text-blue-400" },
                ].filter(c => c.value != null);
                return (
                  <div className="space-y-2">
                    <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Components</div>
                    {items.map((c) => (
                      <div key={c.key} className="flex items-center justify-between text-xs">
                        <span className="text-muted-foreground">{c.label}</span>
                        <div className="flex items-center gap-2">
                          <span className={`font-medium ${c.color}`}>
                            {typeof c.value === "number" ? (Number.isInteger(c.value) ? c.value : Number(c.value).toFixed(1)) : c.value} {c.unit}
                          </span>
                          {c.target && (
                            <span className="text-muted-foreground/50">
                              → {c.target} {c.unit}
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                );
              })()}
            </CardContent>
          </Card>
        )}

        {/* Intensity Minutes */}
        {intensityMin && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Timer className="h-4 w-4 text-emerald-400" />
                Weekly Intensity Minutes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end gap-3 mb-2">
                <div className="text-4xl font-bold">
                  {intensityMin.weekly_total}
                </div>
                <div className="text-sm text-muted-foreground mb-1">
                  / {intensityMin.goal} min goal
                </div>
              </div>
              <div className="h-3 bg-muted rounded-full overflow-hidden mb-2">
                <div
                  className={`h-full rounded-full ${
                    Number(intensityMin.weekly_total) >= Number(intensityMin.goal)
                      ? "bg-green-500"
                      : "bg-emerald-400"
                  }`}
                  style={{ width: `${Math.min((Number(intensityMin.weekly_total) / Number(intensityMin.goal)) * 100, 100)}%` }}
                />
              </div>
              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-blue-400" />
                  Moderate: {intensityMin.weekly_moderate} min
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-orange-400" />
                  Vigorous: {intensityMin.weekly_vigorous} min
                </span>
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                {Math.round((Number(intensityMin.weekly_total) / Number(intensityMin.goal)) * 100)}% of goal
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Body Composition Trend */}
      {weightTrend.length > 0 && (() => {
        const weightData = weightTrend.filter((w) => Number(w.weight_kg) > 0);
        if (weightData.length === 0) return null;
        const latest = weightData[weightData.length - 1];
        const subtitleStr = `${Number(latest.weight_kg).toFixed(1)} kg${latest.body_fat ? ` · ${Number(latest.body_fat).toFixed(1)}% BF` : ""}`;
        return (
          <ExpandableChartCard
            title="Body Composition"
            icon={<Weight className="h-4 w-4 text-blue-400" />}
            subtitle={subtitleStr}
            className="mb-6"
          >
            <WeightTrendChart
              data={weightData.map((w) => ({
                date: w.date,
                weight_kg: Number(w.weight_kg),
                body_fat: w.body_fat ? Number(w.body_fat) : null,
              }))}
            />
          </ExpandableChartCard>
        );
      })()}

      {/* Activity Heatmap */}
      {heatmapData.length > 0 && (
        <Card className="mb-6">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Activity Calendar
              {streak > 0 && (
                <span className="ml-auto text-xs font-normal text-primary">
                  {streak}-day streak
                </span>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ActivityHeatmap
              data={heatmapData.map((d) => ({
                date: d.date,
                count: Number(d.count),
                types: Array.isArray(d.types) ? d.types : [],
                activities: Array.isArray(d.activities)
                  ? d.activities.map((a) => ({
                      activity_id: a.activity_id,
                      type_key: a.type_key,
                      name: a.name,
                      workout_id: a.workout_id || undefined,
                    }))
                  : [],
              }))}
            />
          </CardContent>
        </Card>
      )}

      {/* Recent Activity Feed */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Recent Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ClickableRecentActivity
            activities={recentActivities.map((a) => ({
              type_key: a.type_key,
              date: a.date,
              name: a.name,
              distance_km: Number(a.distance_km),
              duration_min: Number(a.duration_min),
              calories: a.calories ? Number(a.calories) : null,
              activity_id: a.activity_id,
              workout_id: a.workout_id || undefined,
            }))}
          />
        </CardContent>
      </Card>

      {/* Activity Breakdown + Gym Frequency (Interactive) */}
      <InteractiveChartCards
        dayOfWeekData={[]}
        timeOfDayData={[]}
        activityCounts={mergedCounts}
        gymFrequency={gymFreq.map((r) => ({
          month: r.month,
          workouts: Number(r.workouts),
        }))}
        workoutStats={{
          total: Number(workouts.total),
          count_7d: Number(workouts.count_7d),
        }}
        streak={streak}
        totalActivities={totalActivities}
      >
        {/* Last Workout (3rd column in the bottom grid) */}
        {lastWorkout?.workoutId ? (
          <ClickableLastWorkout workoutId={lastWorkout.workoutId}>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Last Gym Session
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold">{lastWorkout.title}</span>
                  <span className="text-xs text-muted-foreground">
                    {new Date(lastWorkout.date).toLocaleDateString("en-US", {
                      month: "short",
                      day: "numeric",
                    })}
                  </span>
                </div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground mb-2">
                  <span>{lastWorkout.durationMin}m</span>
                  <span>{lastWorkout.exercises.length} exercises</span>
                  <span>{lastWorkout.totalSets} sets</span>
                  <span>{lastWorkout.totalVolume.toLocaleString()} kg</span>
                </div>
                <ExpandableExerciseList exercises={lastWorkout.exercises} />
              </CardContent>
            </Card>
          </ClickableLastWorkout>
        ) : (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Last Gym Session
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {lastWorkout ? (
                <>
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold">{lastWorkout.title}</span>
                    <span className="text-xs text-muted-foreground">
                      {new Date(lastWorkout.date).toLocaleDateString("en-US", {
                        month: "short",
                        day: "numeric",
                      })}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground mb-2">
                    <span>{lastWorkout.durationMin}m</span>
                    <span>{lastWorkout.exercises.length} exercises</span>
                    <span>{lastWorkout.totalSets} sets</span>
                    <span>{lastWorkout.totalVolume.toLocaleString()} kg</span>
                  </div>
                  <ExpandableExerciseList exercises={lastWorkout.exercises} />
                </>
              ) : (
                <p className="text-sm text-muted-foreground">No workouts yet</p>
              )}
            </CardContent>
          </Card>
        )}
      </InteractiveChartCards>
    </div>
  );
}
