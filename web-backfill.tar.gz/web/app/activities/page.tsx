import type { Metadata } from "next";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ExpandableChartCard } from "@/components/expandable-chart-card";
import { StatCard } from "@/components/stat-card";
import { MonthlyActivityChart } from "@/components/monthly-activity-chart";
import { KiteSpeedChart } from "@/components/kite-speed-chart";

export const metadata: Metadata = { title: "Activities" };
import { PaginatedActivityTable } from "@/components/paginated-activity-table";
import { TimeRangeSelector } from "@/components/time-range-selector";
import { rangeToDays } from "@/lib/time-ranges";
import { getDb } from "@/lib/db";
import {
  Wind,
  Snowflake,
  Mountain,
  Bike,
  Waves,
  MapPin,
  Clock,
  Flame,
  Gauge,
  ArrowUp,
  Trophy,
  PersonStanding,
  Heart,
  Activity,
} from "lucide-react";
import { cutoffIso } from "@/lib/date-range";
import type { Numeric } from "@/lib/json";

export const revalidate = 300;

const _ACTIVITY_ICONS: Record<string, React.ReactNode> = {
  kiteboarding_v2: <Wind className="h-4 w-4 text-cyan-400" />,
  wind_kite_surfing: <Wind className="h-4 w-4 text-cyan-400" />,
  resort_snowboarding: <Snowflake className="h-4 w-4 text-blue-300" />,
  resort_skiing_snowboarding_ws: <Snowflake className="h-4 w-4 text-blue-300" />,
  hiking: <Mountain className="h-4 w-4 text-green-400" />,
  e_bike_fitness: <Bike className="h-4 w-4 text-yellow-400" />,
  lap_swimming: <Waves className="h-4 w-4 text-blue-400" />,
  swimming: <Waves className="h-4 w-4 text-blue-400" />,
  open_water_swimming: <Waves className="h-4 w-4 text-blue-400" />,
  walking: <PersonStanding className="h-4 w-4 text-emerald-400" />,
  cycling: <Bike className="h-4 w-4 text-yellow-400" />,
  indoor_cardio: <Heart className="h-4 w-4 text-red-400" />,
  indoor_cycling: <Bike className="h-4 w-4 text-yellow-400" />,
  stand_up_paddleboarding_v2: <Waves className="h-4 w-4 text-cyan-300" />,
  other: <Activity className="h-4 w-4 text-muted-foreground" />,
};

const ACTIVITY_LABELS: Record<string, string> = {
  kiteboarding_v2: "Kiteboarding",
  wind_kite_surfing: "Kiteboarding",
  resort_snowboarding: "Snowboarding",
  resort_skiing_snowboarding_ws: "Snowboarding",
  hiking: "Hiking",
  e_bike_fitness: "E-Bike",
  lap_swimming: "Swimming",
  swimming: "Swimming",
  open_water_swimming: "Swimming",
  walking: "Walking",
  cycling: "Cycling",
  indoor_cardio: "Cardio",
  indoor_cycling: "Indoor Cycle",
  stand_up_paddleboarding_v2: "SUP",
  other: "Other",
};

const SPORT_GROUPS: Record<string, string[]> = {
  Kiteboarding: ["kiteboarding_v2", "wind_kite_surfing"],
  Snowboarding: ["resort_snowboarding", "resort_skiing_snowboarding_ws"],
  Hiking: ["hiking"],
  "E-Bike": ["e_bike_fitness"],
  Swimming: ["lap_swimming", "swimming", "open_water_swimming"],
  Walking: ["walking"],
  Cycling: ["cycling"],
  Cardio: ["indoor_cardio"],
  SUP: ["stand_up_paddleboarding_v2"],
  Other: ["other", "indoor_cycling"],
};

/**
 * The shape each query below selects. These are read straight off `garmin_activity_raw`, so a
 * column that is `SUM(...)` or `COUNT(*)` comes back as a `Numeric`: the driver decides whether
 * it is a number or a string, and an empty group is null. Every reader already wraps them in
 * `Number(...)`.
 */
interface SummaryRow {
  type_key: string;
  count: Numeric;
  total_km: Numeric;
  total_hours: Numeric;
  total_cal: Numeric;
  total_elev: Numeric;
}

interface KiteRow {
  name: string;
  date: string;
  max_speed_kts: Numeric;
  avg_speed_kts: Numeric;
  distance_km: Numeric;
  duration_min: Numeric;
  avg_hr: Numeric;
  calories: Numeric;
  wind_speed_mps: Numeric;
  wind_gust_mps: Numeric;
  wind_direction: Numeric;
  weather_desc: string | null;
  temp_c: Numeric;
}

interface SnowRow {
  name: string;
  date: string;
  max_speed_kmh: Numeric;
  distance_km: Numeric;
  duration_min: Numeric;
  elev_gain: Numeric;
  avg_hr: Numeric;
}

interface MonthlyRow {
  month: string;
  type_key: string;
  count: Numeric;
}

interface YearlyRow {
  year: Numeric;
  type_key: string;
  count: Numeric;
  total_km: Numeric;
  total_hours: Numeric;
}

interface CyclingRow {
  date: string;
  name: string;
  distance_km: Numeric;
  duration_min: Numeric;
  avg_speed_kmh: Numeric;
  max_speed_kmh: Numeric;
  elev_gain: Numeric;
  avg_hr: Numeric;
  calories: Numeric;
  type_key: string;
}

interface TimeBreakdownRow {
  category: string;
  hours: Numeric;
  sessions: Numeric;
}

interface SwimmingRow {
  date: string;
  name: string;
  distance_m: Numeric;
  duration_min: Numeric;
  avg_hr: Numeric;
  calories: Numeric;
  avg_swolf: string | null;
  avg_strokes: string | null;
}

interface WalkingRow {
  date: string;
  name: string;
  distance_km: Numeric;
  duration_min: Numeric;
  elev_gain: Numeric;
  avg_hr: Numeric;
  calories: Numeric;
  avg_speed_kmh: Numeric;
}

interface ActivityRow {
  activity_id: string;
  type_key: string;
  date: string;
  name: string;
  distance_km: Numeric;
  duration_min: Numeric;
  avg_hr: Numeric;
  calories: Numeric;
  elev_gain: Numeric;
  max_speed: Numeric;
}

async function getActivitySummary(cutoff: string) {
  const sql = getDb();
  const rows = await sql`
    SELECT
      raw_json->'activityType'->>'typeKey' as type_key,
      COUNT(*) as count,
      SUM((raw_json->>'distance')::float) / 1000.0 as total_km,
      SUM((raw_json->>'duration')::float) / 3600.0 as total_hours,
      SUM((raw_json->>'calories')::float) as total_cal,
      SUM(COALESCE((raw_json->>'elevationGain')::float, 0)) as total_elev
    FROM garmin_activity_raw
    WHERE endpoint_name = 'summary'
      AND raw_json->'activityType'->>'typeKey' NOT IN ('running', 'treadmill_running', 'strength_training')
      AND (raw_json->>'startTimeLocal')::timestamp >= ${cutoff}::date
    GROUP BY type_key
    ORDER BY count DESC
  `;
  return rows as SummaryRow[];
}

async function getKiteSessions(cutoff: string) {
  const sql = getDb();
  const rows = await sql`
    SELECT
      s.raw_json->>'activityName' as name,
      (s.raw_json->>'startTimeLocal')::text as date,
      (s.raw_json->>'maxSpeed')::float * 1.94384 as max_speed_kts,
      (s.raw_json->>'averageSpeed')::float * 1.94384 as avg_speed_kts,
      (s.raw_json->>'distance')::float / 1000.0 as distance_km,
      (s.raw_json->>'duration')::float / 60.0 as duration_min,
      (s.raw_json->>'averageHR')::float as avg_hr,
      (s.raw_json->>'calories')::float as calories,
      (w.raw_json->>'windSpeed')::float as wind_speed_mps,
      (w.raw_json->>'windGust')::float as wind_gust_mps,
      (w.raw_json->>'windDirection')::int as wind_direction,
      (w.raw_json->'weatherTypeDTO'->>'desc')::text as weather_desc,
      ROUND(((w.raw_json->>'temp')::float - 32) * 5.0 / 9.0) as temp_c
    FROM garmin_activity_raw s
    LEFT JOIN garmin_activity_raw w ON s.activity_id = w.activity_id AND w.endpoint_name = 'weather'
    WHERE s.endpoint_name = 'summary'
      AND s.raw_json->'activityType'->>'typeKey' IN ('kiteboarding_v2', 'wind_kite_surfing')
      AND (s.raw_json->>'startTimeLocal')::timestamp >= ${cutoff}::date
    ORDER BY (s.raw_json->>'startTimeLocal')::text ASC
  `;
  return rows as KiteRow[];
}

async function getSnowSessions(cutoff: string) {
  const sql = getDb();
  const rows = await sql`
    SELECT
      raw_json->>'activityName' as name,
      (raw_json->>'startTimeLocal')::text as date,
      (raw_json->>'maxSpeed')::float * 3.6 as max_speed_kmh,
      (raw_json->>'distance')::float / 1000.0 as distance_km,
      (raw_json->>'duration')::float / 60.0 as duration_min,
      COALESCE((raw_json->>'elevationGain')::float, 0) as elev_gain,
      (raw_json->>'averageHR')::float as avg_hr
    FROM garmin_activity_raw
    WHERE endpoint_name = 'summary'
      AND raw_json->'activityType'->>'typeKey' IN ('resort_snowboarding', 'resort_skiing_snowboarding_ws')
      AND (raw_json->>'startTimeLocal')::timestamp >= ${cutoff}::date
    ORDER BY (raw_json->>'startTimeLocal')::text DESC
  `;
  return rows as SnowRow[];
}

async function getMonthlyDistribution(cutoff: string) {
  const sql = getDb();
  const rows = await sql`
    SELECT
      TO_CHAR(DATE_TRUNC('month', (raw_json->>'startTimeLocal')::timestamp), 'YYYY-MM') as month,
      raw_json->'activityType'->>'typeKey' as type_key,
      COUNT(*) as count
    FROM garmin_activity_raw
    WHERE endpoint_name = 'summary'
      AND raw_json->'activityType'->>'typeKey' NOT IN ('running', 'treadmill_running', 'strength_training')
      AND (raw_json->>'startTimeLocal')::timestamp >= ${cutoff}::date
    GROUP BY month, type_key
    ORDER BY month ASC
  `;
  return rows as MonthlyRow[];
}

async function getYearlySportBreakdown(cutoff: string) {
  const sql = getDb();
  const rows = await sql`
    SELECT
      EXTRACT(YEAR FROM (raw_json->>'startTimeLocal')::timestamp)::int as year,
      raw_json->'activityType'->>'typeKey' as type_key,
      COUNT(*) as count,
      SUM((raw_json->>'distance')::float) / 1000.0 as total_km,
      SUM((raw_json->>'duration')::float) / 3600.0 as total_hours
    FROM garmin_activity_raw
    WHERE endpoint_name = 'summary'
      AND raw_json->'activityType'->>'typeKey' NOT IN ('running', 'treadmill_running', 'strength_training')
      AND (raw_json->>'startTimeLocal')::timestamp >= ${cutoff}::date
    GROUP BY year, type_key
    ORDER BY year DESC, count DESC
  `;
  return rows as YearlyRow[];
}

async function getCyclingSessions(cutoff: string) {
  const sql = getDb();
  const rows = await sql`
    SELECT
      (raw_json->>'startTimeLocal')::text as date,
      raw_json->>'activityName' as name,
      (raw_json->>'distance')::float / 1000.0 as distance_km,
      (raw_json->>'duration')::float / 60.0 as duration_min,
      (raw_json->>'averageSpeed')::float * 3.6 as avg_speed_kmh,
      (raw_json->>'maxSpeed')::float * 3.6 as max_speed_kmh,
      COALESCE((raw_json->>'elevationGain')::float, 0) as elev_gain,
      (raw_json->>'averageHR')::float as avg_hr,
      (raw_json->>'calories')::float as calories,
      raw_json->'activityType'->>'typeKey' as type_key
    FROM garmin_activity_raw
    WHERE endpoint_name = 'summary'
      AND raw_json->'activityType'->>'typeKey' IN ('cycling', 'e_bike_fitness', 'indoor_cycling')
      AND (raw_json->>'startTimeLocal')::timestamp >= ${cutoff}::date
    ORDER BY (raw_json->>'startTimeLocal')::text DESC
  `;
  return rows as CyclingRow[];
}

async function getTimeBreakdown(cutoff: string) {
  const sql = getDb();
  const rows = await sql`
    SELECT
      CASE
        WHEN raw_json->'activityType'->>'typeKey' IN ('running', 'treadmill_running') THEN 'Running'
        WHEN raw_json->'activityType'->>'typeKey' = 'strength_training' THEN 'Gym'
        WHEN raw_json->'activityType'->>'typeKey' = 'walking' THEN 'Walking'
        WHEN raw_json->'activityType'->>'typeKey' IN ('cycling', 'e_bike_fitness', 'indoor_cycling') THEN 'Cycling'
        WHEN raw_json->'activityType'->>'typeKey' IN ('kiteboarding_v2', 'wind_kite_surfing') THEN 'Kite'
        WHEN raw_json->'activityType'->>'typeKey' IN ('resort_snowboarding', 'resort_skiing_snowboarding_ws') THEN 'Snow'
        WHEN raw_json->'activityType'->>'typeKey' IN ('lap_swimming', 'swimming', 'open_water_swimming') THEN 'Swim'
        WHEN raw_json->'activityType'->>'typeKey' = 'indoor_cardio' THEN 'Cardio'
        ELSE 'Other'
      END as category,
      SUM((raw_json->>'duration')::float) / 3600.0 as hours,
      COUNT(*) as sessions
    FROM garmin_activity_raw
    WHERE endpoint_name = 'summary'
      AND (raw_json->>'startTimeLocal')::timestamp >= ${cutoff}::date
    GROUP BY category
    ORDER BY hours DESC
  `;
  return rows as TimeBreakdownRow[];
}

async function getSwimmingSessions(cutoff: string) {
  const sql = getDb();
  const rows = await sql`
    SELECT
      (raw_json->>'startTimeLocal')::text as date,
      raw_json->>'activityName' as name,
      (raw_json->>'distance')::float as distance_m,
      (raw_json->>'duration')::float / 60.0 as duration_min,
      (raw_json->>'averageHR')::float as avg_hr,
      (raw_json->>'calories')::float as calories,
      raw_json->>'averageSwolf' as avg_swolf,
      raw_json->>'averageStrokeCount' as avg_strokes
    FROM garmin_activity_raw
    WHERE endpoint_name = 'summary'
      AND raw_json->'activityType'->>'typeKey' IN ('lap_swimming', 'swimming', 'open_water_swimming')
      AND (raw_json->>'startTimeLocal')::timestamp >= ${cutoff}::date
    ORDER BY (raw_json->>'startTimeLocal')::text DESC
  `;
  return rows as SwimmingRow[];
}

async function getWalkingSessions(cutoff: string) {
  const sql = getDb();
  const rows = await sql`
    SELECT
      (raw_json->>'startTimeLocal')::text as date,
      raw_json->>'activityName' as name,
      (raw_json->>'distance')::float / 1000.0 as distance_km,
      (raw_json->>'duration')::float / 60.0 as duration_min,
      COALESCE((raw_json->>'elevationGain')::float, 0) as elev_gain,
      (raw_json->>'averageHR')::float as avg_hr,
      (raw_json->>'calories')::float as calories,
      (raw_json->>'averageSpeed')::float * 3.6 as avg_speed_kmh
    FROM garmin_activity_raw
    WHERE endpoint_name = 'summary'
      AND raw_json->'activityType'->>'typeKey' = 'walking'
      AND (raw_json->>'startTimeLocal')::timestamp >= ${cutoff}::date
    ORDER BY (raw_json->>'startTimeLocal')::text DESC
  `;
  return rows as WalkingRow[];
}

async function getAllActivities(cutoff: string) {
  const sql = getDb();
  const rows = await sql`
    SELECT
      activity_id::text as activity_id,
      raw_json->'activityType'->>'typeKey' as type_key,
      (raw_json->>'startTimeLocal')::text as date,
      raw_json->>'activityName' as name,
      (raw_json->>'distance')::float / 1000.0 as distance_km,
      (raw_json->>'duration')::float / 60.0 as duration_min,
      (raw_json->>'averageHR')::float as avg_hr,
      (raw_json->>'calories')::float as calories,
      COALESCE((raw_json->>'elevationGain')::float, 0) as elev_gain,
      (raw_json->>'maxSpeed')::float as max_speed
    FROM garmin_activity_raw
    WHERE endpoint_name = 'summary'
      AND raw_json->'activityType'->>'typeKey' NOT IN ('running', 'treadmill_running', 'strength_training')
      AND (raw_json->>'startTimeLocal')::timestamp >= ${cutoff}::date
    ORDER BY (raw_json->>'startTimeLocal')::text DESC
  `;
  return rows as ActivityRow[];
}

function formatDuration(mins: number) {
  const h = Math.floor(mins / 60);
  const m = Math.round(mins % 60);
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

function extractSpot(name: string): string {
  // Extract spot from Surfr/Kitesurf session names: "... at Spot: 'X'..."
  const spotMatch = name.match(/Spot:\s*'([^']+)'/);
  if (spotMatch) return spotMatch[1];
  // Extract location from "LocationName Kiteboarding" pattern
  const kiteMatch = name.match(/^(.+?)\s+Kiteboarding$/);
  if (kiteMatch) return kiteMatch[1];
  return "Unknown";
}

function extractJump(name: string): number {
  const match = name.match(/Highest Jump:\s*([\d.]+)\s*m/);
  return match ? parseFloat(match[1]) : 0;
}

function extractResort(name: string): string {
  // "Bansko Snowboard" → "Bansko"
  // "Savoie - Portes du Soleil - Avoriaz 1800 Snowboard" → "Avoriaz"
  // "Kalavryta Resort Snowboarding" → "Kalavryta"
  if (name.includes("Avoriaz") || name.includes("Portes du Soleil") || name.includes("Les")) return "Avoriaz";
  if (name.includes("Bansko")) return "Bansko";
  if (name.includes("Kalavryta")) return "Kalavryta";
  if (name.includes("Akrata")) return "Akrata";
  if (name.includes("Lefkasio")) return "Lefkasio";
  if (name.includes("Vrachní") || name.includes("Elatófyto")) return "Vasilitsa";
  return name.split(" ")[0];
}

export default async function ActivitiesPage({ searchParams }: { searchParams: Promise<{ range?: string }> }) {
  const params = await searchParams;
  const rangeDays = rangeToDays(params.range);
  const cutoff = cutoffIso(rangeDays);

  const [summary, kiteSessions, snowSessions, monthlyRaw, activities, yearlySports, cyclingSessions, timeBreakdown, walkingSessions, swimmingSessions] =
    await Promise.all([
      getActivitySummary(cutoff),
      getKiteSessions(cutoff),
      getSnowSessions(cutoff),
      getMonthlyDistribution(cutoff),
      getAllActivities(cutoff),
      getYearlySportBreakdown(cutoff),
      getCyclingSessions(cutoff),
      getTimeBreakdown(cutoff),
      getWalkingSessions(cutoff),
      getSwimmingSessions(cutoff),
    ]);

  const totalSessions = summary.reduce((s, r) => s + Number(r.count), 0);
  const totalKm = summary.reduce((s, r) => s + Number(r.total_km || 0), 0);
  const totalHours = summary.reduce((s, r) => s + Number(r.total_hours || 0), 0);
  const totalCal = summary.reduce((s, r) => s + Number(r.total_cal || 0), 0);

  // Build monthly distribution chart data
  const typeToSport: Record<string, string> = {};
  for (const [sport, keys] of Object.entries(SPORT_GROUPS)) {
    for (const k of keys) typeToSport[k] = sport;
  }

  const monthMap = new Map<string, Record<string, number>>();
  const sportSet = new Set<string>();
  for (const row of monthlyRaw) {
    const month = row.month;
    const sport = typeToSport[row.type_key] || row.type_key;
    sportSet.add(sport);
    if (!monthMap.has(month)) monthMap.set(month, {});
    const m = monthMap.get(month)!;
    m[sport] = (m[sport] || 0) + Number(row.count);
  }

  const sports = Array.from(sportSet);
  const monthlyData = Array.from(monthMap.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([month, counts]) => ({
      month,
      ...Object.fromEntries(sports.map((s) => [s, counts[s] || 0])),
    }));

  // Kite stats
  const kiteData = kiteSessions.map((k) => ({
    date: k.date,
    maxSpeedKts: Number(Number(k.max_speed_kts).toFixed(1)),
    distanceKm: Number(Number(k.distance_km).toFixed(1)),
    spot: extractSpot(k.name),
    jump: extractJump(k.name),
    name: k.name,
    durationMin: Number(k.duration_min),
    avgHr: Number(k.avg_hr),
    calories: Number(k.calories),
    windSpeedKts: k.wind_speed_mps ? Number((Number(k.wind_speed_mps) * 1.94384).toFixed(1)) : null,
    windGustKts: k.wind_gust_mps ? Number((Number(k.wind_gust_mps) * 1.94384).toFixed(1)) : null,
    windDirection: k.wind_direction ? Number(k.wind_direction) : null,
    weatherDesc: k.weather_desc || null,
    tempC: k.temp_c ? Number(k.temp_c) : null,
  }));

  const validKiteSessions = kiteData.filter((k) => k.maxSpeedKts > 0);
  const topSpeed = validKiteSessions.length
    ? Math.max(...validKiteSessions.map((k) => k.maxSpeedKts))
    : 0;
  const avgSpeed = validKiteSessions.length
    ? validKiteSessions.reduce((s: number, k) => s + k.maxSpeedKts, 0) / validKiteSessions.length
    : 0;
  const bestJump = Math.max(...kiteData.map((k) => k.jump), 0);
  const totalKiteKm = kiteData.reduce((s: number, k) => s + k.distanceKm, 0);

  // Kite spot frequency
  const spotCounts: Record<string, number> = {};
  for (const k of kiteData) {
    spotCounts[k.spot] = (spotCounts[k.spot] || 0) + 1;
  }
  const topSpots = Object.entries(spotCounts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5);

  // Wind stats for kite
  // The predicate is spelled out so the rest of this block reads a number, not a number | null:
  // a plain .filter() narrows nothing, and every wind figure below depends on it.
  const kiteWithWind = kiteData.filter(
    (k): k is (typeof kiteData)[number] & { windSpeedKts: number } =>
      k.windSpeedKts !== null && k.windSpeedKts > 0,
  );
  const avgWindSpeed = kiteWithWind.length
    ? kiteWithWind.reduce((s: number, k) => s + k.windSpeedKts, 0) / kiteWithWind.length
    : 0;
  const maxWindGust = kiteWithWind.length
    ? Math.max(...kiteWithWind.map((k) => k.windGustKts || 0))
    : 0;

  // Snow stats
  const snowData = snowSessions.map((s) => ({
    name: s.name,
    date: s.date,
    resort: extractResort(s.name),
    distanceKm: Number(Number(s.distance_km).toFixed(1)),
    durationMin: Number(s.duration_min),
    elevGain: Number(s.elev_gain),
    maxSpeedKmh: Number(Number(s.max_speed_kmh).toFixed(1)),
    avgHr: Number(s.avg_hr),
  }));

  const totalVertical = snowData.reduce((s: number, d) => s + d.elevGain, 0);
  const topSnowSpeed = snowData.length
    ? Math.max(...snowData.map((d) => d.maxSpeedKmh))
    : 0;
  const totalSnowKm = snowData.reduce((s: number, d) => s + d.distanceKm, 0);

  // Snow resort frequency
  const resortCounts: Record<string, number> = {};
  for (const d of snowData) {
    resortCounts[d.resort] = (resortCounts[d.resort] || 0) + 1;
  }
  const topResorts = Object.entries(resortCounts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5);

  return (
    <div className="container mx-auto px-3 sm:px-6 py-4 sm:py-8 max-w-7xl">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between mb-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Activities</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Kiteboarding, snowboarding, hiking & more
          </p>
        </div>
        <TimeRangeSelector />
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <StatCard
          title="Total Sessions"
          value={totalSessions}
          icon={<Mountain className="h-4 w-4 text-muted-foreground" />}
        />
        <StatCard
          title="Total Distance"
          value={totalKm > 0 ? `${totalKm.toFixed(0)} km` : "—"}
          icon={<MapPin className="h-4 w-4 text-blue-400" />}
        />
        <StatCard
          title="Total Time"
          value={totalHours > 0 ? `${totalHours.toFixed(0)}h` : "—"}
          icon={<Clock className="h-4 w-4 text-green-400" />}
        />
        <StatCard
          title="Total Calories"
          value={totalCal > 0 ? `${Math.round(totalCal).toLocaleString()}` : "—"}
          subtitle={totalCal > 0 ? "kcal" : undefined}
          icon={<Flame className="h-4 w-4 text-orange-400" />}
        />
      </div>

      {/* Monthly Distribution */}
      <ExpandableChartCard
        title="Monthly Activity Distribution"
        className="mb-6"
      >
        <MonthlyActivityChart data={monthlyData} sports={sports} />
      </ExpandableChartCard>

      {/* Yearly Sport Breakdown */}
      {yearlySports.length > 0 && (() => {
        // Group by year
        const yearMap = new Map<number, { type_key: string; label: string; count: number; total_km: number; total_hours: number }[]>();
        for (const row of yearlySports) {
          const year = Number(row.year);
          if (!yearMap.has(year)) yearMap.set(year, []);
          const label = ACTIVITY_LABELS[row.type_key] || row.type_key;
          const existing = yearMap.get(year)!.find((s) => s.label === label);
          if (existing) {
            existing.count += Number(row.count);
            existing.total_km += Number(row.total_km || 0);
            existing.total_hours += Number(row.total_hours || 0);
          } else {
            yearMap.get(year)!.push({
              type_key: row.type_key,
              label,
              count: Number(row.count),
              total_km: Number(row.total_km || 0),
              total_hours: Number(row.total_hours || 0),
            });
          }
        }
        const years = Array.from(yearMap.keys()).sort((a, b) => b - a);

        const SPORT_COLORS: Record<string, string> = {
          kiteboarding_v2: "bg-cyan-500",
          wind_kite_surfing: "bg-cyan-500",
          resort_snowboarding: "bg-blue-400",
          resort_skiing_snowboarding_ws: "bg-blue-400",
          hiking: "bg-green-500",
          walking: "bg-emerald-400",
          cycling: "bg-yellow-500",
          e_bike_fitness: "bg-yellow-500",
          indoor_cardio: "bg-red-400",
          lap_swimming: "bg-blue-500",
          swimming: "bg-blue-500",
          open_water_swimming: "bg-blue-500",
          stand_up_paddleboarding_v2: "bg-cyan-300",
          indoor_cycling: "bg-yellow-400",
          other: "bg-violet-400",
        };

        return (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Activity by Year
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {years.map((year) => {
                  const sports = yearMap.get(year)!;
                  const totalCount = sports.reduce((s, r) => s + r.count, 0);
                  const totalKm = sports.reduce((s, r) => s + r.total_km, 0);
                  const totalHrs = sports.reduce((s, r) => s + r.total_hours, 0);

                  return (
                    <div key={year}>
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-sm font-semibold">{year}</span>
                        <span className="text-xs text-muted-foreground">
                          {totalCount} {totalCount === 1 ? "session" : "sessions"} · {totalKm.toFixed(0)} km · {totalHrs.toFixed(0)}h
                        </span>
                      </div>
                      {/* Stacked bar */}
                      <div className="flex h-4 rounded-full overflow-hidden mb-1">
                        {sports.map((s) => {
                          const pct = (s.count / totalCount) * 100;
                          const color = SPORT_COLORS[s.type_key] || "bg-muted";
                          return (
                            <div
                              key={s.type_key}
                              className={`${color} transition-all`}
                              style={{ width: `${pct}%` }}
                              title={`${s.label}: ${s.count}`}
                            />
                          );
                        })}
                      </div>
                      <div className="flex flex-wrap gap-x-3 gap-y-0.5">
                        {sports.map((s) => (
                          <span key={s.label} className="text-[10px] text-muted-foreground">
                            {s.label}: {s.count}
                          </span>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        );
      })()}

      {/* Kiteboarding Deep Dive */}
      {kiteSessions.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold flex items-center gap-2 mb-4">
            <Wind className="h-5 w-5 text-cyan-400" />
            Kiteboarding
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            <StatCard
              title="Top Speed"
              value={topSpeed > 0 ? `${topSpeed.toFixed(1)} kts` : "—"}
              icon={<Gauge className="h-4 w-4 text-cyan-400" />}
            />
            <StatCard
              title="Avg Max Speed"
              value={avgSpeed > 0 ? `${avgSpeed.toFixed(1)} kts` : "—"}
              icon={<Wind className="h-4 w-4 text-cyan-400" />}
            />
            <StatCard
              title="Total Distance"
              value={totalKiteKm > 0 ? `${totalKiteKm.toFixed(0)} km` : "—"}
              icon={<MapPin className="h-4 w-4 text-cyan-400" />}
            />
            {bestJump > 0 ? (
              <StatCard
                title="Best Jump"
                value={`${bestJump.toFixed(1)}m`}
                icon={<ArrowUp className="h-4 w-4 text-cyan-400" />}
              />
            ) : (
              <StatCard
                title="Sessions"
                value={kiteSessions.length}
                icon={<Trophy className="h-4 w-4 text-cyan-400" />}
              />
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Speed Progression */}
            <ExpandableChartCard
              title="Max Speed Progression"
              icon={<Gauge className="h-4 w-4 text-cyan-400" />}
            >
              <KiteSpeedChart data={kiteData} />
            </ExpandableChartCard>

            {/* Spots & Sessions + Wind */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Spots & Sessions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {topSpots.map(([spot, count]) => (
                    <div key={spot} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <MapPin className="h-3.5 w-3.5 text-cyan-400" />
                        <span className="text-sm">{spot}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <div
                          className="h-2 rounded-full bg-cyan-400/30"
                          style={{
                            width: `${(count / topSpots[0][1]) * 100}px`,
                          }}
                        >
                          <div
                            className="h-full rounded-full bg-cyan-400"
                            style={{
                              width: `${(count / topSpots[0][1]) * 100}%`,
                            }}
                          />
                        </div>
                        <span className="text-sm text-muted-foreground w-8 text-right">
                          {count}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
                {/* Jump Records */}
                {kiteData.some((k) => k.jump > 0) && (
                  <div className="mt-6 pt-4 border-t border-border">
                    <h4 className="text-xs font-medium text-muted-foreground mb-3 uppercase tracking-wider">
                      Jump Records
                    </h4>
                    <div className="space-y-2">
                      {kiteData
                        .filter((k) => k.jump > 0)
                        .sort((a, b) => b.jump - a.jump)
                        .map((k, i: number) => (
                          <div
                            key={i}
                            className="flex items-center justify-between text-sm"
                          >
                            <div className="flex items-center gap-2">
                              <ArrowUp className="h-3 w-3 text-cyan-400" />
                              <span>{k.spot}</span>
                            </div>
                            <div className="flex items-center gap-3">
                              <span className="text-muted-foreground">
                                {new Date(k.date).toLocaleDateString("en-US", {
                                  month: "short",
                                  day: "numeric",
                                })}
                              </span>
                              <span className="font-medium">
                                {k.jump.toFixed(2)}m
                              </span>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Wind Conditions */}
          {kiteWithWind.length > 0 && (
            <Card className="mt-4">
              <CardHeader>
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <Wind className="h-4 w-4 text-cyan-400" />
                  Wind Conditions
                  <span className="ml-auto text-xs font-normal">{kiteWithWind.length} sessions with wind data</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div>
                    <div className="text-xs text-muted-foreground mb-1">Avg Wind</div>
                    <div className="text-xl font-bold text-cyan-400">{avgWindSpeed.toFixed(1)} kts</div>
                  </div>
                  {maxWindGust > 0 && (
                  <div>
                    <div className="text-xs text-muted-foreground mb-1">Max Gust</div>
                    <div className="text-xl font-bold text-cyan-400">{maxWindGust.toFixed(1)} kts</div>
                  </div>
                  )}
                  <div>
                    <div className="text-xs text-muted-foreground mb-1">Sessions w/ Wind</div>
                    <div className="text-xl font-bold">{kiteWithWind.length}/{kiteData.length}</div>
                  </div>
                </div>
                <div className="space-y-2">
                  {kiteData
                    .filter((k) => k.windSpeedKts)
                    .sort((a, b) => b.date.localeCompare(a.date))
                    .slice(0, 10)
                    .map((k, i: number) => (
                      <div key={i} className="flex items-center justify-between text-sm border-b border-border/20 pb-2">
                        <div className="flex items-center gap-2">
                          <Wind className="h-3.5 w-3.5 text-cyan-400" />
                          <span className="font-medium">{k.spot}</span>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground">
                          <span>{k.windSpeedKts} kts</span>
                          {k.windGustKts !== null && k.windGustKts > 0 && (
                            <span className="text-cyan-400">gusts {k.windGustKts}</span>
                          )}
                          {k.tempC !== null && <span>{k.tempC}°C</span>}
                          <span className="w-20 text-right">
                            {new Date(k.date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "2-digit" })}
                          </span>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Snowboarding Deep Dive */}
      {snowSessions.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold flex items-center gap-2 mb-4">
            <Snowflake className="h-5 w-5 text-blue-300" />
            Snowboarding
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            <StatCard
              title="Total Vertical"
              value={totalVertical > 0 ? `${totalVertical.toLocaleString()}m` : "—"}
              icon={<ArrowUp className="h-4 w-4 text-blue-300" />}
            />
            <StatCard
              title="Top Speed"
              value={topSnowSpeed > 0 ? `${topSnowSpeed.toFixed(0)} km/h` : "—"}
              icon={<Gauge className="h-4 w-4 text-blue-300" />}
            />
            <StatCard
              title="Total Distance"
              value={totalSnowKm > 0 ? `${totalSnowKm.toFixed(0)} km` : "—"}
              icon={<MapPin className="h-4 w-4 text-blue-300" />}
            />
            <StatCard
              title="Days on Snow"
              value={snowData.length}
              icon={<Snowflake className="h-4 w-4 text-blue-300" />}
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Resort breakdown */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Resorts
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {topResorts.map(([resort, count]) => {
                    const resortSessions = snowData.filter(
                      (d) => d.resort === resort
                    );
                    const resortVert = resortSessions.reduce(
                      (s: number, d) => s + d.elevGain,
                      0
                    );
                    const resortTopSpeed = Math.max(
                      ...resortSessions.map((d) => d.maxSpeedKmh)
                    );
                    return (
                      <div key={resort} className="border-b border-border/50 pb-3 last:border-0 last:pb-0">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium flex items-center gap-2">
                            <Snowflake className="h-3.5 w-3.5 text-blue-300" />
                            {resort}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {count} {count === 1 ? "day" : "days"}
                          </span>
                        </div>
                        <div className="flex gap-4 text-xs text-muted-foreground">
                          {resortVert > 0 && <span>{resortVert.toLocaleString()}m vert</span>}
                          <span>{resortTopSpeed.toFixed(0)} km/h top</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Best sessions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Best Sessions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {snowData
                    .sort((a, b) => b.elevGain - a.elevGain)
                    .slice(0, 5)
                    .map((d, i: number) => (
                      <div
                        key={i}
                        className="flex items-center justify-between text-sm"
                      >
                        <div>
                          <div className="font-medium">{d.resort}</div>
                          <div className="text-xs text-muted-foreground">
                            {new Date(d.date).toLocaleDateString("en-US", {
                              month: "short",
                              day: "numeric",
                              year: "numeric",
                            })}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-medium">
                            {d.elevGain > 0
                              ? `${d.elevGain.toLocaleString()}m`
                              : `${d.distanceKm} km`}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {d.maxSpeedKmh.toFixed(0)} km/h ·{" "}
                            {formatDuration(d.durationMin)}
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* Total Time Breakdown */}
      {timeBreakdown.length > 0 && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Clock className="h-4 w-4 text-blue-400" />
              Total Training Time Breakdown
              <span className="ml-auto text-xs font-normal">
                {Math.round(timeBreakdown.reduce((s: number, t) => s + Number(t.hours), 0))}h total
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {(() => {
              const data = timeBreakdown;
              const totalH = data.reduce((s: number, t) => s + Number(t.hours), 0);
              const catColors: Record<string, string> = {
                Gym: "bg-orange-500", Running: "bg-green-500", Walking: "bg-emerald-400",
                Cycling: "bg-yellow-500", Kite: "bg-cyan-500", Snow: "bg-blue-400",
                Cardio: "bg-red-400", Swim: "bg-blue-500", Other: "bg-violet-400",
              };
              return (
                <div>
                  {/* Stacked bar */}
                  <div className="flex h-8 rounded-lg overflow-hidden mb-4">
                    {data.map((t) => {
                      const pct = totalH > 0 ? (Number(t.hours) / totalH) * 100 : 0;
                      if (pct < 0.5) return null;
                      return (
                        <div
                          key={t.category}
                          className={`${catColors[t.category] || "bg-gray-500"} flex items-center justify-center`}
                          style={{ width: `${pct}%` }}
                          title={`${t.category}: ${Number(t.hours).toFixed(0)}h (${pct.toFixed(0)}%)`}
                        >
                          {pct > 6 && <span className="text-[10px] font-bold text-black/70">{t.category}</span>}
                        </div>
                      );
                    })}
                  </div>
                  {/* Details grid */}
                  <div className="grid grid-cols-3 md:grid-cols-5 gap-3">
                    {data.map((t) => {
                      const hours = Number(t.hours);
                      const pct = totalH > 0 ? ((hours / totalH) * 100).toFixed(0) : "0";
                      return (
                        <div key={t.category} className="flex items-center gap-2">
                          <span className={`w-2.5 h-2.5 rounded-full ${catColors[t.category] || "bg-gray-500"} shrink-0`} />
                          <div className="text-xs">
                            <div className="font-medium">{t.category}</div>
                            <div className="text-muted-foreground">
                              {hours.toFixed(0)}h · {Number(t.sessions)} · {pct}%
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })()}
          </CardContent>
        </Card>
      )}

      {/* Walking Section */}
      {walkingSessions.length >= 5 && (
        <div className="mb-6">
          <h2 className="text-xl font-semibold flex items-center gap-2 mb-4">
            <PersonStanding className="h-5 w-5 text-emerald-400" />
            Walking
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            {(() => {
              const walks = walkingSessions;
              const totalDist = walks.reduce((s: number, w) => s + Number(w.distance_km || 0), 0);
              const totalElev = walks.reduce((s: number, w) => s + Number(w.elev_gain || 0), 0);
              const avgDuration = walks.reduce((s: number, w) => s + Number(w.duration_min || 0), 0) / walks.length;
              const _totalCal = walks.reduce((s: number, w) => s + Number(w.calories || 0), 0);
              return (
                <>
                  <StatCard title="Total Walks" value={walks.length} icon={<PersonStanding className="h-4 w-4 text-emerald-400" />} />
                  <StatCard title="Total Distance" value={totalDist > 0 ? `${totalDist.toFixed(0)} km` : "—"} icon={<MapPin className="h-4 w-4 text-blue-400" />} />
                  <StatCard title="Avg Duration" value={avgDuration > 0 ? formatDuration(avgDuration) : "—"} icon={<Clock className="h-4 w-4 text-green-400" />} />
                  <StatCard title="Total Elevation" value={totalElev > 0 ? `${totalElev.toFixed(0)}m` : "—"} icon={<ArrowUp className="h-4 w-4 text-amber-400" />} />
                </>
              );
            })()}
          </div>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">Recent Walks</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {walkingSessions.slice(0, 8).map((w, i: number) => (
                  <div key={i} className="flex items-center justify-between text-sm border-b border-border/20 pb-2">
                    <div className="flex items-center gap-2">
                      <PersonStanding className="h-3.5 w-3.5 text-emerald-400" />
                      <span className="font-medium truncate max-w-[200px]">{w.name || "Walking"}</span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span>{Number(w.distance_km).toFixed(1)} km</span>
                      <span>{formatDuration(Number(w.duration_min))}</span>
                      {Number(w.elev_gain) > 0 && <span>{Number(w.elev_gain).toFixed(0)}m ↑</span>}
                      <span className="w-20 text-right">{new Date(w.date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "2-digit" })}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Cycling Section */}
      {cyclingSessions.length >= 5 && (
        <div className="mb-6">
          <h2 className="text-xl font-semibold flex items-center gap-2 mb-4">
            <Bike className="h-5 w-5 text-yellow-400" />
            Cycling
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            {(() => {
              const rides = cyclingSessions;
              const totalDist = rides.reduce((s: number, r) => s + Number(r.distance_km || 0), 0);
              const totalElev = rides.reduce((s: number, r) => s + Number(r.elev_gain || 0), 0);
              const validSpeeds = rides.filter((r) => r.max_speed_kmh && Number(r.max_speed_kmh) > 0).map((r) => Number(r.max_speed_kmh));
              const topSpeed = validSpeeds.length > 0 ? Math.max(...validSpeeds) : 0;
              const _avgSpeed = rides.filter((r) => Number(r.avg_speed_kmh) > 0).reduce((s: number, r) => s + Number(r.avg_speed_kmh), 0) / rides.filter((r) => Number(r.avg_speed_kmh) > 0).length;
              return (
                <>
                  <StatCard title="Total Rides" value={rides.length} icon={<Bike className="h-4 w-4 text-yellow-400" />} />
                  <StatCard title="Total Distance" value={totalDist > 0 ? `${totalDist.toFixed(0)} km` : "—"} icon={<MapPin className="h-4 w-4 text-blue-400" />} />
                  <StatCard title="Top Speed" value={topSpeed > 0 ? `${topSpeed.toFixed(0)} km/h` : "—"} icon={<Gauge className="h-4 w-4 text-red-400" />} />
                  <StatCard title="Total Elevation" value={totalElev > 0 ? `${totalElev.toFixed(0)}m` : "—"} icon={<ArrowUp className="h-4 w-4 text-green-400" />} />
                </>
              );
            })()}
          </div>
          {/* Recent rides */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">Recent Rides</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {cyclingSessions.slice(0, 8).map((r, i: number) => (
                  <div key={i} className="flex items-center justify-between text-sm border-b border-border/20 pb-2">
                    <div className="flex items-center gap-2">
                      <Bike className="h-3.5 w-3.5 text-yellow-400" />
                      <span className="font-medium truncate max-w-[200px]">{r.name || "Cycling"}</span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span>{Number(r.distance_km).toFixed(1)} km</span>
                      <span>{formatDuration(Number(r.duration_min))}</span>
                      {Number(r.avg_speed_kmh) > 0 && <span>{Number(r.avg_speed_kmh).toFixed(0)} km/h</span>}
                      <span className="w-20 text-right">{new Date(r.date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "2-digit" })}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Swimming Section */}
      {swimmingSessions.length >= 3 && (
        <div className="mb-6">
          <h2 className="text-xl font-semibold flex items-center gap-2 mb-4">
            <Waves className="h-5 w-5 text-blue-400" />
            Swimming
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            {(() => {
              const swims = swimmingSessions;
              const totalDist = swims.reduce((s: number, sw) => s + Number(sw.distance_m || 0), 0);
              const avgDist = totalDist / swims.length;
              const totalDuration = swims.reduce((s: number, sw) => s + Number(sw.duration_min || 0), 0);
              const totalCal = swims.reduce((s: number, sw) => s + Number(sw.calories || 0), 0);
              return (
                <>
                  <StatCard title="Total Swims" value={swims.length} icon={<Waves className="h-4 w-4 text-blue-400" />} />
                  <StatCard title="Total Distance" value={totalDist > 0 ? `${(totalDist / 1000).toFixed(1)} km` : "—"} subtitle={`${swims.length} sessions`} icon={<MapPin className="h-4 w-4 text-blue-400" />} />
                  <StatCard title="Avg Distance" value={avgDist > 0 ? (avgDist >= 1000 ? `${(avgDist / 1000).toFixed(1)} km` : `${Math.round(avgDist)}m`) : "—"} icon={<Activity className="h-4 w-4 text-blue-400" />} />
                  <StatCard title="Total Time" value={totalDuration > 0 ? `${Math.round(totalDuration / 60)}h` : "—"} subtitle={totalCal > 0 ? `${Math.round(totalCal).toLocaleString()} kcal` : undefined} icon={<Clock className="h-4 w-4 text-blue-400" />} />
                </>
              );
            })()}
          </div>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">All Swim Sessions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {swimmingSessions.map((sw, i: number) => (
                  <div key={i} className="flex items-center justify-between text-sm border-b border-border/20 pb-2">
                    <div className="flex items-center gap-2">
                      <Waves className="h-3.5 w-3.5 text-blue-400" />
                      <span className="font-medium">{sw.name || "Pool Swim"}</span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span>{Math.round(Number(sw.distance_m))}m</span>
                      <span>{Math.round(Number(sw.duration_min))} min</span>
                      {Number(sw.avg_hr) > 0 && <span>{Math.round(Number(sw.avg_hr))} bpm</span>}
                      <span className="w-24 text-right">{new Date(sw.date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Activity Log */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium text-muted-foreground">
            All Activities
          </CardTitle>
        </CardHeader>
        <CardContent>
          <PaginatedActivityTable
            activities={activities.map((a) => ({
              activity_id: a.activity_id,
              type_key: a.type_key,
              date: a.date,
              name: a.name,
              distance_km: Number(a.distance_km),
              duration_min: Number(a.duration_min),
              avg_hr: a.avg_hr ? Number(a.avg_hr) : null,
              calories: a.calories ? Number(a.calories) : null,
              elev_gain: Number(a.elev_gain),
            }))}
          />
        </CardContent>
      </Card>
    </div>
  );
}
