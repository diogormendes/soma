import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Sidebar } from "@/components/sidebar";
import { DemoBanner } from "@/components/demo-banner";
import { Toaster } from "sonner";
import { SWRegister } from "@/components/sw-register";
import { TzBeacon } from "@/components/tz-beacon";
import { PWAInstallPrompt } from "@/components/pwa-install-prompt";
import { NavProgress } from "@/components/nav-progress";
import { ChatWidget } from "@/components/chat-widget";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const isDemo = process.env.DEMO_MODE === "true";

export const metadata: Metadata = {
  title: {
    default: "Soma: Dashboard",
    template: "Soma: %s",
  },
  description: "Science-driven personal health dashboard",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "Soma",
  },
  icons: {
    apple: "/icons/apple-touch-icon.png",
  },
  other: {
    "mobile-web-app-capable": "yes",
    "apple-mobile-web-app-capable": "yes",
  },
};

export const viewport: Viewport = {
  themeColor: "#10b981",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.variable} antialiased`}>
        <TooltipProvider>
          {isDemo && (
            <DemoBanner repoUrl="https://github.com/drkostas/soma" />
          )}
          <NavProgress />
          <Sidebar />
          <main className={`min-h-screen bg-background pb-[env(safe-area-inset-bottom,0.5rem)] pt-[calc(env(safe-area-inset-top,0px)+3rem)] pl-[env(safe-area-inset-left,0px)] pr-[env(safe-area-inset-right,0px)] lg:pl-16 xl:pl-56 2xl:pl-64 lg:pt-6${isDemo ? " md:pt-8" : ""}`}>
            {children}
          </main>
          <Toaster richColors />
        </TooltipProvider>
        {/* Tells the server which timezone this device is in. See `lib/request-tz.ts`. */}
        <TzBeacon />
        <SWRegister />
        <PWAInstallPrompt />
        <ChatWidget />
      </body>
    </html>
  );
}
