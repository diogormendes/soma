/**
 * Garmin ingestion — TS port of sync/src/garmin_sync.py + pipeline._get_stale_dates.
 * Runs as a Vercel cron (#183), alongside the Python sync during the incremental
 * cutover. Idempotent upserts into garmin_raw_data / garmin_activity_raw, so
 * running both is safe (last writer wins, same rows).
 *
 * Auth: garmin-auth GarminAuth + DBTokenStore (default platform `garmin_tokens`,
 * matching soma's fresh main-account DI tokens). connectapi paths carry query
 * params inline (the TS client's connectapi(path) takes no separate params arg).
 */
import { GarminAuth, DBTokenStore, type GarminClient } from "garmin-auth";
import type { QueryFn } from "./db";
import {
  DAILY_ENDPOINTS, RANGE_ENDPOINTS, DISCOVERY_ENDPOINTS, ACTIVITY_DETAIL_ENDPOINTS,
  buildRequest, type GarminRequest,
} from "garmin-auth/endpoints";
import { processDay } from "./garmin-parse-day";
import { updateFitnessTrajectory } from "./fitness-stream";
import { computeDailyReadiness } from "./readiness-stream";
import { updateBodyComp } from "./body-comp-stream";
import { extractKiteJumpsForActivity } from "./kite-jumps";
import { dateInAthleteTz } from "./athlete-tz";

const MIN_COMPLETE_HR_POINTS = 650;
// DI-token API profile path (returns displayName). garth's web API uses
// /userprofile/profile, but the DI/native-app token 404s there — socialProfile
// is the DI-compatible path (same one garmin-auth's own refresh() uses).
const PROFILE_URL = "/userprofile-service/socialProfile";
// The athlete's weight (GRAMS), exact birthDate and vo2MaxRunning. Not in the package's
// endpoint catalogue, so it is fetched here rather than through DAILY_ENDPOINTS.
const USER_SETTINGS_URL = "/userprofile-service/userprofile/user-settings";

/** Today's date (YYYY-MM-DD) in the athlete's timezone (soma#872). */
export function athleteToday(now: Date = new Date()): string {
  return dateInAthleteTz(now);
}

/**
 * Days Garmin holds a weigh-in for that soma has no weight row for.
 *
 * ⛔ `getStaleDates` re-fetches a day only while its heart rate is incomplete or its health summary looks
 * partial. A weigh-in typed into Garmin the next evening lands on a day that is already complete by those
 * measures, so it was never collected. One range call over the look-back window says which days Garmin
 * holds a weigh-in for, and any of those missing here is fetched again.
 */
export function lateWeighInDates(range: unknown, storedDates: Iterable<string>): string[] {
  const days = (range as { dailyWeightSummaries?: unknown } | null)?.dailyWeightSummaries;
  if (!Array.isArray(days)) return [];
  const stored = new Set(storedDates);
  const late = new Set<string>();
  for (const d of days as Array<{ summaryDate?: string; allWeightMetrics?: Array<{ calendarDate?: string }> }>) {
    const samples = Array.isArray(d?.allWeightMetrics) ? d.allWeightMetrics : [];
    if (!samples.length) continue;
    const date = d.summaryDate ?? samples[0]?.calendarDate;
    if (typeof date === "string" && date.length >= 10 && !stored.has(date.slice(0, 10))) late.add(date.slice(0, 10));
  }
  return [...late].sort().reverse();
}

/** Serialize a GarminRequest into a connectapi path with an inline query string. */
export function toPath(req: GarminRequest): string {
  if (!req.params) return req.url;
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries(req.params)) qs.set(k, String(v));
  return `${req.url}?${qs.toString()}`;
}

/** Python `if data:` — treat empty dict/array/null/undefined as "no data". */
function hasData(d: unknown): boolean {
  if (d === null || d === undefined) return false;
  if (Array.isArray(d)) return d.length > 0;
  if (typeof d === "object") return Object.keys(d as object).length > 0;
  return Boolean(d);
}

async function upsertRaw(sql: QueryFn, date: string, endpoint: string, data: unknown): Promise<void> {
  await sql`
    INSERT INTO garmin_raw_data (date, endpoint_name, raw_json)
    VALUES (${date}, ${endpoint}, ${JSON.stringify(data)}::jsonb)
    ON CONFLICT (date, endpoint_name)
    DO UPDATE SET raw_json = EXCLUDED.raw_json, synced_at = NOW()`;
}

async function upsertActivityRaw(sql: QueryFn, activityId: number, endpoint: string, data: unknown): Promise<void> {
  await sql`
    INSERT INTO garmin_activity_raw (activity_id, endpoint_name, raw_json)
    VALUES (${activityId}, ${endpoint}, ${JSON.stringify(data)}::jsonb)
    ON CONFLICT (activity_id, endpoint_name)
    DO UPDATE SET raw_json = EXCLUDED.raw_json, synced_at = NOW()`;
}

/**
 * Find dates needing a re-sync (incomplete HR or partial health summary).
 * Today is always included. Port of pipeline._get_stale_dates.
 */
export async function getStaleDates(sql: QueryFn, maxLookback = 14, now: Date = new Date()): Promise<string[]> {
  const today = athleteToday(now);
  const stale = new Set<string>([today]);
  const dayMs = 86_400_000;
  const todayMs = Date.parse(today + "T00:00:00Z");

  // Check 1: HR completeness — find the most recent complete day, include everything after it.
  const hrRows = await sql`
    SELECT date::text AS date,
           CASE WHEN jsonb_typeof(raw_json->'heartRateValues') = 'array'
                THEN jsonb_array_length(raw_json->'heartRateValues') ELSE 0 END AS pts
    FROM garmin_raw_data
    WHERE endpoint_name = 'heart_rates'
      AND date >= ${today}::date - ${maxLookback}::int
      AND date < ${today}::date
    ORDER BY date DESC`;
  let foundComplete = false;
  for (const row of hrRows) {
    if (Number(row.pts) >= MIN_COMPLETE_HR_POINTS && !foundComplete) {
      foundComplete = true;
      const daysBack = Math.round((todayMs - Date.parse(row.date + "T00:00:00Z")) / dayMs);
      for (let i = 0; i < daysBack; i++) stale.add(new Date(todayMs - i * dayMs).toISOString().slice(0, 10));
      break;
    }
  }
  if (!foundComplete) {
    for (let i = 0; i < maxLookback; i++) stale.add(new Date(todayMs - i * dayMs).toISOString().slice(0, 10));
  }

  // Check 2: health summaries with suspiciously low values (partial sync).
  const partial = await sql`
    SELECT date::text AS date FROM daily_health_summary
    WHERE date >= ${today}::date - 7 AND date < ${today}::date
      AND (bmr_kilocalories < 1500 OR total_steps < 1000)`;
  for (const row of partial) stale.add(row.date);

  return [...stale].sort().reverse();
}

/** Sync all daily + range endpoints for one date. Returns count of records saved. */
export async function syncDay(client: GarminClient, sql: QueryFn, display: string, date: string): Promise<number> {
  let count = 0;
  const groups = [DAILY_ENDPOINTS, RANGE_ENDPOINTS];
  for (const group of groups) {
    for (const [name, spec] of Object.entries(group)) {
      try {
        const req = buildRequest(spec, { display, cdate: date });
        const data = await client.connectapi(toPath(req));
        if (hasData(data)) {
          await upsertRaw(sql, date, name, data);
          count += 1;
        }
      } catch (e) {
        console.warn(`  Warning: ${name} failed for ${date}: ${(e as Error).message}`);
      }
    }
  }
  return count;
}

/**
 * Fetch the per-activity detail endpoints (splits, HR zones, weather, gear, …) and
 * upsert to garmin_activity_raw. Skips activities that already have details stored,
 * so it only fetches new ones (avoids re-hitting the API + rate limits). Mirrors
 * garmin_sync.sync_activity_details. Returns the count of detail endpoints saved.
 */
export async function syncActivityDetails(client: GarminClient, sql: QueryFn, activityId: number): Promise<number> {
  const seen = await sql`
    SELECT 1 FROM garmin_activity_raw WHERE activity_id = ${activityId} AND endpoint_name = 'details' LIMIT 1`;
  if (seen.length) return 0; // already fetched
  let count = 0;
  for (const [name, spec] of Object.entries(ACTIVITY_DETAIL_ENDPOINTS)) {
    try {
      const req = buildRequest(spec, { aid: activityId });
      const data = await client.connectapi(toPath(req));
      if (hasData(data)) { await upsertActivityRaw(sql, activityId, name, data); count += 1; }
    } catch (e) {
      console.warn(`  Warning: ${name} failed for activity ${activityId}: ${(e as Error).message}`);
    }
  }
  return count;
}

/** The fields this sync reads off one entry of Garmin's activity list. */
interface ActivityListEntry {
  activityId?: number;
  activityType?: { typeKey?: string | null } | null;
  startTimeGMT?: string | null;
}

/** Discover activities for a date, store list + per-activity summaries + details, return ids. */
export async function syncActivitiesForDate(client: GarminClient, sql: QueryFn, date: string): Promise<number[]> {
  try {
    const req = buildRequest(DISCOVERY_ENDPOINTS.activities_list, { cdate: date });
    const activities = (await client.connectapi(toPath(req))) as ActivityListEntry[];
    if (!activities || !activities.length) return [];
    await upsertRaw(sql, date, "activities_list", activities);
    const ids: number[] = [];
    for (const a of activities) {
      const aid = a.activityId;
      if (aid) {
        await upsertActivityRaw(sql, aid, "summary", a);
        await syncActivityDetails(client, sql, aid);
        // Kiteboarding: extract per-jump data (downloads the FIT). Non-fatal —
        // never let a kite-extraction failure break the activity sync.
        try {
          const typeKey = a.activityType?.typeKey ?? null;
          const kite = await extractKiteJumpsForActivity(sql, client, aid, typeKey, a.startTimeGMT ?? null);
          if (kite) console.log(`  Kite: ${kite.summary.jump_count} jumps for ${aid}`);
        } catch (e) {
          console.warn(`  Warning: kite extraction for ${aid} failed: ${(e as Error).message}`);
        }
        ids.push(aid);
      }
    }
    return ids;
  } catch (e) {
    console.warn(`  Warning: activities_list failed for ${date}: ${(e as Error).message}`);
    return [];
  }
}

export interface IngestResult {
  displayName: string;
  dates: string[];
  recordsSaved: number;
  activitiesFound: number;
  daysParsed: number;
  fitnessUpdated: boolean;
  readiness: string | null;
}

/** Top-level ingestion: auth, resolve stale dates, sync each. */
export async function runGarminIngest(databaseUrl: string, sql: QueryFn): Promise<IngestResult> {
  // A flat DI row (Python fresh-login) would read as "needs MFA" (#723).
  const auth = new GarminAuth({ store: new DBTokenStore(databaseUrl) });
  const client = await auth.client();
  const profile = (await client.connectapi(PROFILE_URL)) as { displayName?: string };
  const display = profile?.displayName;
  if (!display) throw new Error("Garmin profile has no displayName");

  // Garmin's own record of the athlete: weight, birth date and VO2max in one call. Stored so
  // `getAthleteProfile` can read it without a Garmin client, because the enrichment step runs
  // before the pipeline has built one (soma#986). Non-fatal: a missing row means the calorie
  // estimate uses the default profile, which is what it did before.
  try {
    const settings = await client.connectapi(USER_SETTINGS_URL);
    if (hasData(settings)) await upsertRaw(sql, athleteToday(), "user_settings", settings);
  } catch (e) {
    console.warn(`  user_settings failed: ${(e as Error).message}`);
  }

  const dates = await getStaleDates(sql);
  // Days whose weigh-in reached Garmin after the day was already complete. Non-fatal: if the range call
  // fails, the run goes on with the usual days, as it did before this existed.
  try {
    const to = athleteToday();
    const from = new Date(Date.parse(`${to}T00:00:00Z`) - 14 * 86_400_000).toISOString().slice(0, 10);
    const range = await client.connectapi(`/weight-service/weight/range/${from}/${to}?includeAll=true`);
    const stored = (await sql`
      SELECT DISTINCT date::text AS date FROM weight_log WHERE date >= ${from}::date AND date <= ${to}::date
    `) as unknown as { date: string }[];
    const late = lateWeighInDates(range, stored.map((r) => r.date));
    for (const d of late) if (!dates.includes(d)) dates.push(d);
    dates.sort().reverse();
    if (late.length) console.log(`  late weigh-ins to collect: ${late.join(", ")}`);
  } catch (e) {
    console.warn(`  late weigh-in check failed: ${(e as Error).message}`);
  }
  let recordsSaved = 0;
  let activitiesFound = 0;
  let daysParsed = 0;
  for (const date of dates) {
    recordsSaved += await syncDay(client, sql, display, date);
    activitiesFound += (await syncActivitiesForDate(client, sql, date)).length;
    // Parse the raw we just fetched into the structured tables (daily_health_summary,
    // sleep_detail, weight_log) — completes fetch→parse in TS.
    try { const r = await processDay(sql, date); if (r.health) daysParsed += 1; }
    catch (e) { console.warn(`  parse failed for ${date}: ${(e as Error).message}`); }
  }
  // Fitness trajectory (VO2max / EF / decoupling / race prediction) for today —
  // uses the raw + parsed data just ingested. Non-fatal on failure.
  let fitnessUpdated = false;
  try {
    const traj = await updateFitnessTrajectory(sql, athleteToday());
    fitnessUpdated = traj !== null;
  } catch (e) { console.warn(`  fitness trajectory failed: ${(e as Error).message}`); }

  // Body composition: 7-day weight EMA + weight-adjusted VDOT / race prediction.
  // Runs AFTER the fitness trajectory (needs its vo2max) and overwrites weight_kg
  // with the smoothed value. Non-fatal on failure.
  try { await updateBodyComp(sql, athleteToday()); }
  catch (e) { console.warn(`  body comp failed: ${(e as Error).message}`); }

  // Daily readiness (traffic light from HRV/sleep/RHR/body-battery z-scores) for
  // today — reads the daily_health_summary just parsed. Non-fatal on failure.
  let readiness: string | null = null;
  try {
    const rd = await computeDailyReadiness(sql, athleteToday());
    readiness = rd.traffic_light;
  } catch (e) { console.warn(`  readiness failed: ${(e as Error).message}`); }

  return { displayName: display, dates, recordsSaved, activitiesFound, daysParsed, fitnessUpdated, readiness };
}
